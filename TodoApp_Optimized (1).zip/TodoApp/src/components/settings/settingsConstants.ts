export const OPTION_ICON_SIZE = 32;
