import {
  require_react
} from "./chunk-EBMUM4CB.js";
import "./chunk-G3PMV62Z.js";
export default require_react();
