import {
  newStyled
} from "./chunk-VQFPU33Y.js";
import "./chunk-ICKI6VIU.js";
import "./chunk-ZHEA33UK.js";
import "./chunk-6QGP7FRW.js";
import "./chunk-2RSSGIOK.js";
import "./chunk-EBMUM4CB.js";
import "./chunk-G3PMV62Z.js";
export {
  newStyled as default
};
