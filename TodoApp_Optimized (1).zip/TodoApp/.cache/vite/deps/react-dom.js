import {
  require_react_dom
} from "./chunk-ZV5E4JRH.js";
import "./chunk-EBMUM4CB.js";
import "./chunk-G3PMV62Z.js";
export default require_react_dom();
