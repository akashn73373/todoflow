import {
  _objectWithoutPropertiesLoose
} from "./chunk-B66LP72S.js";
import {
  require_react_dom
} from "./chunk-ZV5E4JRH.js";
import {
  _extends
} from "./chunk-2RSSGIOK.js";
import {
  require_react
} from "./chunk-EBMUM4CB.js";
import {
  __commonJS,
  __toESM
} from "./chunk-G3PMV62Z.js";

// node_modules/warning/warning.js
var require_warning = __commonJS({
  "node_modules/warning/warning.js"(exports, module) {
    "use strict";
    var __DEV__ = true;
    var warning = function() {
    };
    if (__DEV__) {
      printWarning = function printWarning2(format, args) {
        var len = arguments.length;
        args = new Array(len > 1 ? len - 1 : 0);
        for (var key = 1; key < len; key++) {
          args[key - 1] = arguments[key];
        }
        var argIndex = 0;
        var message = "Warning: " + format.replace(/%s/g, function() {
          return args[argIndex++];
        });
        if (typeof console !== "undefined") {
          console.error(message);
        }
        try {
          throw new Error(message);
        } catch (x2) {
        }
      };
      warning = function(condition, format, args) {
        var len = arguments.length;
        args = new Array(len > 2 ? len - 2 : 0);
        for (var key = 2; key < len; key++) {
          args[key - 2] = arguments[key];
        }
        if (format === void 0) {
          throw new Error(
            "`warning(condition, format, ...args)` requires a warning message argument"
          );
        }
        if (!condition) {
          printWarning.apply(null, [format].concat(args));
        }
      };
    }
    var printWarning;
    module.exports = warning;
  }
});

// node_modules/use-sync-external-store/cjs/use-sync-external-store-shim.development.js
var require_use_sync_external_store_shim_development = __commonJS({
  "node_modules/use-sync-external-store/cjs/use-sync-external-store-shim.development.js"(exports) {
    "use strict";
    (function() {
      function is2(x2, y) {
        return x2 === y && (0 !== x2 || 1 / x2 === 1 / y) || x2 !== x2 && y !== y;
      }
      function useSyncExternalStore$2(subscribe, getSnapshot) {
        didWarnOld18Alpha || void 0 === React5.startTransition || (didWarnOld18Alpha = true, console.error(
          "You are using an outdated, pre-release alpha of React 18 that does not support useSyncExternalStore. The use-sync-external-store shim will not work correctly. Upgrade to a newer pre-release."
        ));
        var value = getSnapshot();
        if (!didWarnUncachedGetSnapshot) {
          var cachedValue = getSnapshot();
          objectIs(value, cachedValue) || (console.error(
            "The result of getSnapshot should be cached to avoid an infinite loop"
          ), didWarnUncachedGetSnapshot = true);
        }
        cachedValue = useState6({
          inst: { value, getSnapshot }
        });
        var inst = cachedValue[0].inst, forceUpdate = cachedValue[1];
        useLayoutEffect3(
          function() {
            inst.value = value;
            inst.getSnapshot = getSnapshot;
            checkIfSnapshotChanged(inst) && forceUpdate({ inst });
          },
          [subscribe, value, getSnapshot]
        );
        useEffect4(
          function() {
            checkIfSnapshotChanged(inst) && forceUpdate({ inst });
            return subscribe(function() {
              checkIfSnapshotChanged(inst) && forceUpdate({ inst });
            });
          },
          [subscribe]
        );
        useDebugValue(value);
        return value;
      }
      function checkIfSnapshotChanged(inst) {
        var latestGetSnapshot = inst.getSnapshot;
        inst = inst.value;
        try {
          var nextValue = latestGetSnapshot();
          return !objectIs(inst, nextValue);
        } catch (error3) {
          return true;
        }
      }
      function useSyncExternalStore$1(subscribe, getSnapshot) {
        return getSnapshot();
      }
      "undefined" !== typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ && "function" === typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStart && __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStart(Error());
      var React5 = require_react(), objectIs = "function" === typeof Object.is ? Object.is : is2, useState6 = React5.useState, useEffect4 = React5.useEffect, useLayoutEffect3 = React5.useLayoutEffect, useDebugValue = React5.useDebugValue, didWarnOld18Alpha = false, didWarnUncachedGetSnapshot = false, shim = "undefined" === typeof window || "undefined" === typeof window.document || "undefined" === typeof window.document.createElement ? useSyncExternalStore$1 : useSyncExternalStore$2;
      exports.useSyncExternalStore = void 0 !== React5.useSyncExternalStore ? React5.useSyncExternalStore : shim;
      "undefined" !== typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ && "function" === typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStop && __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStop(Error());
    })();
  }
});

// node_modules/use-sync-external-store/shim/index.js
var require_shim = __commonJS({
  "node_modules/use-sync-external-store/shim/index.js"(exports, module) {
    "use strict";
    if (false) {
      module.exports = null;
    } else {
      module.exports = require_use_sync_external_store_shim_development();
    }
  }
});

// node_modules/use-subscription/cjs/use-subscription.development.js
var require_use_subscription_development = __commonJS({
  "node_modules/use-subscription/cjs/use-subscription.development.js"(exports) {
    "use strict";
    (function() {
      "undefined" !== typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ && "function" === typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStart && __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStart(Error());
      var shim = require_shim();
      exports.useSubscription = function(_ref) {
        return shim.useSyncExternalStore(_ref.subscribe, _ref.getCurrentValue);
      };
      "undefined" !== typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ && "function" === typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStop && __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStop(Error());
    })();
  }
});

// node_modules/use-subscription/index.js
var require_use_subscription = __commonJS({
  "node_modules/use-subscription/index.js"(exports, module) {
    "use strict";
    if (false) {
      module.exports = null;
    } else {
      module.exports = require_use_subscription_development();
    }
  }
});

// node_modules/xstate/lib/_virtual/_tslib.js
var require_tslib = __commonJS({
  "node_modules/xstate/lib/_virtual/_tslib.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.__assign = function() {
      exports.__assign = Object.assign || function __assign3(t3) {
        for (var s2, i2 = 1, n2 = arguments.length; i2 < n2; i2++) {
          s2 = arguments[i2];
          for (var p in s2) if (Object.prototype.hasOwnProperty.call(s2, p)) t3[p] = s2[p];
        }
        return t3;
      };
      return exports.__assign.apply(this, arguments);
    };
    function __rest3(s2, e) {
      var t3 = {};
      for (var p in s2) if (Object.prototype.hasOwnProperty.call(s2, p) && e.indexOf(p) < 0)
        t3[p] = s2[p];
      if (s2 != null && typeof Object.getOwnPropertySymbols === "function")
        for (var i2 = 0, p = Object.getOwnPropertySymbols(s2); i2 < p.length; i2++) {
          if (e.indexOf(p[i2]) < 0 && Object.prototype.propertyIsEnumerable.call(s2, p[i2]))
            t3[p[i2]] = s2[p[i2]];
        }
      return t3;
    }
    function __values3(o2) {
      var s2 = typeof Symbol === "function" && Symbol.iterator, m = s2 && o2[s2], i2 = 0;
      if (m) return m.call(o2);
      if (o2 && typeof o2.length === "number") return {
        next: function() {
          if (o2 && i2 >= o2.length) o2 = void 0;
          return { value: o2 && o2[i2++], done: !o2 };
        }
      };
      throw new TypeError(s2 ? "Object is not iterable." : "Symbol.iterator is not defined.");
    }
    function __read6(o2, n2) {
      var m = typeof Symbol === "function" && o2[Symbol.iterator];
      if (!m) return o2;
      var i2 = m.call(o2), r2, ar = [], e;
      try {
        while ((n2 === void 0 || n2-- > 0) && !(r2 = i2.next()).done) ar.push(r2.value);
      } catch (error3) {
        e = { error: error3 };
      } finally {
        try {
          if (r2 && !r2.done && (m = i2["return"])) m.call(i2);
        } finally {
          if (e) throw e.error;
        }
      }
      return ar;
    }
    function __spreadArray3(to, from, pack) {
      if (pack || arguments.length === 2) for (var i2 = 0, l2 = from.length, ar; i2 < l2; i2++) {
        if (ar || !(i2 in from)) {
          if (!ar) ar = Array.prototype.slice.call(from, 0, i2);
          ar[i2] = from[i2];
        }
      }
      return to.concat(ar || Array.prototype.slice.call(from));
    }
    exports.__read = __read6;
    exports.__rest = __rest3;
    exports.__spreadArray = __spreadArray3;
    exports.__values = __values3;
  }
});

// node_modules/xstate/lib/types.js
var require_types = __commonJS({
  "node_modules/xstate/lib/types.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.ActionTypes = void 0;
    (function(ActionTypes2) {
      ActionTypes2["Start"] = "xstate.start";
      ActionTypes2["Stop"] = "xstate.stop";
      ActionTypes2["Raise"] = "xstate.raise";
      ActionTypes2["Send"] = "xstate.send";
      ActionTypes2["Cancel"] = "xstate.cancel";
      ActionTypes2["NullEvent"] = "";
      ActionTypes2["Assign"] = "xstate.assign";
      ActionTypes2["After"] = "xstate.after";
      ActionTypes2["DoneState"] = "done.state";
      ActionTypes2["DoneInvoke"] = "done.invoke";
      ActionTypes2["Log"] = "xstate.log";
      ActionTypes2["Init"] = "xstate.init";
      ActionTypes2["Invoke"] = "xstate.invoke";
      ActionTypes2["ErrorExecution"] = "error.execution";
      ActionTypes2["ErrorCommunication"] = "error.communication";
      ActionTypes2["ErrorPlatform"] = "error.platform";
      ActionTypes2["ErrorCustom"] = "xstate.error";
      ActionTypes2["Update"] = "xstate.update";
      ActionTypes2["Pure"] = "xstate.pure";
      ActionTypes2["Choose"] = "xstate.choose";
    })(exports.ActionTypes || (exports.ActionTypes = {}));
    exports.SpecialTargets = void 0;
    (function(SpecialTargets2) {
      SpecialTargets2["Parent"] = "#_parent";
      SpecialTargets2["Internal"] = "#_internal";
    })(exports.SpecialTargets || (exports.SpecialTargets = {}));
  }
});

// node_modules/xstate/lib/actionTypes.js
var require_actionTypes = __commonJS({
  "node_modules/xstate/lib/actionTypes.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var types = require_types();
    var start4 = types.ActionTypes.Start;
    var stop4 = types.ActionTypes.Stop;
    var raise3 = types.ActionTypes.Raise;
    var send3 = types.ActionTypes.Send;
    var cancel3 = types.ActionTypes.Cancel;
    var nullEvent2 = types.ActionTypes.NullEvent;
    var assign4 = types.ActionTypes.Assign;
    var after3 = types.ActionTypes.After;
    var doneState2 = types.ActionTypes.DoneState;
    var log3 = types.ActionTypes.Log;
    var init2 = types.ActionTypes.Init;
    var invoke2 = types.ActionTypes.Invoke;
    var errorExecution2 = types.ActionTypes.ErrorExecution;
    var errorPlatform2 = types.ActionTypes.ErrorPlatform;
    var error3 = types.ActionTypes.ErrorCustom;
    var update3 = types.ActionTypes.Update;
    var choose3 = types.ActionTypes.Choose;
    var pure3 = types.ActionTypes.Pure;
    exports.after = after3;
    exports.assign = assign4;
    exports.cancel = cancel3;
    exports.choose = choose3;
    exports.doneState = doneState2;
    exports.error = error3;
    exports.errorExecution = errorExecution2;
    exports.errorPlatform = errorPlatform2;
    exports.init = init2;
    exports.invoke = invoke2;
    exports.log = log3;
    exports.nullEvent = nullEvent2;
    exports.pure = pure3;
    exports.raise = raise3;
    exports.send = send3;
    exports.start = start4;
    exports.stop = stop4;
    exports.update = update3;
  }
});

// node_modules/xstate/lib/constants.js
var require_constants = __commonJS({
  "node_modules/xstate/lib/constants.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var STATE_DELIMITER2 = ".";
    var EMPTY_ACTIVITY_MAP2 = {};
    var DEFAULT_GUARD_TYPE2 = "xstate.guard";
    var TARGETLESS_KEY2 = "";
    exports.DEFAULT_GUARD_TYPE = DEFAULT_GUARD_TYPE2;
    exports.EMPTY_ACTIVITY_MAP = EMPTY_ACTIVITY_MAP2;
    exports.STATE_DELIMITER = STATE_DELIMITER2;
    exports.TARGETLESS_KEY = TARGETLESS_KEY2;
  }
});

// node_modules/xstate/lib/environment.js
var require_environment = __commonJS({
  "node_modules/xstate/lib/environment.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var IS_PRODUCTION2 = false;
    exports.IS_PRODUCTION = IS_PRODUCTION2;
  }
});

// node_modules/xstate/lib/utils.js
var require_utils = __commonJS({
  "node_modules/xstate/lib/utils.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var _tslib = require_tslib();
    var types = require_types();
    var actionTypes = require_actionTypes();
    var constants = require_constants();
    var environment = require_environment();
    var _a2;
    function keys(value) {
      return Object.keys(value);
    }
    function matchesState2(parentStateId, childStateId, delimiter) {
      if (delimiter === void 0) {
        delimiter = constants.STATE_DELIMITER;
      }
      var parentStateValue = toStateValue2(parentStateId, delimiter);
      var childStateValue = toStateValue2(childStateId, delimiter);
      if (isString2(childStateValue)) {
        if (isString2(parentStateValue)) {
          return childStateValue === parentStateValue;
        }
        return false;
      }
      if (isString2(parentStateValue)) {
        return parentStateValue in childStateValue;
      }
      return Object.keys(parentStateValue).every(function(key) {
        if (!(key in childStateValue)) {
          return false;
        }
        return matchesState2(parentStateValue[key], childStateValue[key]);
      });
    }
    function getEventType2(event2) {
      try {
        return isString2(event2) || typeof event2 === "number" ? "".concat(event2) : event2.type;
      } catch (e) {
        throw new Error("Events must be strings or objects with a string event.type property.");
      }
    }
    function getActionType(action) {
      try {
        return isString2(action) || typeof action === "number" ? "".concat(action) : isFunction2(action) ? action.name : action.type;
      } catch (e) {
        throw new Error("Actions must be strings or objects with a string action.type property.");
      }
    }
    function toStatePath2(stateId, delimiter) {
      try {
        if (isArray2(stateId)) {
          return stateId;
        }
        return stateId.toString().split(delimiter);
      } catch (e) {
        throw new Error("'".concat(stateId, "' is not a valid state path."));
      }
    }
    function isStateLike2(state) {
      return typeof state === "object" && "value" in state && "context" in state && "event" in state && "_event" in state;
    }
    function toStateValue2(stateValue, delimiter) {
      if (isStateLike2(stateValue)) {
        return stateValue.value;
      }
      if (isArray2(stateValue)) {
        return pathToStateValue2(stateValue);
      }
      if (typeof stateValue !== "string") {
        return stateValue;
      }
      var statePath = toStatePath2(stateValue, delimiter);
      return pathToStateValue2(statePath);
    }
    function pathToStateValue2(statePath) {
      if (statePath.length === 1) {
        return statePath[0];
      }
      var value = {};
      var marker = value;
      for (var i2 = 0; i2 < statePath.length - 1; i2++) {
        if (i2 === statePath.length - 2) {
          marker[statePath[i2]] = statePath[i2 + 1];
        } else {
          marker[statePath[i2]] = {};
          marker = marker[statePath[i2]];
        }
      }
      return value;
    }
    function mapValues2(collection, iteratee) {
      var result = {};
      var collectionKeys = Object.keys(collection);
      for (var i2 = 0; i2 < collectionKeys.length; i2++) {
        var key = collectionKeys[i2];
        result[key] = iteratee(collection[key], key, collection, i2);
      }
      return result;
    }
    function mapFilterValues2(collection, iteratee, predicate) {
      var e_1, _a3;
      var result = {};
      try {
        for (var _b = _tslib.__values(Object.keys(collection)), _c = _b.next(); !_c.done; _c = _b.next()) {
          var key = _c.value;
          var item = collection[key];
          if (!predicate(item)) {
            continue;
          }
          result[key] = iteratee(item, key, collection);
        }
      } catch (e_1_1) {
        e_1 = {
          error: e_1_1
        };
      } finally {
        try {
          if (_c && !_c.done && (_a3 = _b.return)) _a3.call(_b);
        } finally {
          if (e_1) throw e_1.error;
        }
      }
      return result;
    }
    var path2 = function(props) {
      return function(object) {
        var e_2, _a3;
        var result = object;
        try {
          for (var props_1 = _tslib.__values(props), props_1_1 = props_1.next(); !props_1_1.done; props_1_1 = props_1.next()) {
            var prop = props_1_1.value;
            result = result[prop];
          }
        } catch (e_2_1) {
          e_2 = {
            error: e_2_1
          };
        } finally {
          try {
            if (props_1_1 && !props_1_1.done && (_a3 = props_1.return)) _a3.call(props_1);
          } finally {
            if (e_2) throw e_2.error;
          }
        }
        return result;
      };
    };
    function nestedPath2(props, accessorProp) {
      return function(object) {
        var e_3, _a3;
        var result = object;
        try {
          for (var props_2 = _tslib.__values(props), props_2_1 = props_2.next(); !props_2_1.done; props_2_1 = props_2.next()) {
            var prop = props_2_1.value;
            result = result[accessorProp][prop];
          }
        } catch (e_3_1) {
          e_3 = {
            error: e_3_1
          };
        } finally {
          try {
            if (props_2_1 && !props_2_1.done && (_a3 = props_2.return)) _a3.call(props_2);
          } finally {
            if (e_3) throw e_3.error;
          }
        }
        return result;
      };
    }
    function toStatePaths2(stateValue) {
      if (!stateValue) {
        return [[]];
      }
      if (isString2(stateValue)) {
        return [[stateValue]];
      }
      var result = flatten2(Object.keys(stateValue).map(function(key) {
        var subStateValue = stateValue[key];
        if (typeof subStateValue !== "string" && (!subStateValue || !Object.keys(subStateValue).length)) {
          return [[key]];
        }
        return toStatePaths2(stateValue[key]).map(function(subPath) {
          return [key].concat(subPath);
        });
      }));
      return result;
    }
    function pathsToStateValue(paths) {
      var e_4, _a3;
      var result = {};
      if (paths && paths.length === 1 && paths[0].length === 1) {
        return paths[0][0];
      }
      try {
        for (var paths_1 = _tslib.__values(paths), paths_1_1 = paths_1.next(); !paths_1_1.done; paths_1_1 = paths_1.next()) {
          var currentPath = paths_1_1.value;
          var marker = result;
          for (var i2 = 0; i2 < currentPath.length; i2++) {
            var subPath = currentPath[i2];
            if (i2 === currentPath.length - 2) {
              marker[subPath] = currentPath[i2 + 1];
              break;
            }
            marker[subPath] = marker[subPath] || {};
            marker = marker[subPath];
          }
        }
      } catch (e_4_1) {
        e_4 = {
          error: e_4_1
        };
      } finally {
        try {
          if (paths_1_1 && !paths_1_1.done && (_a3 = paths_1.return)) _a3.call(paths_1);
        } finally {
          if (e_4) throw e_4.error;
        }
      }
      return result;
    }
    function flatten2(array) {
      var _a3;
      return (_a3 = []).concat.apply(_a3, _tslib.__spreadArray([], _tslib.__read(array), false));
    }
    function toArrayStrict2(value) {
      if (isArray2(value)) {
        return value;
      }
      return [value];
    }
    function toArray3(value) {
      if (value === void 0) {
        return [];
      }
      return toArrayStrict2(value);
    }
    function mapContext2(mapper, context, _event) {
      var e_5, _a3;
      if (isFunction2(mapper)) {
        return mapper(context, _event.data);
      }
      var result = {};
      try {
        for (var _b = _tslib.__values(Object.keys(mapper)), _c = _b.next(); !_c.done; _c = _b.next()) {
          var key = _c.value;
          var subMapper = mapper[key];
          if (isFunction2(subMapper)) {
            result[key] = subMapper(context, _event.data);
          } else {
            result[key] = subMapper;
          }
        }
      } catch (e_5_1) {
        e_5 = {
          error: e_5_1
        };
      } finally {
        try {
          if (_c && !_c.done && (_a3 = _b.return)) _a3.call(_b);
        } finally {
          if (e_5) throw e_5.error;
        }
      }
      return result;
    }
    function isBuiltInEvent2(eventType) {
      return /^(done|error)\./.test(eventType);
    }
    function isPromiseLike2(value) {
      if (value instanceof Promise) {
        return true;
      }
      if (value !== null && (isFunction2(value) || typeof value === "object") && isFunction2(value.then)) {
        return true;
      }
      return false;
    }
    function isBehavior2(value) {
      return value !== null && typeof value === "object" && "transition" in value && typeof value.transition === "function";
    }
    function partition3(items, predicate) {
      var e_6, _a3;
      var _b = _tslib.__read([[], []], 2), truthy = _b[0], falsy = _b[1];
      try {
        for (var items_1 = _tslib.__values(items), items_1_1 = items_1.next(); !items_1_1.done; items_1_1 = items_1.next()) {
          var item = items_1_1.value;
          if (predicate(item)) {
            truthy.push(item);
          } else {
            falsy.push(item);
          }
        }
      } catch (e_6_1) {
        e_6 = {
          error: e_6_1
        };
      } finally {
        try {
          if (items_1_1 && !items_1_1.done && (_a3 = items_1.return)) _a3.call(items_1);
        } finally {
          if (e_6) throw e_6.error;
        }
      }
      return [truthy, falsy];
    }
    function updateHistoryStates2(hist, stateValue) {
      return mapValues2(hist.states, function(subHist, key) {
        if (!subHist) {
          return void 0;
        }
        var subStateValue = (isString2(stateValue) ? void 0 : stateValue[key]) || (subHist ? subHist.current : void 0);
        if (!subStateValue) {
          return void 0;
        }
        return {
          current: subStateValue,
          states: updateHistoryStates2(subHist, subStateValue)
        };
      });
    }
    function updateHistoryValue2(hist, stateValue) {
      return {
        current: stateValue,
        states: updateHistoryStates2(hist, stateValue)
      };
    }
    function updateContext2(context, _event, assignActions, state) {
      if (!environment.IS_PRODUCTION) {
        exports.warn(!!context, "Attempting to update undefined context");
      }
      var updatedContext = context ? assignActions.reduce(function(acc, assignAction) {
        var e_7, _a3;
        var assignment = assignAction.assignment;
        var meta = {
          state,
          action: assignAction,
          _event
        };
        var partialUpdate = {};
        if (isFunction2(assignment)) {
          partialUpdate = assignment(acc, _event.data, meta);
        } else {
          try {
            for (var _b = _tslib.__values(Object.keys(assignment)), _c = _b.next(); !_c.done; _c = _b.next()) {
              var key = _c.value;
              var propAssignment = assignment[key];
              partialUpdate[key] = isFunction2(propAssignment) ? propAssignment(acc, _event.data, meta) : propAssignment;
            }
          } catch (e_7_1) {
            e_7 = {
              error: e_7_1
            };
          } finally {
            try {
              if (_c && !_c.done && (_a3 = _b.return)) _a3.call(_b);
            } finally {
              if (e_7) throw e_7.error;
            }
          }
        }
        return Object.assign({}, acc, partialUpdate);
      }, context) : context;
      return updatedContext;
    }
    exports.warn = function() {
    };
    if (!environment.IS_PRODUCTION) {
      exports.warn = function(condition, message) {
        var error3 = condition instanceof Error ? condition : void 0;
        if (!error3 && condition) {
          return;
        }
        if (console !== void 0) {
          var args = ["Warning: ".concat(message)];
          if (error3) {
            args.push(error3);
          }
          console.warn.apply(console, args);
        }
      };
    }
    function isArray2(value) {
      return Array.isArray(value);
    }
    function isFunction2(value) {
      return typeof value === "function";
    }
    function isString2(value) {
      return typeof value === "string";
    }
    function toGuard2(condition, guardMap) {
      if (!condition) {
        return void 0;
      }
      if (isString2(condition)) {
        return {
          type: constants.DEFAULT_GUARD_TYPE,
          name: condition,
          predicate: guardMap ? guardMap[condition] : void 0
        };
      }
      if (isFunction2(condition)) {
        return {
          type: constants.DEFAULT_GUARD_TYPE,
          name: condition.name,
          predicate: condition
        };
      }
      return condition;
    }
    function isObservable2(value) {
      try {
        return "subscribe" in value && isFunction2(value.subscribe);
      } catch (e) {
        return false;
      }
    }
    var symbolObservable2 = function() {
      return typeof Symbol === "function" && Symbol.observable || "@@observable";
    }();
    var interopSymbols2 = (_a2 = {}, _a2[symbolObservable2] = function() {
      return this;
    }, _a2[Symbol.observable] = function() {
      return this;
    }, _a2);
    function isMachine2(value) {
      return !!value && "__xstatenode" in value;
    }
    function isActor3(value) {
      return !!value && typeof value.send === "function";
    }
    var uniqueId2 = /* @__PURE__ */ function() {
      var currentId = 0;
      return function() {
        currentId++;
        return currentId.toString(16);
      };
    }();
    function toEventObject2(event2, payload) {
      if (isString2(event2) || typeof event2 === "number") {
        return _tslib.__assign({
          type: event2
        }, payload);
      }
      return event2;
    }
    function toSCXMLEvent2(event2, scxmlEvent) {
      if (!isString2(event2) && "$$type" in event2 && event2.$$type === "scxml") {
        return event2;
      }
      var eventObject = toEventObject2(event2);
      return _tslib.__assign({
        name: eventObject.type,
        data: eventObject,
        $$type: "scxml",
        type: "external"
      }, scxmlEvent);
    }
    function toTransitionConfigArray2(event2, configLike) {
      var transitions = toArrayStrict2(configLike).map(function(transitionLike) {
        if (typeof transitionLike === "undefined" || typeof transitionLike === "string" || isMachine2(transitionLike)) {
          return {
            target: transitionLike,
            event: event2
          };
        }
        return _tslib.__assign(_tslib.__assign({}, transitionLike), {
          event: event2
        });
      });
      return transitions;
    }
    function normalizeTarget2(target) {
      if (target === void 0 || target === constants.TARGETLESS_KEY) {
        return void 0;
      }
      return toArray3(target);
    }
    function reportUnhandledExceptionOnInvocation2(originalError, currentError, id) {
      if (!environment.IS_PRODUCTION) {
        var originalStackTrace = originalError.stack ? " Stacktrace was '".concat(originalError.stack, "'") : "";
        if (originalError === currentError) {
          console.error("Missing onError handler for invocation '".concat(id, "', error was '").concat(originalError, "'.").concat(originalStackTrace));
        } else {
          var stackTrace = currentError.stack ? " Stacktrace was '".concat(currentError.stack, "'") : "";
          console.error("Missing onError handler and/or unhandled exception/promise rejection for invocation '".concat(id, "'. ") + "Original error: '".concat(originalError, "'. ").concat(originalStackTrace, " Current error is '").concat(currentError, "'.").concat(stackTrace));
        }
      }
    }
    function evaluateGuard2(machine, guard, context, _event, state) {
      var guards = machine.options.guards;
      var guardMeta = {
        state,
        cond: guard,
        _event
      };
      if (guard.type === constants.DEFAULT_GUARD_TYPE) {
        return ((guards === null || guards === void 0 ? void 0 : guards[guard.name]) || guard.predicate)(context, _event.data, guardMeta);
      }
      var condFn = guards === null || guards === void 0 ? void 0 : guards[guard.type];
      if (!condFn) {
        throw new Error("Guard '".concat(guard.type, "' is not implemented on machine '").concat(machine.id, "'."));
      }
      return condFn(context, _event.data, guardMeta);
    }
    function toInvokeSource3(src) {
      if (typeof src === "string") {
        return {
          type: src
        };
      }
      return src;
    }
    function toObserver3(nextHandler, errorHandler, completionHandler) {
      var noop3 = function() {
      };
      var isObserver = typeof nextHandler === "object";
      var self2 = isObserver ? nextHandler : null;
      return {
        next: ((isObserver ? nextHandler.next : nextHandler) || noop3).bind(self2),
        error: ((isObserver ? nextHandler.error : errorHandler) || noop3).bind(self2),
        complete: ((isObserver ? nextHandler.complete : completionHandler) || noop3).bind(self2)
      };
    }
    function createInvokeId2(stateNodeId, index2) {
      return "".concat(stateNodeId, ":invocation[").concat(index2, "]");
    }
    function isRaisableAction2(action) {
      return (action.type === actionTypes.raise || action.type === actionTypes.send && action.to === types.SpecialTargets.Internal) && typeof action.delay !== "number";
    }
    exports.createInvokeId = createInvokeId2;
    exports.evaluateGuard = evaluateGuard2;
    exports.flatten = flatten2;
    exports.getActionType = getActionType;
    exports.getEventType = getEventType2;
    exports.interopSymbols = interopSymbols2;
    exports.isActor = isActor3;
    exports.isArray = isArray2;
    exports.isBehavior = isBehavior2;
    exports.isBuiltInEvent = isBuiltInEvent2;
    exports.isFunction = isFunction2;
    exports.isMachine = isMachine2;
    exports.isObservable = isObservable2;
    exports.isPromiseLike = isPromiseLike2;
    exports.isRaisableAction = isRaisableAction2;
    exports.isStateLike = isStateLike2;
    exports.isString = isString2;
    exports.keys = keys;
    exports.mapContext = mapContext2;
    exports.mapFilterValues = mapFilterValues2;
    exports.mapValues = mapValues2;
    exports.matchesState = matchesState2;
    exports.nestedPath = nestedPath2;
    exports.normalizeTarget = normalizeTarget2;
    exports.partition = partition3;
    exports.path = path2;
    exports.pathToStateValue = pathToStateValue2;
    exports.pathsToStateValue = pathsToStateValue;
    exports.reportUnhandledExceptionOnInvocation = reportUnhandledExceptionOnInvocation2;
    exports.symbolObservable = symbolObservable2;
    exports.toArray = toArray3;
    exports.toArrayStrict = toArrayStrict2;
    exports.toEventObject = toEventObject2;
    exports.toGuard = toGuard2;
    exports.toInvokeSource = toInvokeSource3;
    exports.toObserver = toObserver3;
    exports.toSCXMLEvent = toSCXMLEvent2;
    exports.toStatePath = toStatePath2;
    exports.toStatePaths = toStatePaths2;
    exports.toStateValue = toStateValue2;
    exports.toTransitionConfigArray = toTransitionConfigArray2;
    exports.uniqueId = uniqueId2;
    exports.updateContext = updateContext2;
    exports.updateHistoryStates = updateHistoryStates2;
    exports.updateHistoryValue = updateHistoryValue2;
  }
});

// node_modules/xstate/lib/actions.js
var require_actions = __commonJS({
  "node_modules/xstate/lib/actions.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var _tslib = require_tslib();
    var types = require_types();
    var actionTypes = require_actionTypes();
    var utils = require_utils();
    var environment = require_environment();
    var initEvent2 = utils.toSCXMLEvent({
      type: actionTypes.init
    });
    function getActionFunction2(actionType, actionFunctionMap) {
      return actionFunctionMap ? actionFunctionMap[actionType] || void 0 : void 0;
    }
    function toActionObject2(action, actionFunctionMap) {
      var actionObject;
      if (utils.isString(action) || typeof action === "number") {
        var exec = getActionFunction2(action, actionFunctionMap);
        if (utils.isFunction(exec)) {
          actionObject = {
            type: action,
            exec
          };
        } else if (exec) {
          actionObject = exec;
        } else {
          actionObject = {
            type: action,
            exec: void 0
          };
        }
      } else if (utils.isFunction(action)) {
        actionObject = {
          // Convert action to string if unnamed
          type: action.name || action.toString(),
          exec: action
        };
      } else {
        var exec = getActionFunction2(action.type, actionFunctionMap);
        if (utils.isFunction(exec)) {
          actionObject = _tslib.__assign(_tslib.__assign({}, action), {
            exec
          });
        } else if (exec) {
          var actionType = exec.type || action.type;
          actionObject = _tslib.__assign(_tslib.__assign(_tslib.__assign({}, exec), action), {
            type: actionType
          });
        } else {
          actionObject = action;
        }
      }
      return actionObject;
    }
    var toActionObjects2 = function(action, actionFunctionMap) {
      if (!action) {
        return [];
      }
      var actions = utils.isArray(action) ? action : [action];
      return actions.map(function(subAction) {
        return toActionObject2(subAction, actionFunctionMap);
      });
    };
    function toActivityDefinition2(action) {
      var actionObject = toActionObject2(action);
      return _tslib.__assign(_tslib.__assign({
        id: utils.isString(action) ? action : actionObject.id
      }, actionObject), {
        type: actionObject.type
      });
    }
    function raise3(event2, options) {
      return {
        type: actionTypes.raise,
        event: typeof event2 === "function" ? event2 : utils.toEventObject(event2),
        delay: options ? options.delay : void 0,
        id: options === null || options === void 0 ? void 0 : options.id
      };
    }
    function resolveRaise2(action, ctx, _event, delaysMap) {
      var meta = {
        _event
      };
      var resolvedEvent = utils.toSCXMLEvent(utils.isFunction(action.event) ? action.event(ctx, _event.data, meta) : action.event);
      var resolvedDelay;
      if (utils.isString(action.delay)) {
        var configDelay = delaysMap && delaysMap[action.delay];
        resolvedDelay = utils.isFunction(configDelay) ? configDelay(ctx, _event.data, meta) : configDelay;
      } else {
        resolvedDelay = utils.isFunction(action.delay) ? action.delay(ctx, _event.data, meta) : action.delay;
      }
      return _tslib.__assign(_tslib.__assign({}, action), {
        type: actionTypes.raise,
        _event: resolvedEvent,
        delay: resolvedDelay
      });
    }
    function send3(event2, options) {
      return {
        to: options ? options.to : void 0,
        type: actionTypes.send,
        event: utils.isFunction(event2) ? event2 : utils.toEventObject(event2),
        delay: options ? options.delay : void 0,
        // TODO: don't auto-generate IDs here like that
        // there is too big chance of the ID collision
        id: options && options.id !== void 0 ? options.id : utils.isFunction(event2) ? event2.name : utils.getEventType(event2)
      };
    }
    function resolveSend2(action, ctx, _event, delaysMap) {
      var meta = {
        _event
      };
      var resolvedEvent = utils.toSCXMLEvent(utils.isFunction(action.event) ? action.event(ctx, _event.data, meta) : action.event);
      var resolvedDelay;
      if (utils.isString(action.delay)) {
        var configDelay = delaysMap && delaysMap[action.delay];
        resolvedDelay = utils.isFunction(configDelay) ? configDelay(ctx, _event.data, meta) : configDelay;
      } else {
        resolvedDelay = utils.isFunction(action.delay) ? action.delay(ctx, _event.data, meta) : action.delay;
      }
      var resolvedTarget = utils.isFunction(action.to) ? action.to(ctx, _event.data, meta) : action.to;
      return _tslib.__assign(_tslib.__assign({}, action), {
        to: resolvedTarget,
        _event: resolvedEvent,
        event: resolvedEvent.data,
        delay: resolvedDelay
      });
    }
    function sendParent2(event2, options) {
      return send3(event2, _tslib.__assign(_tslib.__assign({}, options), {
        to: types.SpecialTargets.Parent
      }));
    }
    function sendTo2(actor, event2, options) {
      return send3(event2, _tslib.__assign(_tslib.__assign({}, options), {
        to: actor
      }));
    }
    function sendUpdate2() {
      return sendParent2(actionTypes.update);
    }
    function respond(event2, options) {
      return send3(event2, _tslib.__assign(_tslib.__assign({}, options), {
        to: function(_, __, _a2) {
          var _event = _a2._event;
          return _event.origin;
        }
      }));
    }
    var defaultLogExpr = function(context, event2) {
      return {
        context,
        event: event2
      };
    };
    function log3(expr, label) {
      if (expr === void 0) {
        expr = defaultLogExpr;
      }
      return {
        type: actionTypes.log,
        label,
        expr
      };
    }
    var resolveLog2 = function(action, ctx, _event) {
      return _tslib.__assign(_tslib.__assign({}, action), {
        value: utils.isString(action.expr) ? action.expr : action.expr(ctx, _event.data, {
          _event
        })
      });
    };
    var cancel3 = function(sendId) {
      return {
        type: actionTypes.cancel,
        sendId
      };
    };
    function start4(activity) {
      var activityDef = toActivityDefinition2(activity);
      return {
        type: types.ActionTypes.Start,
        activity: activityDef,
        exec: void 0
      };
    }
    function stop4(actorRef) {
      var activity = utils.isFunction(actorRef) ? actorRef : toActivityDefinition2(actorRef);
      return {
        type: types.ActionTypes.Stop,
        activity,
        exec: void 0
      };
    }
    function resolveStop2(action, context, _event) {
      var actorRefOrString = utils.isFunction(action.activity) ? action.activity(context, _event.data) : action.activity;
      var resolvedActorRef = typeof actorRefOrString === "string" ? {
        id: actorRefOrString
      } : actorRefOrString;
      var actionObject = {
        type: types.ActionTypes.Stop,
        activity: resolvedActorRef
      };
      return actionObject;
    }
    var assign4 = function(assignment) {
      return {
        type: actionTypes.assign,
        assignment
      };
    };
    function isActionObject(action) {
      return typeof action === "object" && "type" in action;
    }
    function after3(delayRef, id) {
      var idSuffix = id ? "#".concat(id) : "";
      return "".concat(types.ActionTypes.After, "(").concat(delayRef, ")").concat(idSuffix);
    }
    function done2(id, data) {
      var type = "".concat(types.ActionTypes.DoneState, ".").concat(id);
      var eventObject = {
        type,
        data
      };
      eventObject.toString = function() {
        return type;
      };
      return eventObject;
    }
    function doneInvoke2(id, data) {
      var type = "".concat(types.ActionTypes.DoneInvoke, ".").concat(id);
      var eventObject = {
        type,
        data
      };
      eventObject.toString = function() {
        return type;
      };
      return eventObject;
    }
    function error3(id, data) {
      var type = "".concat(types.ActionTypes.ErrorPlatform, ".").concat(id);
      var eventObject = {
        type,
        data
      };
      eventObject.toString = function() {
        return type;
      };
      return eventObject;
    }
    function pure3(getActions) {
      return {
        type: types.ActionTypes.Pure,
        get: getActions
      };
    }
    function forwardTo2(target, options) {
      if (!environment.IS_PRODUCTION && (!target || typeof target === "function")) {
        var originalTarget_1 = target;
        target = function() {
          var args = [];
          for (var _i = 0; _i < arguments.length; _i++) {
            args[_i] = arguments[_i];
          }
          var resolvedTarget = typeof originalTarget_1 === "function" ? originalTarget_1.apply(void 0, _tslib.__spreadArray([], _tslib.__read(args), false)) : originalTarget_1;
          if (!resolvedTarget) {
            throw new Error("Attempted to forward event to undefined actor. This risks an infinite loop in the sender.");
          }
          return resolvedTarget;
        };
      }
      return send3(function(_, event2) {
        return event2;
      }, _tslib.__assign(_tslib.__assign({}, options), {
        to: target
      }));
    }
    function escalate(errorData, options) {
      return sendParent2(function(context, event2, meta) {
        return {
          type: actionTypes.error,
          data: utils.isFunction(errorData) ? errorData(context, event2, meta) : errorData
        };
      }, _tslib.__assign(_tslib.__assign({}, options), {
        to: types.SpecialTargets.Parent
      }));
    }
    function choose3(conds) {
      return {
        type: types.ActionTypes.Choose,
        conds
      };
    }
    var pluckAssigns2 = function(actionBlocks) {
      var e_1, _a2;
      var assignActions = [];
      try {
        for (var actionBlocks_1 = _tslib.__values(actionBlocks), actionBlocks_1_1 = actionBlocks_1.next(); !actionBlocks_1_1.done; actionBlocks_1_1 = actionBlocks_1.next()) {
          var block = actionBlocks_1_1.value;
          var i2 = 0;
          while (i2 < block.actions.length) {
            if (block.actions[i2].type === actionTypes.assign) {
              assignActions.push(block.actions[i2]);
              block.actions.splice(i2, 1);
              continue;
            }
            i2++;
          }
        }
      } catch (e_1_1) {
        e_1 = {
          error: e_1_1
        };
      } finally {
        try {
          if (actionBlocks_1_1 && !actionBlocks_1_1.done && (_a2 = actionBlocks_1.return)) _a2.call(actionBlocks_1);
        } finally {
          if (e_1) throw e_1.error;
        }
      }
      return assignActions;
    };
    function resolveActions2(machine, currentState, currentContext, _event, actionBlocks, predictableExec, preserveActionOrder) {
      if (preserveActionOrder === void 0) {
        preserveActionOrder = false;
      }
      var assignActions = preserveActionOrder ? [] : pluckAssigns2(actionBlocks);
      var updatedContext = assignActions.length ? utils.updateContext(currentContext, _event, assignActions, currentState) : currentContext;
      var preservedContexts = preserveActionOrder ? [currentContext] : void 0;
      var deferredToBlockEnd = [];
      function handleAction(blockType, actionObject) {
        var _a2;
        switch (actionObject.type) {
          case actionTypes.raise: {
            var raisedAction = resolveRaise2(actionObject, updatedContext, _event, machine.options.delays);
            if (predictableExec && typeof raisedAction.delay === "number") {
              predictableExec(raisedAction, updatedContext, _event);
            }
            return raisedAction;
          }
          case actionTypes.send:
            var sendAction = resolveSend2(actionObject, updatedContext, _event, machine.options.delays);
            if (!environment.IS_PRODUCTION) {
              var configuredDelay = actionObject.delay;
              utils.warn(
                !utils.isString(configuredDelay) || typeof sendAction.delay === "number",
                // tslint:disable-next-line:max-line-length
                "No delay reference for delay expression '".concat(configuredDelay, "' was found on machine '").concat(machine.id, "'")
              );
            }
            if (predictableExec && sendAction.to !== types.SpecialTargets.Internal) {
              if (blockType === "entry") {
                deferredToBlockEnd.push(sendAction);
              } else {
                predictableExec(sendAction, updatedContext, _event);
              }
            }
            return sendAction;
          case actionTypes.log: {
            var resolved = resolveLog2(actionObject, updatedContext, _event);
            predictableExec === null || predictableExec === void 0 ? void 0 : predictableExec(resolved, updatedContext, _event);
            return resolved;
          }
          case actionTypes.choose: {
            var chooseAction = actionObject;
            var matchedActions = (_a2 = chooseAction.conds.find(function(condition) {
              var guard = utils.toGuard(condition.cond, machine.options.guards);
              return !guard || utils.evaluateGuard(machine, guard, updatedContext, _event, !predictableExec ? currentState : void 0);
            })) === null || _a2 === void 0 ? void 0 : _a2.actions;
            if (!matchedActions) {
              return [];
            }
            var _b = _tslib.__read(resolveActions2(machine, currentState, updatedContext, _event, [{
              type: blockType,
              actions: toActionObjects2(utils.toArray(matchedActions), machine.options.actions)
            }], predictableExec, preserveActionOrder), 2), resolvedActionsFromChoose = _b[0], resolvedContextFromChoose = _b[1];
            updatedContext = resolvedContextFromChoose;
            preservedContexts === null || preservedContexts === void 0 ? void 0 : preservedContexts.push(updatedContext);
            return resolvedActionsFromChoose;
          }
          case actionTypes.pure: {
            var matchedActions = actionObject.get(updatedContext, _event.data);
            if (!matchedActions) {
              return [];
            }
            var _c = _tslib.__read(resolveActions2(machine, currentState, updatedContext, _event, [{
              type: blockType,
              actions: toActionObjects2(utils.toArray(matchedActions), machine.options.actions)
            }], predictableExec, preserveActionOrder), 2), resolvedActionsFromPure = _c[0], resolvedContext = _c[1];
            updatedContext = resolvedContext;
            preservedContexts === null || preservedContexts === void 0 ? void 0 : preservedContexts.push(updatedContext);
            return resolvedActionsFromPure;
          }
          case actionTypes.stop: {
            var resolved = resolveStop2(actionObject, updatedContext, _event);
            predictableExec === null || predictableExec === void 0 ? void 0 : predictableExec(resolved, currentContext, _event);
            return resolved;
          }
          case actionTypes.assign: {
            updatedContext = utils.updateContext(updatedContext, _event, [actionObject], !predictableExec ? currentState : void 0);
            preservedContexts === null || preservedContexts === void 0 ? void 0 : preservedContexts.push(updatedContext);
            break;
          }
          default:
            var resolvedActionObject = toActionObject2(actionObject, machine.options.actions);
            var exec_1 = resolvedActionObject.exec;
            if (predictableExec) {
              predictableExec(resolvedActionObject, updatedContext, _event);
            } else if (exec_1 && preservedContexts) {
              var contextIndex_1 = preservedContexts.length - 1;
              var wrapped = _tslib.__assign(_tslib.__assign({}, resolvedActionObject), {
                exec: function(_ctx) {
                  var args = [];
                  for (var _i = 1; _i < arguments.length; _i++) {
                    args[_i - 1] = arguments[_i];
                  }
                  exec_1.apply(void 0, _tslib.__spreadArray([preservedContexts[contextIndex_1]], _tslib.__read(args), false));
                }
              });
              resolvedActionObject = wrapped;
            }
            return resolvedActionObject;
        }
      }
      function processBlock(block) {
        var e_2, _a2;
        var resolvedActions2 = [];
        try {
          for (var _b = _tslib.__values(block.actions), _c = _b.next(); !_c.done; _c = _b.next()) {
            var action = _c.value;
            var resolved = handleAction(block.type, action);
            if (resolved) {
              resolvedActions2 = resolvedActions2.concat(resolved);
            }
          }
        } catch (e_2_1) {
          e_2 = {
            error: e_2_1
          };
        } finally {
          try {
            if (_c && !_c.done && (_a2 = _b.return)) _a2.call(_b);
          } finally {
            if (e_2) throw e_2.error;
          }
        }
        deferredToBlockEnd.forEach(function(action2) {
          predictableExec(action2, updatedContext, _event);
        });
        deferredToBlockEnd.length = 0;
        return resolvedActions2;
      }
      var resolvedActions = utils.flatten(actionBlocks.map(processBlock));
      return [resolvedActions, updatedContext];
    }
    exports.actionTypes = actionTypes;
    exports.after = after3;
    exports.assign = assign4;
    exports.cancel = cancel3;
    exports.choose = choose3;
    exports.done = done2;
    exports.doneInvoke = doneInvoke2;
    exports.error = error3;
    exports.escalate = escalate;
    exports.forwardTo = forwardTo2;
    exports.getActionFunction = getActionFunction2;
    exports.initEvent = initEvent2;
    exports.isActionObject = isActionObject;
    exports.log = log3;
    exports.pure = pure3;
    exports.raise = raise3;
    exports.resolveActions = resolveActions2;
    exports.resolveLog = resolveLog2;
    exports.resolveRaise = resolveRaise2;
    exports.resolveSend = resolveSend2;
    exports.resolveStop = resolveStop2;
    exports.respond = respond;
    exports.send = send3;
    exports.sendParent = sendParent2;
    exports.sendTo = sendTo2;
    exports.sendUpdate = sendUpdate2;
    exports.start = start4;
    exports.stop = stop4;
    exports.toActionObject = toActionObject2;
    exports.toActionObjects = toActionObjects2;
    exports.toActivityDefinition = toActivityDefinition2;
  }
});

// node_modules/xstate/lib/serviceScope.js
var require_serviceScope = __commonJS({
  "node_modules/xstate/lib/serviceScope.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var serviceStack2 = [];
    var provide2 = function(service, fn) {
      serviceStack2.push(service);
      var result = fn(service);
      serviceStack2.pop();
      return result;
    };
    var consume2 = function(fn) {
      return fn(serviceStack2[serviceStack2.length - 1]);
    };
    exports.consume = consume2;
    exports.provide = provide2;
  }
});

// node_modules/xstate/lib/Actor.js
var require_Actor = __commonJS({
  "node_modules/xstate/lib/Actor.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var _tslib = require_tslib();
    var utils = require_utils();
    var serviceScope = require_serviceScope();
    function createNullActor2(id) {
      var _a2;
      return _a2 = {
        id,
        send: function() {
          return void 0;
        },
        subscribe: function() {
          return {
            unsubscribe: function() {
              return void 0;
            }
          };
        },
        getSnapshot: function() {
          return void 0;
        },
        toJSON: function() {
          return {
            id
          };
        }
      }, _a2[utils.symbolObservable] = function() {
        return this;
      }, _a2;
    }
    function createInvocableActor2(invokeDefinition, machine, context, _event) {
      var _a2;
      var invokeSrc = utils.toInvokeSource(invokeDefinition.src);
      var serviceCreator = (_a2 = machine === null || machine === void 0 ? void 0 : machine.options.services) === null || _a2 === void 0 ? void 0 : _a2[invokeSrc.type];
      var resolvedData = invokeDefinition.data ? utils.mapContext(invokeDefinition.data, context, _event) : void 0;
      var tempActor = serviceCreator ? createDeferredActor2(serviceCreator, invokeDefinition.id, resolvedData) : createNullActor2(invokeDefinition.id);
      tempActor.meta = invokeDefinition;
      return tempActor;
    }
    function createDeferredActor2(entity, id, data) {
      var tempActor = createNullActor2(id);
      tempActor.deferred = true;
      if (utils.isMachine(entity)) {
        var initialState_1 = tempActor.state = serviceScope.provide(void 0, function() {
          return (data ? entity.withContext(data) : entity).initialState;
        });
        tempActor.getSnapshot = function() {
          return initialState_1;
        };
      }
      return tempActor;
    }
    function isActor3(item) {
      try {
        return typeof item.send === "function";
      } catch (e) {
        return false;
      }
    }
    function isSpawnedActor2(item) {
      return isActor3(item) && "id" in item;
    }
    function toActorRef2(actorRefLike) {
      var _a2;
      return _tslib.__assign((_a2 = {
        subscribe: function() {
          return {
            unsubscribe: function() {
              return void 0;
            }
          };
        },
        id: "anonymous",
        getSnapshot: function() {
          return void 0;
        }
      }, _a2[utils.symbolObservable] = function() {
        return this;
      }, _a2), actorRefLike);
    }
    exports.createDeferredActor = createDeferredActor2;
    exports.createInvocableActor = createInvocableActor2;
    exports.createNullActor = createNullActor2;
    exports.isActor = isActor3;
    exports.isSpawnedActor = isSpawnedActor2;
    exports.toActorRef = toActorRef2;
  }
});

// node_modules/xstate/lib/behaviors.js
var require_behaviors = __commonJS({
  "node_modules/xstate/lib/behaviors.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var actions = require_actions();
    var Actor = require_Actor();
    var utils = require_utils();
    function fromReducer(transition, initialState) {
      return {
        transition,
        initialState
      };
    }
    function fromPromise(promiseFn) {
      var initialState = {
        error: void 0,
        data: void 0,
        status: "pending"
      };
      return {
        transition: function(state, event2, _a2) {
          var parent = _a2.parent, id = _a2.id, observers = _a2.observers;
          switch (event2.type) {
            case "fulfill":
              parent === null || parent === void 0 ? void 0 : parent.send(actions.doneInvoke(id, event2.data));
              return {
                error: void 0,
                data: event2.data,
                status: "fulfilled"
              };
            case "reject":
              parent === null || parent === void 0 ? void 0 : parent.send(actions.error(id, event2.error));
              observers.forEach(function(observer) {
                observer.error(event2.error);
              });
              return {
                error: event2.error,
                data: void 0,
                status: "rejected"
              };
            default:
              return state;
          }
        },
        initialState,
        start: function(_a2) {
          var self2 = _a2.self;
          promiseFn().then(function(data) {
            self2.send({
              type: "fulfill",
              data
            });
          }, function(reason) {
            self2.send({
              type: "reject",
              error: reason
            });
          });
          return initialState;
        }
      };
    }
    function spawnBehavior3(behavior, options) {
      if (options === void 0) {
        options = {};
      }
      var state = behavior.initialState;
      var observers = /* @__PURE__ */ new Set();
      var mailbox = [];
      var flushing = false;
      var flush = function() {
        if (flushing) {
          return;
        }
        flushing = true;
        while (mailbox.length > 0) {
          var event_1 = mailbox.shift();
          state = behavior.transition(state, event_1, actorCtx);
          observers.forEach(function(observer) {
            return observer.next(state);
          });
        }
        flushing = false;
      };
      var actor = Actor.toActorRef({
        id: options.id,
        send: function(event2) {
          mailbox.push(event2);
          flush();
        },
        getSnapshot: function() {
          return state;
        },
        subscribe: function(next, handleError, complete) {
          var observer = utils.toObserver(next, handleError, complete);
          observers.add(observer);
          observer.next(state);
          return {
            unsubscribe: function() {
              observers.delete(observer);
            }
          };
        }
      });
      var actorCtx = {
        parent: options.parent,
        self: actor,
        id: options.id || "anonymous",
        observers
      };
      state = behavior.start ? behavior.start(actorCtx) : state;
      return actor;
    }
    exports.fromPromise = fromPromise;
    exports.fromReducer = fromReducer;
    exports.spawnBehavior = spawnBehavior3;
  }
});

// node_modules/react-spring-bottom-sheet/node_modules/@reach/portal/dist/reach-portal.esm.js
var import_react2 = __toESM(require_react());

// node_modules/react-spring-bottom-sheet/node_modules/@reach/portal/node_modules/@reach/utils/dist/reach-utils.esm.js
var React = __toESM(require_react());
var import_react = __toESM(require_react());
var import_warning = __toESM(require_warning());
var useIsomorphicLayoutEffect = canUseDOM() ? import_react.useLayoutEffect : import_react.useEffect;
var checkedPkgs = {};
var checkStyles = noop;
if (true) {
  _ref = typeof process !== "undefined" ? process : {
    env: {
      NODE_ENV: "development"
    }
  }, env = _ref.env;
  checkStyles = function checkStyles2(packageName) {
    if (checkedPkgs[packageName]) return;
    checkedPkgs[packageName] = true;
    if (env.NODE_ENV !== "test" && parseInt(window.getComputedStyle(document.body).getPropertyValue("--reach-" + packageName), 10) !== 1) {
      console.warn("@reach/" + packageName + ' styles not found. If you are using a bundler like webpack or parcel include this in the entry file of your app before any of your own styles:\n\n    import "@reach/' + packageName + `/styles.css";

  Otherwise you'll need to include them some other way:

    <link rel="stylesheet" type="text/css" href="node_modules/@reach/` + packageName + '/styles.css" />\n\n  For more information visit https://ui.reach.tech/styling.\n  ');
    }
  };
}
var _ref;
var env;
var ponyfillGlobal = typeof window != "undefined" && window.Math == Math ? window : typeof self != "undefined" && self.Math == Math ? self : (
  // eslint-disable-next-line no-new-func
  Function("return this")()
);
function canUseDOM() {
  return !!(typeof window !== "undefined" && window.document && window.document.createElement);
}
function noop() {
}
var useControlledSwitchWarning = noop;
if (true) {
  useControlledSwitchWarning = function useControlledSwitchWarning2(controlledValue, controlledPropName, componentName) {
    var controlledRef = (0, import_react.useRef)(controlledValue != null);
    var nameCache = (0, import_react.useRef)({
      componentName,
      controlledPropName
    });
    (0, import_react.useEffect)(function() {
      nameCache.current = {
        componentName,
        controlledPropName
      };
    }, [componentName, controlledPropName]);
    (0, import_react.useEffect)(function() {
      var wasControlled = controlledRef.current;
      var _nameCache$current = nameCache.current, componentName2 = _nameCache$current.componentName, controlledPropName2 = _nameCache$current.controlledPropName;
      var isControlled = controlledValue != null;
      if (wasControlled !== isControlled) {
        console.error("A component is changing an " + (wasControlled ? "" : "un") + "controlled `" + controlledPropName2 + "` state of " + componentName2 + " to be " + (wasControlled ? "un" : "") + "controlled. This is likely caused by the value changing from undefined to a defined value, which should not happen. Decide between using a controlled or uncontrolled " + componentName2 + " element for the lifetime of the component.\nMore info: https://fb.me/react-controlled-components");
      }
    }, [controlledValue]);
  };
}
var useCheckStyles = noop;
if (true) {
  useCheckStyles = function useCheckStyles2(pkg) {
    var name = (0, import_react.useRef)(pkg);
    (0, import_react.useEffect)(function() {
      return void (name.current = pkg);
    }, [pkg]);
    (0, import_react.useEffect)(function() {
      return checkStyles(name.current);
    }, []);
  };
}
function useForceUpdate() {
  var _React$useState2 = (0, import_react.useState)(/* @__PURE__ */ Object.create(null)), dispatch = _React$useState2[1];
  return (0, import_react.useCallback)(function() {
    dispatch(/* @__PURE__ */ Object.create(null));
  }, []);
}
var useStateLogger = noop;
if (true) {
  useStateLogger = function useStateLogger2(state, DEBUG) {
    if (DEBUG === void 0) {
      DEBUG = false;
    }
    var debugRef = (0, import_react.useRef)(DEBUG);
    (0, import_react.useEffect)(function() {
      debugRef.current = DEBUG;
    }, [DEBUG]);
    (0, import_react.useEffect)(function() {
      if (debugRef.current) {
        console.group("State Updated");
        console.log("%c" + state, "font-weight: normal; font-size: 120%; font-style: italic;");
        console.groupEnd();
      }
    }, [state]);
  };
}

// node_modules/react-spring-bottom-sheet/node_modules/@reach/portal/dist/reach-portal.esm.js
var import_react_dom = __toESM(require_react_dom());
var Portal = function Portal2(_ref) {
  var children2 = _ref.children, _ref$type = _ref.type, type = _ref$type === void 0 ? "reach-portal" : _ref$type;
  var mountNode = (0, import_react2.useRef)(null);
  var portalNode = (0, import_react2.useRef)(null);
  var forceUpdate = useForceUpdate();
  useIsomorphicLayoutEffect(function() {
    if (!mountNode.current) return;
    var ownerDocument = mountNode.current.ownerDocument;
    portalNode.current = ownerDocument == null ? void 0 : ownerDocument.createElement(type);
    ownerDocument.body.appendChild(portalNode.current);
    forceUpdate();
    return function() {
      if (portalNode.current && portalNode.current.ownerDocument) {
        portalNode.current.ownerDocument.body.removeChild(portalNode.current);
      }
    };
  }, [type, forceUpdate]);
  return portalNode.current ? (0, import_react_dom.createPortal)(children2, portalNode.current) : (0, import_react2.createElement)("span", {
    ref: mountNode
  });
};
if (true) {
  Portal.displayName = "Portal";
}
var reach_portal_esm_default = Portal;

// node_modules/react-spring-bottom-sheet/dist/index.es.js
var import_react11 = __toESM(require_react());

// node_modules/react-spring-bottom-sheet/node_modules/@xstate/react/es/useMachine.js
var import_react6 = __toESM(require_react());

// node_modules/xstate/es/_virtual/_tslib.js
var __assign = function() {
  __assign = Object.assign || function __assign3(t3) {
    for (var s2, i2 = 1, n2 = arguments.length; i2 < n2; i2++) {
      s2 = arguments[i2];
      for (var p in s2) if (Object.prototype.hasOwnProperty.call(s2, p)) t3[p] = s2[p];
    }
    return t3;
  };
  return __assign.apply(this, arguments);
};
function __rest(s2, e) {
  var t3 = {};
  for (var p in s2) if (Object.prototype.hasOwnProperty.call(s2, p) && e.indexOf(p) < 0)
    t3[p] = s2[p];
  if (s2 != null && typeof Object.getOwnPropertySymbols === "function")
    for (var i2 = 0, p = Object.getOwnPropertySymbols(s2); i2 < p.length; i2++) {
      if (e.indexOf(p[i2]) < 0 && Object.prototype.propertyIsEnumerable.call(s2, p[i2]))
        t3[p[i2]] = s2[p[i2]];
    }
  return t3;
}
function __values(o2) {
  var s2 = typeof Symbol === "function" && Symbol.iterator, m = s2 && o2[s2], i2 = 0;
  if (m) return m.call(o2);
  if (o2 && typeof o2.length === "number") return {
    next: function() {
      if (o2 && i2 >= o2.length) o2 = void 0;
      return { value: o2 && o2[i2++], done: !o2 };
    }
  };
  throw new TypeError(s2 ? "Object is not iterable." : "Symbol.iterator is not defined.");
}
function __read(o2, n2) {
  var m = typeof Symbol === "function" && o2[Symbol.iterator];
  if (!m) return o2;
  var i2 = m.call(o2), r2, ar = [], e;
  try {
    while ((n2 === void 0 || n2-- > 0) && !(r2 = i2.next()).done) ar.push(r2.value);
  } catch (error3) {
    e = { error: error3 };
  } finally {
    try {
      if (r2 && !r2.done && (m = i2["return"])) m.call(i2);
    } finally {
      if (e) throw e.error;
    }
  }
  return ar;
}
function __spreadArray(to, from, pack) {
  if (pack || arguments.length === 2) for (var i2 = 0, l2 = from.length, ar; i2 < l2; i2++) {
    if (ar || !(i2 in from)) {
      if (!ar) ar = Array.prototype.slice.call(from, 0, i2);
      ar[i2] = from[i2];
    }
  }
  return to.concat(ar || Array.prototype.slice.call(from));
}

// node_modules/xstate/es/types.js
var ActionTypes;
(function(ActionTypes2) {
  ActionTypes2["Start"] = "xstate.start";
  ActionTypes2["Stop"] = "xstate.stop";
  ActionTypes2["Raise"] = "xstate.raise";
  ActionTypes2["Send"] = "xstate.send";
  ActionTypes2["Cancel"] = "xstate.cancel";
  ActionTypes2["NullEvent"] = "";
  ActionTypes2["Assign"] = "xstate.assign";
  ActionTypes2["After"] = "xstate.after";
  ActionTypes2["DoneState"] = "done.state";
  ActionTypes2["DoneInvoke"] = "done.invoke";
  ActionTypes2["Log"] = "xstate.log";
  ActionTypes2["Init"] = "xstate.init";
  ActionTypes2["Invoke"] = "xstate.invoke";
  ActionTypes2["ErrorExecution"] = "error.execution";
  ActionTypes2["ErrorCommunication"] = "error.communication";
  ActionTypes2["ErrorPlatform"] = "error.platform";
  ActionTypes2["ErrorCustom"] = "xstate.error";
  ActionTypes2["Update"] = "xstate.update";
  ActionTypes2["Pure"] = "xstate.pure";
  ActionTypes2["Choose"] = "xstate.choose";
})(ActionTypes || (ActionTypes = {}));
var SpecialTargets;
(function(SpecialTargets2) {
  SpecialTargets2["Parent"] = "#_parent";
  SpecialTargets2["Internal"] = "#_internal";
})(SpecialTargets || (SpecialTargets = {}));

// node_modules/xstate/es/actionTypes.js
var start = ActionTypes.Start;
var stop = ActionTypes.Stop;
var raise = ActionTypes.Raise;
var send = ActionTypes.Send;
var cancel = ActionTypes.Cancel;
var nullEvent = ActionTypes.NullEvent;
var assign = ActionTypes.Assign;
var after = ActionTypes.After;
var doneState = ActionTypes.DoneState;
var log = ActionTypes.Log;
var init = ActionTypes.Init;
var invoke = ActionTypes.Invoke;
var errorExecution = ActionTypes.ErrorExecution;
var errorPlatform = ActionTypes.ErrorPlatform;
var error = ActionTypes.ErrorCustom;
var update = ActionTypes.Update;
var choose = ActionTypes.Choose;
var pure = ActionTypes.Pure;

// node_modules/xstate/es/constants.js
var STATE_DELIMITER = ".";
var EMPTY_ACTIVITY_MAP = {};
var DEFAULT_GUARD_TYPE = "xstate.guard";
var TARGETLESS_KEY = "";

// node_modules/xstate/es/environment.js
var IS_PRODUCTION = false;

// node_modules/xstate/es/utils.js
var _a;
function matchesState(parentStateId, childStateId, delimiter) {
  if (delimiter === void 0) {
    delimiter = STATE_DELIMITER;
  }
  var parentStateValue = toStateValue(parentStateId, delimiter);
  var childStateValue = toStateValue(childStateId, delimiter);
  if (isString(childStateValue)) {
    if (isString(parentStateValue)) {
      return childStateValue === parentStateValue;
    }
    return false;
  }
  if (isString(parentStateValue)) {
    return parentStateValue in childStateValue;
  }
  return Object.keys(parentStateValue).every(function(key) {
    if (!(key in childStateValue)) {
      return false;
    }
    return matchesState(parentStateValue[key], childStateValue[key]);
  });
}
function getEventType(event2) {
  try {
    return isString(event2) || typeof event2 === "number" ? "".concat(event2) : event2.type;
  } catch (e) {
    throw new Error("Events must be strings or objects with a string event.type property.");
  }
}
function toStatePath(stateId, delimiter) {
  try {
    if (isArray(stateId)) {
      return stateId;
    }
    return stateId.toString().split(delimiter);
  } catch (e) {
    throw new Error("'".concat(stateId, "' is not a valid state path."));
  }
}
function isStateLike(state) {
  return typeof state === "object" && "value" in state && "context" in state && "event" in state && "_event" in state;
}
function toStateValue(stateValue, delimiter) {
  if (isStateLike(stateValue)) {
    return stateValue.value;
  }
  if (isArray(stateValue)) {
    return pathToStateValue(stateValue);
  }
  if (typeof stateValue !== "string") {
    return stateValue;
  }
  var statePath = toStatePath(stateValue, delimiter);
  return pathToStateValue(statePath);
}
function pathToStateValue(statePath) {
  if (statePath.length === 1) {
    return statePath[0];
  }
  var value = {};
  var marker = value;
  for (var i2 = 0; i2 < statePath.length - 1; i2++) {
    if (i2 === statePath.length - 2) {
      marker[statePath[i2]] = statePath[i2 + 1];
    } else {
      marker[statePath[i2]] = {};
      marker = marker[statePath[i2]];
    }
  }
  return value;
}
function mapValues(collection, iteratee) {
  var result = {};
  var collectionKeys = Object.keys(collection);
  for (var i2 = 0; i2 < collectionKeys.length; i2++) {
    var key = collectionKeys[i2];
    result[key] = iteratee(collection[key], key, collection, i2);
  }
  return result;
}
function mapFilterValues(collection, iteratee, predicate) {
  var e_1, _a2;
  var result = {};
  try {
    for (var _b = __values(Object.keys(collection)), _c = _b.next(); !_c.done; _c = _b.next()) {
      var key = _c.value;
      var item = collection[key];
      if (!predicate(item)) {
        continue;
      }
      result[key] = iteratee(item, key, collection);
    }
  } catch (e_1_1) {
    e_1 = {
      error: e_1_1
    };
  } finally {
    try {
      if (_c && !_c.done && (_a2 = _b.return)) _a2.call(_b);
    } finally {
      if (e_1) throw e_1.error;
    }
  }
  return result;
}
var path = function(props) {
  return function(object) {
    var e_2, _a2;
    var result = object;
    try {
      for (var props_1 = __values(props), props_1_1 = props_1.next(); !props_1_1.done; props_1_1 = props_1.next()) {
        var prop = props_1_1.value;
        result = result[prop];
      }
    } catch (e_2_1) {
      e_2 = {
        error: e_2_1
      };
    } finally {
      try {
        if (props_1_1 && !props_1_1.done && (_a2 = props_1.return)) _a2.call(props_1);
      } finally {
        if (e_2) throw e_2.error;
      }
    }
    return result;
  };
};
function nestedPath(props, accessorProp) {
  return function(object) {
    var e_3, _a2;
    var result = object;
    try {
      for (var props_2 = __values(props), props_2_1 = props_2.next(); !props_2_1.done; props_2_1 = props_2.next()) {
        var prop = props_2_1.value;
        result = result[accessorProp][prop];
      }
    } catch (e_3_1) {
      e_3 = {
        error: e_3_1
      };
    } finally {
      try {
        if (props_2_1 && !props_2_1.done && (_a2 = props_2.return)) _a2.call(props_2);
      } finally {
        if (e_3) throw e_3.error;
      }
    }
    return result;
  };
}
function toStatePaths(stateValue) {
  if (!stateValue) {
    return [[]];
  }
  if (isString(stateValue)) {
    return [[stateValue]];
  }
  var result = flatten(Object.keys(stateValue).map(function(key) {
    var subStateValue = stateValue[key];
    if (typeof subStateValue !== "string" && (!subStateValue || !Object.keys(subStateValue).length)) {
      return [[key]];
    }
    return toStatePaths(stateValue[key]).map(function(subPath) {
      return [key].concat(subPath);
    });
  }));
  return result;
}
function flatten(array) {
  var _a2;
  return (_a2 = []).concat.apply(_a2, __spreadArray([], __read(array), false));
}
function toArrayStrict(value) {
  if (isArray(value)) {
    return value;
  }
  return [value];
}
function toArray(value) {
  if (value === void 0) {
    return [];
  }
  return toArrayStrict(value);
}
function mapContext(mapper, context, _event) {
  var e_5, _a2;
  if (isFunction(mapper)) {
    return mapper(context, _event.data);
  }
  var result = {};
  try {
    for (var _b = __values(Object.keys(mapper)), _c = _b.next(); !_c.done; _c = _b.next()) {
      var key = _c.value;
      var subMapper = mapper[key];
      if (isFunction(subMapper)) {
        result[key] = subMapper(context, _event.data);
      } else {
        result[key] = subMapper;
      }
    }
  } catch (e_5_1) {
    e_5 = {
      error: e_5_1
    };
  } finally {
    try {
      if (_c && !_c.done && (_a2 = _b.return)) _a2.call(_b);
    } finally {
      if (e_5) throw e_5.error;
    }
  }
  return result;
}
function isBuiltInEvent(eventType) {
  return /^(done|error)\./.test(eventType);
}
function isPromiseLike(value) {
  if (value instanceof Promise) {
    return true;
  }
  if (value !== null && (isFunction(value) || typeof value === "object") && isFunction(value.then)) {
    return true;
  }
  return false;
}
function isBehavior(value) {
  return value !== null && typeof value === "object" && "transition" in value && typeof value.transition === "function";
}
function partition(items, predicate) {
  var e_6, _a2;
  var _b = __read([[], []], 2), truthy = _b[0], falsy = _b[1];
  try {
    for (var items_1 = __values(items), items_1_1 = items_1.next(); !items_1_1.done; items_1_1 = items_1.next()) {
      var item = items_1_1.value;
      if (predicate(item)) {
        truthy.push(item);
      } else {
        falsy.push(item);
      }
    }
  } catch (e_6_1) {
    e_6 = {
      error: e_6_1
    };
  } finally {
    try {
      if (items_1_1 && !items_1_1.done && (_a2 = items_1.return)) _a2.call(items_1);
    } finally {
      if (e_6) throw e_6.error;
    }
  }
  return [truthy, falsy];
}
function updateHistoryStates(hist, stateValue) {
  return mapValues(hist.states, function(subHist, key) {
    if (!subHist) {
      return void 0;
    }
    var subStateValue = (isString(stateValue) ? void 0 : stateValue[key]) || (subHist ? subHist.current : void 0);
    if (!subStateValue) {
      return void 0;
    }
    return {
      current: subStateValue,
      states: updateHistoryStates(subHist, subStateValue)
    };
  });
}
function updateHistoryValue(hist, stateValue) {
  return {
    current: stateValue,
    states: updateHistoryStates(hist, stateValue)
  };
}
function updateContext(context, _event, assignActions, state) {
  if (!IS_PRODUCTION) {
    warn(!!context, "Attempting to update undefined context");
  }
  var updatedContext = context ? assignActions.reduce(function(acc, assignAction) {
    var e_7, _a2;
    var assignment = assignAction.assignment;
    var meta = {
      state,
      action: assignAction,
      _event
    };
    var partialUpdate = {};
    if (isFunction(assignment)) {
      partialUpdate = assignment(acc, _event.data, meta);
    } else {
      try {
        for (var _b = __values(Object.keys(assignment)), _c = _b.next(); !_c.done; _c = _b.next()) {
          var key = _c.value;
          var propAssignment = assignment[key];
          partialUpdate[key] = isFunction(propAssignment) ? propAssignment(acc, _event.data, meta) : propAssignment;
        }
      } catch (e_7_1) {
        e_7 = {
          error: e_7_1
        };
      } finally {
        try {
          if (_c && !_c.done && (_a2 = _b.return)) _a2.call(_b);
        } finally {
          if (e_7) throw e_7.error;
        }
      }
    }
    return Object.assign({}, acc, partialUpdate);
  }, context) : context;
  return updatedContext;
}
var warn = function() {
};
if (!IS_PRODUCTION) {
  warn = function(condition, message) {
    var error3 = condition instanceof Error ? condition : void 0;
    if (!error3 && condition) {
      return;
    }
    if (console !== void 0) {
      var args = ["Warning: ".concat(message)];
      if (error3) {
        args.push(error3);
      }
      console.warn.apply(console, args);
    }
  };
}
function isArray(value) {
  return Array.isArray(value);
}
function isFunction(value) {
  return typeof value === "function";
}
function isString(value) {
  return typeof value === "string";
}
function toGuard(condition, guardMap) {
  if (!condition) {
    return void 0;
  }
  if (isString(condition)) {
    return {
      type: DEFAULT_GUARD_TYPE,
      name: condition,
      predicate: guardMap ? guardMap[condition] : void 0
    };
  }
  if (isFunction(condition)) {
    return {
      type: DEFAULT_GUARD_TYPE,
      name: condition.name,
      predicate: condition
    };
  }
  return condition;
}
function isObservable(value) {
  try {
    return "subscribe" in value && isFunction(value.subscribe);
  } catch (e) {
    return false;
  }
}
var symbolObservable = function() {
  return typeof Symbol === "function" && Symbol.observable || "@@observable";
}();
var interopSymbols = (_a = {}, _a[symbolObservable] = function() {
  return this;
}, _a[Symbol.observable] = function() {
  return this;
}, _a);
function isMachine(value) {
  return !!value && "__xstatenode" in value;
}
function isActor(value) {
  return !!value && typeof value.send === "function";
}
function toEventObject(event2, payload) {
  if (isString(event2) || typeof event2 === "number") {
    return __assign({
      type: event2
    }, payload);
  }
  return event2;
}
function toSCXMLEvent(event2, scxmlEvent) {
  if (!isString(event2) && "$$type" in event2 && event2.$$type === "scxml") {
    return event2;
  }
  var eventObject = toEventObject(event2);
  return __assign({
    name: eventObject.type,
    data: eventObject,
    $$type: "scxml",
    type: "external"
  }, scxmlEvent);
}
function toTransitionConfigArray(event2, configLike) {
  var transitions = toArrayStrict(configLike).map(function(transitionLike) {
    if (typeof transitionLike === "undefined" || typeof transitionLike === "string" || isMachine(transitionLike)) {
      return {
        target: transitionLike,
        event: event2
      };
    }
    return __assign(__assign({}, transitionLike), {
      event: event2
    });
  });
  return transitions;
}
function normalizeTarget(target) {
  if (target === void 0 || target === TARGETLESS_KEY) {
    return void 0;
  }
  return toArray(target);
}
function reportUnhandledExceptionOnInvocation(originalError, currentError, id) {
  if (!IS_PRODUCTION) {
    var originalStackTrace = originalError.stack ? " Stacktrace was '".concat(originalError.stack, "'") : "";
    if (originalError === currentError) {
      console.error("Missing onError handler for invocation '".concat(id, "', error was '").concat(originalError, "'.").concat(originalStackTrace));
    } else {
      var stackTrace = currentError.stack ? " Stacktrace was '".concat(currentError.stack, "'") : "";
      console.error("Missing onError handler and/or unhandled exception/promise rejection for invocation '".concat(id, "'. ") + "Original error: '".concat(originalError, "'. ").concat(originalStackTrace, " Current error is '").concat(currentError, "'.").concat(stackTrace));
    }
  }
}
function evaluateGuard(machine, guard, context, _event, state) {
  var guards = machine.options.guards;
  var guardMeta = {
    state,
    cond: guard,
    _event
  };
  if (guard.type === DEFAULT_GUARD_TYPE) {
    return ((guards === null || guards === void 0 ? void 0 : guards[guard.name]) || guard.predicate)(context, _event.data, guardMeta);
  }
  var condFn = guards === null || guards === void 0 ? void 0 : guards[guard.type];
  if (!condFn) {
    throw new Error("Guard '".concat(guard.type, "' is not implemented on machine '").concat(machine.id, "'."));
  }
  return condFn(context, _event.data, guardMeta);
}
function toInvokeSource(src) {
  if (typeof src === "string") {
    return {
      type: src
    };
  }
  return src;
}
function toObserver(nextHandler, errorHandler, completionHandler) {
  var noop3 = function() {
  };
  var isObserver = typeof nextHandler === "object";
  var self2 = isObserver ? nextHandler : null;
  return {
    next: ((isObserver ? nextHandler.next : nextHandler) || noop3).bind(self2),
    error: ((isObserver ? nextHandler.error : errorHandler) || noop3).bind(self2),
    complete: ((isObserver ? nextHandler.complete : completionHandler) || noop3).bind(self2)
  };
}
function createInvokeId(stateNodeId, index2) {
  return "".concat(stateNodeId, ":invocation[").concat(index2, "]");
}
function isRaisableAction(action) {
  return (action.type === raise || action.type === send && action.to === SpecialTargets.Internal) && typeof action.delay !== "number";
}

// node_modules/xstate/es/actions.js
var initEvent = toSCXMLEvent({
  type: init
});
function getActionFunction(actionType, actionFunctionMap) {
  return actionFunctionMap ? actionFunctionMap[actionType] || void 0 : void 0;
}
function toActionObject(action, actionFunctionMap) {
  var actionObject;
  if (isString(action) || typeof action === "number") {
    var exec = getActionFunction(action, actionFunctionMap);
    if (isFunction(exec)) {
      actionObject = {
        type: action,
        exec
      };
    } else if (exec) {
      actionObject = exec;
    } else {
      actionObject = {
        type: action,
        exec: void 0
      };
    }
  } else if (isFunction(action)) {
    actionObject = {
      // Convert action to string if unnamed
      type: action.name || action.toString(),
      exec: action
    };
  } else {
    var exec = getActionFunction(action.type, actionFunctionMap);
    if (isFunction(exec)) {
      actionObject = __assign(__assign({}, action), {
        exec
      });
    } else if (exec) {
      var actionType = exec.type || action.type;
      actionObject = __assign(__assign(__assign({}, exec), action), {
        type: actionType
      });
    } else {
      actionObject = action;
    }
  }
  return actionObject;
}
var toActionObjects = function(action, actionFunctionMap) {
  if (!action) {
    return [];
  }
  var actions = isArray(action) ? action : [action];
  return actions.map(function(subAction) {
    return toActionObject(subAction, actionFunctionMap);
  });
};
function toActivityDefinition(action) {
  var actionObject = toActionObject(action);
  return __assign(__assign({
    id: isString(action) ? action : actionObject.id
  }, actionObject), {
    type: actionObject.type
  });
}
function raise2(event2, options) {
  return {
    type: raise,
    event: typeof event2 === "function" ? event2 : toEventObject(event2),
    delay: options ? options.delay : void 0,
    id: options === null || options === void 0 ? void 0 : options.id
  };
}
function resolveRaise(action, ctx, _event, delaysMap) {
  var meta = {
    _event
  };
  var resolvedEvent = toSCXMLEvent(isFunction(action.event) ? action.event(ctx, _event.data, meta) : action.event);
  var resolvedDelay;
  if (isString(action.delay)) {
    var configDelay = delaysMap && delaysMap[action.delay];
    resolvedDelay = isFunction(configDelay) ? configDelay(ctx, _event.data, meta) : configDelay;
  } else {
    resolvedDelay = isFunction(action.delay) ? action.delay(ctx, _event.data, meta) : action.delay;
  }
  return __assign(__assign({}, action), {
    type: raise,
    _event: resolvedEvent,
    delay: resolvedDelay
  });
}
function send2(event2, options) {
  return {
    to: options ? options.to : void 0,
    type: send,
    event: isFunction(event2) ? event2 : toEventObject(event2),
    delay: options ? options.delay : void 0,
    // TODO: don't auto-generate IDs here like that
    // there is too big chance of the ID collision
    id: options && options.id !== void 0 ? options.id : isFunction(event2) ? event2.name : getEventType(event2)
  };
}
function resolveSend(action, ctx, _event, delaysMap) {
  var meta = {
    _event
  };
  var resolvedEvent = toSCXMLEvent(isFunction(action.event) ? action.event(ctx, _event.data, meta) : action.event);
  var resolvedDelay;
  if (isString(action.delay)) {
    var configDelay = delaysMap && delaysMap[action.delay];
    resolvedDelay = isFunction(configDelay) ? configDelay(ctx, _event.data, meta) : configDelay;
  } else {
    resolvedDelay = isFunction(action.delay) ? action.delay(ctx, _event.data, meta) : action.delay;
  }
  var resolvedTarget = isFunction(action.to) ? action.to(ctx, _event.data, meta) : action.to;
  return __assign(__assign({}, action), {
    to: resolvedTarget,
    _event: resolvedEvent,
    event: resolvedEvent.data,
    delay: resolvedDelay
  });
}
var resolveLog = function(action, ctx, _event) {
  return __assign(__assign({}, action), {
    value: isString(action.expr) ? action.expr : action.expr(ctx, _event.data, {
      _event
    })
  });
};
var cancel2 = function(sendId) {
  return {
    type: cancel,
    sendId
  };
};
function start2(activity) {
  var activityDef = toActivityDefinition(activity);
  return {
    type: ActionTypes.Start,
    activity: activityDef,
    exec: void 0
  };
}
function stop2(actorRef) {
  var activity = isFunction(actorRef) ? actorRef : toActivityDefinition(actorRef);
  return {
    type: ActionTypes.Stop,
    activity,
    exec: void 0
  };
}
function resolveStop(action, context, _event) {
  var actorRefOrString = isFunction(action.activity) ? action.activity(context, _event.data) : action.activity;
  var resolvedActorRef = typeof actorRefOrString === "string" ? {
    id: actorRefOrString
  } : actorRefOrString;
  var actionObject = {
    type: ActionTypes.Stop,
    activity: resolvedActorRef
  };
  return actionObject;
}
var assign2 = function(assignment) {
  return {
    type: assign,
    assignment
  };
};
function after2(delayRef, id) {
  var idSuffix = id ? "#".concat(id) : "";
  return "".concat(ActionTypes.After, "(").concat(delayRef, ")").concat(idSuffix);
}
function done(id, data) {
  var type = "".concat(ActionTypes.DoneState, ".").concat(id);
  var eventObject = {
    type,
    data
  };
  eventObject.toString = function() {
    return type;
  };
  return eventObject;
}
function doneInvoke(id, data) {
  var type = "".concat(ActionTypes.DoneInvoke, ".").concat(id);
  var eventObject = {
    type,
    data
  };
  eventObject.toString = function() {
    return type;
  };
  return eventObject;
}
function error2(id, data) {
  var type = "".concat(ActionTypes.ErrorPlatform, ".").concat(id);
  var eventObject = {
    type,
    data
  };
  eventObject.toString = function() {
    return type;
  };
  return eventObject;
}
var pluckAssigns = function(actionBlocks) {
  var e_1, _a2;
  var assignActions = [];
  try {
    for (var actionBlocks_1 = __values(actionBlocks), actionBlocks_1_1 = actionBlocks_1.next(); !actionBlocks_1_1.done; actionBlocks_1_1 = actionBlocks_1.next()) {
      var block = actionBlocks_1_1.value;
      var i2 = 0;
      while (i2 < block.actions.length) {
        if (block.actions[i2].type === assign) {
          assignActions.push(block.actions[i2]);
          block.actions.splice(i2, 1);
          continue;
        }
        i2++;
      }
    }
  } catch (e_1_1) {
    e_1 = {
      error: e_1_1
    };
  } finally {
    try {
      if (actionBlocks_1_1 && !actionBlocks_1_1.done && (_a2 = actionBlocks_1.return)) _a2.call(actionBlocks_1);
    } finally {
      if (e_1) throw e_1.error;
    }
  }
  return assignActions;
};
function resolveActions(machine, currentState, currentContext, _event, actionBlocks, predictableExec, preserveActionOrder) {
  if (preserveActionOrder === void 0) {
    preserveActionOrder = false;
  }
  var assignActions = preserveActionOrder ? [] : pluckAssigns(actionBlocks);
  var updatedContext = assignActions.length ? updateContext(currentContext, _event, assignActions, currentState) : currentContext;
  var preservedContexts = preserveActionOrder ? [currentContext] : void 0;
  var deferredToBlockEnd = [];
  function handleAction(blockType, actionObject) {
    var _a2;
    switch (actionObject.type) {
      case raise: {
        var raisedAction = resolveRaise(actionObject, updatedContext, _event, machine.options.delays);
        if (predictableExec && typeof raisedAction.delay === "number") {
          predictableExec(raisedAction, updatedContext, _event);
        }
        return raisedAction;
      }
      case send:
        var sendAction = resolveSend(actionObject, updatedContext, _event, machine.options.delays);
        if (!IS_PRODUCTION) {
          var configuredDelay = actionObject.delay;
          warn(
            !isString(configuredDelay) || typeof sendAction.delay === "number",
            // tslint:disable-next-line:max-line-length
            "No delay reference for delay expression '".concat(configuredDelay, "' was found on machine '").concat(machine.id, "'")
          );
        }
        if (predictableExec && sendAction.to !== SpecialTargets.Internal) {
          if (blockType === "entry") {
            deferredToBlockEnd.push(sendAction);
          } else {
            predictableExec(sendAction, updatedContext, _event);
          }
        }
        return sendAction;
      case log: {
        var resolved = resolveLog(actionObject, updatedContext, _event);
        predictableExec === null || predictableExec === void 0 ? void 0 : predictableExec(resolved, updatedContext, _event);
        return resolved;
      }
      case choose: {
        var chooseAction = actionObject;
        var matchedActions = (_a2 = chooseAction.conds.find(function(condition) {
          var guard = toGuard(condition.cond, machine.options.guards);
          return !guard || evaluateGuard(machine, guard, updatedContext, _event, !predictableExec ? currentState : void 0);
        })) === null || _a2 === void 0 ? void 0 : _a2.actions;
        if (!matchedActions) {
          return [];
        }
        var _b = __read(resolveActions(machine, currentState, updatedContext, _event, [{
          type: blockType,
          actions: toActionObjects(toArray(matchedActions), machine.options.actions)
        }], predictableExec, preserveActionOrder), 2), resolvedActionsFromChoose = _b[0], resolvedContextFromChoose = _b[1];
        updatedContext = resolvedContextFromChoose;
        preservedContexts === null || preservedContexts === void 0 ? void 0 : preservedContexts.push(updatedContext);
        return resolvedActionsFromChoose;
      }
      case pure: {
        var matchedActions = actionObject.get(updatedContext, _event.data);
        if (!matchedActions) {
          return [];
        }
        var _c = __read(resolveActions(machine, currentState, updatedContext, _event, [{
          type: blockType,
          actions: toActionObjects(toArray(matchedActions), machine.options.actions)
        }], predictableExec, preserveActionOrder), 2), resolvedActionsFromPure = _c[0], resolvedContext = _c[1];
        updatedContext = resolvedContext;
        preservedContexts === null || preservedContexts === void 0 ? void 0 : preservedContexts.push(updatedContext);
        return resolvedActionsFromPure;
      }
      case stop: {
        var resolved = resolveStop(actionObject, updatedContext, _event);
        predictableExec === null || predictableExec === void 0 ? void 0 : predictableExec(resolved, currentContext, _event);
        return resolved;
      }
      case assign: {
        updatedContext = updateContext(updatedContext, _event, [actionObject], !predictableExec ? currentState : void 0);
        preservedContexts === null || preservedContexts === void 0 ? void 0 : preservedContexts.push(updatedContext);
        break;
      }
      default:
        var resolvedActionObject = toActionObject(actionObject, machine.options.actions);
        var exec_1 = resolvedActionObject.exec;
        if (predictableExec) {
          predictableExec(resolvedActionObject, updatedContext, _event);
        } else if (exec_1 && preservedContexts) {
          var contextIndex_1 = preservedContexts.length - 1;
          var wrapped = __assign(__assign({}, resolvedActionObject), {
            exec: function(_ctx) {
              var args = [];
              for (var _i = 1; _i < arguments.length; _i++) {
                args[_i - 1] = arguments[_i];
              }
              exec_1.apply(void 0, __spreadArray([preservedContexts[contextIndex_1]], __read(args), false));
            }
          });
          resolvedActionObject = wrapped;
        }
        return resolvedActionObject;
    }
  }
  function processBlock(block) {
    var e_2, _a2;
    var resolvedActions2 = [];
    try {
      for (var _b = __values(block.actions), _c = _b.next(); !_c.done; _c = _b.next()) {
        var action = _c.value;
        var resolved = handleAction(block.type, action);
        if (resolved) {
          resolvedActions2 = resolvedActions2.concat(resolved);
        }
      }
    } catch (e_2_1) {
      e_2 = {
        error: e_2_1
      };
    } finally {
      try {
        if (_c && !_c.done && (_a2 = _b.return)) _a2.call(_b);
      } finally {
        if (e_2) throw e_2.error;
      }
    }
    deferredToBlockEnd.forEach(function(action2) {
      predictableExec(action2, updatedContext, _event);
    });
    deferredToBlockEnd.length = 0;
    return resolvedActions2;
  }
  var resolvedActions = flatten(actionBlocks.map(processBlock));
  return [resolvedActions, updatedContext];
}

// node_modules/xstate/es/serviceScope.js
var serviceStack = [];
var provide = function(service, fn) {
  serviceStack.push(service);
  var result = fn(service);
  serviceStack.pop();
  return result;
};

// node_modules/xstate/es/Actor.js
function createNullActor(id) {
  var _a2;
  return _a2 = {
    id,
    send: function() {
      return void 0;
    },
    subscribe: function() {
      return {
        unsubscribe: function() {
          return void 0;
        }
      };
    },
    getSnapshot: function() {
      return void 0;
    },
    toJSON: function() {
      return {
        id
      };
    }
  }, _a2[symbolObservable] = function() {
    return this;
  }, _a2;
}
function createInvocableActor(invokeDefinition, machine, context, _event) {
  var _a2;
  var invokeSrc = toInvokeSource(invokeDefinition.src);
  var serviceCreator = (_a2 = machine === null || machine === void 0 ? void 0 : machine.options.services) === null || _a2 === void 0 ? void 0 : _a2[invokeSrc.type];
  var resolvedData = invokeDefinition.data ? mapContext(invokeDefinition.data, context, _event) : void 0;
  var tempActor = serviceCreator ? createDeferredActor(serviceCreator, invokeDefinition.id, resolvedData) : createNullActor(invokeDefinition.id);
  tempActor.meta = invokeDefinition;
  return tempActor;
}
function createDeferredActor(entity, id, data) {
  var tempActor = createNullActor(id);
  tempActor.deferred = true;
  if (isMachine(entity)) {
    var initialState_1 = tempActor.state = provide(void 0, function() {
      return (data ? entity.withContext(data) : entity).initialState;
    });
    tempActor.getSnapshot = function() {
      return initialState_1;
    };
  }
  return tempActor;
}
function isActor2(item) {
  try {
    return typeof item.send === "function";
  } catch (e) {
    return false;
  }
}
function isSpawnedActor(item) {
  return isActor2(item) && "id" in item;
}
function toActorRef(actorRefLike) {
  var _a2;
  return __assign((_a2 = {
    subscribe: function() {
      return {
        unsubscribe: function() {
          return void 0;
        }
      };
    },
    id: "anonymous",
    getSnapshot: function() {
      return void 0;
    }
  }, _a2[symbolObservable] = function() {
    return this;
  }, _a2), actorRefLike);
}

// node_modules/xstate/es/stateUtils.js
var isLeafNode = function(stateNode) {
  return stateNode.type === "atomic" || stateNode.type === "final";
};
function getAllChildren(stateNode) {
  return Object.keys(stateNode.states).map(function(key) {
    return stateNode.states[key];
  });
}
function getChildren(stateNode) {
  return getAllChildren(stateNode).filter(function(sn) {
    return sn.type !== "history";
  });
}
function getAllStateNodes(stateNode) {
  var stateNodes = [stateNode];
  if (isLeafNode(stateNode)) {
    return stateNodes;
  }
  return stateNodes.concat(flatten(getChildren(stateNode).map(getAllStateNodes)));
}
function getConfiguration(prevStateNodes, stateNodes) {
  var e_1, _a2, e_2, _b, e_3, _c, e_4, _d;
  var prevConfiguration = new Set(prevStateNodes);
  var prevAdjList = getAdjList(prevConfiguration);
  var configuration = new Set(stateNodes);
  try {
    for (var configuration_1 = __values(configuration), configuration_1_1 = configuration_1.next(); !configuration_1_1.done; configuration_1_1 = configuration_1.next()) {
      var s2 = configuration_1_1.value;
      var m = s2.parent;
      while (m && !configuration.has(m)) {
        configuration.add(m);
        m = m.parent;
      }
    }
  } catch (e_1_1) {
    e_1 = {
      error: e_1_1
    };
  } finally {
    try {
      if (configuration_1_1 && !configuration_1_1.done && (_a2 = configuration_1.return)) _a2.call(configuration_1);
    } finally {
      if (e_1) throw e_1.error;
    }
  }
  var adjList = getAdjList(configuration);
  try {
    for (var configuration_2 = __values(configuration), configuration_2_1 = configuration_2.next(); !configuration_2_1.done; configuration_2_1 = configuration_2.next()) {
      var s2 = configuration_2_1.value;
      if (s2.type === "compound" && (!adjList.get(s2) || !adjList.get(s2).length)) {
        if (prevAdjList.get(s2)) {
          prevAdjList.get(s2).forEach(function(sn) {
            return configuration.add(sn);
          });
        } else {
          s2.initialStateNodes.forEach(function(sn) {
            return configuration.add(sn);
          });
        }
      } else {
        if (s2.type === "parallel") {
          try {
            for (var _e = (e_3 = void 0, __values(getChildren(s2))), _f = _e.next(); !_f.done; _f = _e.next()) {
              var child = _f.value;
              if (!configuration.has(child)) {
                configuration.add(child);
                if (prevAdjList.get(child)) {
                  prevAdjList.get(child).forEach(function(sn) {
                    return configuration.add(sn);
                  });
                } else {
                  child.initialStateNodes.forEach(function(sn) {
                    return configuration.add(sn);
                  });
                }
              }
            }
          } catch (e_3_1) {
            e_3 = {
              error: e_3_1
            };
          } finally {
            try {
              if (_f && !_f.done && (_c = _e.return)) _c.call(_e);
            } finally {
              if (e_3) throw e_3.error;
            }
          }
        }
      }
    }
  } catch (e_2_1) {
    e_2 = {
      error: e_2_1
    };
  } finally {
    try {
      if (configuration_2_1 && !configuration_2_1.done && (_b = configuration_2.return)) _b.call(configuration_2);
    } finally {
      if (e_2) throw e_2.error;
    }
  }
  try {
    for (var configuration_3 = __values(configuration), configuration_3_1 = configuration_3.next(); !configuration_3_1.done; configuration_3_1 = configuration_3.next()) {
      var s2 = configuration_3_1.value;
      var m = s2.parent;
      while (m && !configuration.has(m)) {
        configuration.add(m);
        m = m.parent;
      }
    }
  } catch (e_4_1) {
    e_4 = {
      error: e_4_1
    };
  } finally {
    try {
      if (configuration_3_1 && !configuration_3_1.done && (_d = configuration_3.return)) _d.call(configuration_3);
    } finally {
      if (e_4) throw e_4.error;
    }
  }
  return configuration;
}
function getValueFromAdj(baseNode, adjList) {
  var childStateNodes = adjList.get(baseNode);
  if (!childStateNodes) {
    return {};
  }
  if (baseNode.type === "compound") {
    var childStateNode = childStateNodes[0];
    if (childStateNode) {
      if (isLeafNode(childStateNode)) {
        return childStateNode.key;
      }
    } else {
      return {};
    }
  }
  var stateValue = {};
  childStateNodes.forEach(function(csn) {
    stateValue[csn.key] = getValueFromAdj(csn, adjList);
  });
  return stateValue;
}
function getAdjList(configuration) {
  var e_5, _a2;
  var adjList = /* @__PURE__ */ new Map();
  try {
    for (var configuration_4 = __values(configuration), configuration_4_1 = configuration_4.next(); !configuration_4_1.done; configuration_4_1 = configuration_4.next()) {
      var s2 = configuration_4_1.value;
      if (!adjList.has(s2)) {
        adjList.set(s2, []);
      }
      if (s2.parent) {
        if (!adjList.has(s2.parent)) {
          adjList.set(s2.parent, []);
        }
        adjList.get(s2.parent).push(s2);
      }
    }
  } catch (e_5_1) {
    e_5 = {
      error: e_5_1
    };
  } finally {
    try {
      if (configuration_4_1 && !configuration_4_1.done && (_a2 = configuration_4.return)) _a2.call(configuration_4);
    } finally {
      if (e_5) throw e_5.error;
    }
  }
  return adjList;
}
function getValue(rootNode, configuration) {
  var config2 = getConfiguration([rootNode], configuration);
  return getValueFromAdj(rootNode, getAdjList(config2));
}
function has(iterable, item) {
  if (Array.isArray(iterable)) {
    return iterable.some(function(member) {
      return member === item;
    });
  }
  if (iterable instanceof Set) {
    return iterable.has(item);
  }
  return false;
}
function nextEvents(configuration) {
  return __spreadArray([], __read(new Set(flatten(__spreadArray([], __read(configuration.map(function(sn) {
    return sn.ownEvents;
  })), false)))), false);
}
function isInFinalState(configuration, stateNode) {
  if (stateNode.type === "compound") {
    return getChildren(stateNode).some(function(s2) {
      return s2.type === "final" && has(configuration, s2);
    });
  }
  if (stateNode.type === "parallel") {
    return getChildren(stateNode).every(function(sn) {
      return isInFinalState(configuration, sn);
    });
  }
  return false;
}
function getMeta(configuration) {
  if (configuration === void 0) {
    configuration = [];
  }
  return configuration.reduce(function(acc, stateNode) {
    if (stateNode.meta !== void 0) {
      acc[stateNode.id] = stateNode.meta;
    }
    return acc;
  }, {});
}
function getTagsFromConfiguration(configuration) {
  return new Set(flatten(configuration.map(function(sn) {
    return sn.tags;
  })));
}

// node_modules/xstate/es/State.js
function stateValuesEqual(a2, b) {
  if (a2 === b) {
    return true;
  }
  if (a2 === void 0 || b === void 0) {
    return false;
  }
  if (isString(a2) || isString(b)) {
    return a2 === b;
  }
  var aKeys = Object.keys(a2);
  var bKeys = Object.keys(b);
  return aKeys.length === bKeys.length && aKeys.every(function(key) {
    return stateValuesEqual(a2[key], b[key]);
  });
}
function isStateConfig(state) {
  if (typeof state !== "object" || state === null) {
    return false;
  }
  return "value" in state && "_event" in state;
}
function bindActionToState(action, state) {
  var exec = action.exec;
  var boundAction = __assign(__assign({}, action), {
    exec: exec !== void 0 ? function() {
      return exec(state.context, state.event, {
        action,
        state,
        _event: state._event
      });
    } : void 0
  });
  return boundAction;
}
var State = (
  /** @class */
  function() {
    function State2(config2) {
      var _this = this;
      var _a2;
      this.actions = [];
      this.activities = EMPTY_ACTIVITY_MAP;
      this.meta = {};
      this.events = [];
      this.value = config2.value;
      this.context = config2.context;
      this._event = config2._event;
      this._sessionid = config2._sessionid;
      this.event = this._event.data;
      this.historyValue = config2.historyValue;
      this.history = config2.history;
      this.actions = config2.actions || [];
      this.activities = config2.activities || EMPTY_ACTIVITY_MAP;
      this.meta = getMeta(config2.configuration);
      this.events = config2.events || [];
      this.matches = this.matches.bind(this);
      this.toStrings = this.toStrings.bind(this);
      this.configuration = config2.configuration;
      this.transitions = config2.transitions;
      this.children = config2.children;
      this.done = !!config2.done;
      this.tags = (_a2 = Array.isArray(config2.tags) ? new Set(config2.tags) : config2.tags) !== null && _a2 !== void 0 ? _a2 : /* @__PURE__ */ new Set();
      this.machine = config2.machine;
      Object.defineProperty(this, "nextEvents", {
        get: function() {
          return nextEvents(_this.configuration);
        }
      });
    }
    State2.from = function(stateValue, context) {
      if (stateValue instanceof State2) {
        if (stateValue.context !== context) {
          return new State2({
            value: stateValue.value,
            context,
            _event: stateValue._event,
            _sessionid: null,
            historyValue: stateValue.historyValue,
            history: stateValue.history,
            actions: [],
            activities: stateValue.activities,
            meta: {},
            events: [],
            configuration: [],
            transitions: [],
            children: {}
          });
        }
        return stateValue;
      }
      var _event = initEvent;
      return new State2({
        value: stateValue,
        context,
        _event,
        _sessionid: null,
        historyValue: void 0,
        history: void 0,
        actions: [],
        activities: void 0,
        meta: void 0,
        events: [],
        configuration: [],
        transitions: [],
        children: {}
      });
    };
    State2.create = function(config2) {
      return new State2(config2);
    };
    State2.inert = function(stateValue, context) {
      if (stateValue instanceof State2) {
        if (!stateValue.actions.length) {
          return stateValue;
        }
        var _event = initEvent;
        return new State2({
          value: stateValue.value,
          context,
          _event,
          _sessionid: null,
          historyValue: stateValue.historyValue,
          history: stateValue.history,
          activities: stateValue.activities,
          configuration: stateValue.configuration,
          transitions: [],
          children: {}
        });
      }
      return State2.from(stateValue, context);
    };
    State2.prototype.toStrings = function(stateValue, delimiter) {
      var _this = this;
      if (stateValue === void 0) {
        stateValue = this.value;
      }
      if (delimiter === void 0) {
        delimiter = ".";
      }
      if (isString(stateValue)) {
        return [stateValue];
      }
      var valueKeys = Object.keys(stateValue);
      return valueKeys.concat.apply(valueKeys, __spreadArray([], __read(valueKeys.map(function(key) {
        return _this.toStrings(stateValue[key], delimiter).map(function(s2) {
          return key + delimiter + s2;
        });
      })), false));
    };
    State2.prototype.toJSON = function() {
      var _a2 = this;
      _a2.configuration;
      _a2.transitions;
      var tags = _a2.tags;
      _a2.machine;
      var jsonValues = __rest(_a2, ["configuration", "transitions", "tags", "machine"]);
      return __assign(__assign({}, jsonValues), {
        tags: Array.from(tags)
      });
    };
    State2.prototype.matches = function(parentStateValue) {
      return matchesState(parentStateValue, this.value);
    };
    State2.prototype.hasTag = function(tag) {
      return this.tags.has(tag);
    };
    State2.prototype.can = function(event2) {
      var _a2;
      if (IS_PRODUCTION) {
        warn(!!this.machine, "state.can(...) used outside of a machine-created State object; this will always return false.");
      }
      var transitionData = (_a2 = this.machine) === null || _a2 === void 0 ? void 0 : _a2.getTransitionData(this, event2);
      return !!(transitionData === null || transitionData === void 0 ? void 0 : transitionData.transitions.length) && // Check that at least one transition is not forbidden
      transitionData.transitions.some(function(t3) {
        return t3.target !== void 0 || t3.actions.length;
      });
    };
    return State2;
  }()
);

// node_modules/xstate/es/scheduler.js
var defaultOptions = {
  deferEvents: false
};
var Scheduler = (
  /** @class */
  function() {
    function Scheduler3(options) {
      this.processingEvent = false;
      this.queue = [];
      this.initialized = false;
      this.options = __assign(__assign({}, defaultOptions), options);
    }
    Scheduler3.prototype.initialize = function(callback) {
      this.initialized = true;
      if (callback) {
        if (!this.options.deferEvents) {
          this.schedule(callback);
          return;
        }
        this.process(callback);
      }
      this.flushEvents();
    };
    Scheduler3.prototype.schedule = function(task) {
      if (!this.initialized || this.processingEvent) {
        this.queue.push(task);
        return;
      }
      if (this.queue.length !== 0) {
        throw new Error("Event queue should be empty when it is not processing events");
      }
      this.process(task);
      this.flushEvents();
    };
    Scheduler3.prototype.clear = function() {
      this.queue = [];
    };
    Scheduler3.prototype.flushEvents = function() {
      var nextCallback = this.queue.shift();
      while (nextCallback) {
        this.process(nextCallback);
        nextCallback = this.queue.shift();
      }
    };
    Scheduler3.prototype.process = function(callback) {
      this.processingEvent = true;
      try {
        callback();
      } catch (e) {
        this.clear();
        throw e;
      } finally {
        this.processingEvent = false;
      }
    };
    return Scheduler3;
  }()
);

// node_modules/xstate/es/registry.js
var children = /* @__PURE__ */ new Map();
var sessionIdIndex = 0;
var registry = {
  bookId: function() {
    return "x:".concat(sessionIdIndex++);
  },
  register: function(id, actor) {
    children.set(id, actor);
    return id;
  },
  get: function(id) {
    return children.get(id);
  },
  free: function(id) {
    children.delete(id);
  }
};

// node_modules/xstate/es/devTools.js
function getGlobal() {
  if (typeof globalThis !== "undefined") {
    return globalThis;
  }
  if (typeof self !== "undefined") {
    return self;
  }
  if (typeof window !== "undefined") {
    return window;
  }
  if (typeof global !== "undefined") {
    return global;
  }
  if (!IS_PRODUCTION) {
    console.warn("XState could not find a global object in this environment. Please let the maintainers know and raise an issue here: https://github.com/statelyai/xstate/issues");
  }
}
function getDevTools() {
  var global3 = getGlobal();
  if (global3 && "__xstate__" in global3) {
    return global3.__xstate__;
  }
  return void 0;
}
function registerService(service) {
  if (!getGlobal()) {
    return;
  }
  var devTools = getDevTools();
  if (devTools) {
    devTools.register(service);
  }
}

// node_modules/xstate/es/behaviors.js
function spawnBehavior(behavior, options) {
  if (options === void 0) {
    options = {};
  }
  var state = behavior.initialState;
  var observers = /* @__PURE__ */ new Set();
  var mailbox = [];
  var flushing = false;
  var flush = function() {
    if (flushing) {
      return;
    }
    flushing = true;
    while (mailbox.length > 0) {
      var event_1 = mailbox.shift();
      state = behavior.transition(state, event_1, actorCtx);
      observers.forEach(function(observer) {
        return observer.next(state);
      });
    }
    flushing = false;
  };
  var actor = toActorRef({
    id: options.id,
    send: function(event2) {
      mailbox.push(event2);
      flush();
    },
    getSnapshot: function() {
      return state;
    },
    subscribe: function(next, handleError, complete) {
      var observer = toObserver(next, handleError, complete);
      observers.add(observer);
      observer.next(state);
      return {
        unsubscribe: function() {
          observers.delete(observer);
        }
      };
    }
  });
  var actorCtx = {
    parent: options.parent,
    self: actor,
    id: options.id || "anonymous",
    observers
  };
  state = behavior.start ? behavior.start(actorCtx) : state;
  return actor;
}

// node_modules/xstate/es/interpreter.js
var DEFAULT_SPAWN_OPTIONS = {
  sync: false,
  autoForward: false
};
var InterpreterStatus;
(function(InterpreterStatus2) {
  InterpreterStatus2[InterpreterStatus2["NotStarted"] = 0] = "NotStarted";
  InterpreterStatus2[InterpreterStatus2["Running"] = 1] = "Running";
  InterpreterStatus2[InterpreterStatus2["Stopped"] = 2] = "Stopped";
})(InterpreterStatus || (InterpreterStatus = {}));
var Interpreter = (
  /** @class */
  function() {
    function Interpreter2(machine, options) {
      if (options === void 0) {
        options = Interpreter2.defaultOptions;
      }
      var _this = this;
      this.machine = machine;
      this.delayedEventsMap = {};
      this.listeners = /* @__PURE__ */ new Set();
      this.contextListeners = /* @__PURE__ */ new Set();
      this.stopListeners = /* @__PURE__ */ new Set();
      this.doneListeners = /* @__PURE__ */ new Set();
      this.eventListeners = /* @__PURE__ */ new Set();
      this.sendListeners = /* @__PURE__ */ new Set();
      this.initialized = false;
      this.status = InterpreterStatus.NotStarted;
      this.children = /* @__PURE__ */ new Map();
      this.forwardTo = /* @__PURE__ */ new Set();
      this._outgoingQueue = [];
      this.init = this.start;
      this.send = function(event2, payload) {
        if (isArray(event2)) {
          _this.batch(event2);
          return _this.state;
        }
        var _event = toSCXMLEvent(toEventObject(event2, payload));
        if (_this.status === InterpreterStatus.Stopped) {
          if (!IS_PRODUCTION) {
            warn(false, 'Event "'.concat(_event.name, '" was sent to stopped service "').concat(_this.machine.id, '". This service has already reached its final state, and will not transition.\nEvent: ').concat(JSON.stringify(_event.data)));
          }
          return _this.state;
        }
        if (_this.status !== InterpreterStatus.Running && !_this.options.deferEvents) {
          throw new Error('Event "'.concat(_event.name, '" was sent to uninitialized service "').concat(
            _this.machine.id,
            '". Make sure .start() is called for this service, or set { deferEvents: true } in the service options.\nEvent: '
          ).concat(JSON.stringify(_event.data)));
        }
        _this.scheduler.schedule(function() {
          _this.forward(_event);
          var nextState = _this._nextState(_event);
          _this.update(nextState, _event);
        });
        return _this._state;
      };
      this.sendTo = function(event2, to, immediate) {
        var isParent = _this.parent && (to === SpecialTargets.Parent || _this.parent.id === to);
        var target = isParent ? _this.parent : isString(to) ? to === SpecialTargets.Internal ? _this : _this.children.get(to) || registry.get(to) : isActor(to) ? to : void 0;
        if (!target) {
          if (!isParent) {
            throw new Error("Unable to send event to child '".concat(to, "' from service '").concat(_this.id, "'."));
          }
          if (!IS_PRODUCTION) {
            warn(false, "Service '".concat(_this.id, "' has no parent: unable to send event ").concat(event2.type));
          }
          return;
        }
        if ("machine" in target) {
          if (_this.status !== InterpreterStatus.Stopped || _this.parent !== target || // we need to send events to the parent from exit handlers of a machine that reached its final state
          _this.state.done) {
            var scxmlEvent = __assign(__assign({}, event2), {
              name: event2.name === error ? "".concat(error2(_this.id)) : event2.name,
              origin: _this.sessionId
            });
            if (!immediate && _this.machine.config.predictableActionArguments) {
              _this._outgoingQueue.push([target, scxmlEvent]);
            } else {
              target.send(scxmlEvent);
            }
          }
        } else {
          if (!immediate && _this.machine.config.predictableActionArguments) {
            _this._outgoingQueue.push([target, event2.data]);
          } else {
            target.send(event2.data);
          }
        }
      };
      this._exec = function(action, context, _event, actionFunctionMap) {
        if (actionFunctionMap === void 0) {
          actionFunctionMap = _this.machine.options.actions;
        }
        var actionOrExec = action.exec || getActionFunction(action.type, actionFunctionMap);
        var exec = isFunction(actionOrExec) ? actionOrExec : actionOrExec ? actionOrExec.exec : action.exec;
        if (exec) {
          try {
            return exec(context, _event.data, !_this.machine.config.predictableActionArguments ? {
              action,
              state: _this.state,
              _event
            } : {
              action,
              _event
            });
          } catch (err) {
            if (_this.parent) {
              _this.parent.send({
                type: "xstate.error",
                data: err
              });
            }
            throw err;
          }
        }
        switch (action.type) {
          case raise: {
            var sendAction_1 = action;
            _this.defer(sendAction_1);
            break;
          }
          case send:
            var sendAction = action;
            if (typeof sendAction.delay === "number") {
              _this.defer(sendAction);
              return;
            } else {
              if (sendAction.to) {
                _this.sendTo(sendAction._event, sendAction.to, _event === initEvent);
              } else {
                _this.send(sendAction._event);
              }
            }
            break;
          case cancel:
            _this.cancel(action.sendId);
            break;
          case start: {
            if (_this.status !== InterpreterStatus.Running) {
              return;
            }
            var activity = action.activity;
            if (
              // in v4 with `predictableActionArguments` invokes are called eagerly when the `this.state` still points to the previous state
              !_this.machine.config.predictableActionArguments && !_this.state.activities[activity.id || activity.type]
            ) {
              break;
            }
            if (activity.type === ActionTypes.Invoke) {
              var invokeSource = toInvokeSource(activity.src);
              var serviceCreator = _this.machine.options.services ? _this.machine.options.services[invokeSource.type] : void 0;
              var id2 = activity.id, data = activity.data;
              if (!IS_PRODUCTION) {
                warn(
                  !("forward" in activity),
                  // tslint:disable-next-line:max-line-length
                  "`forward` property is deprecated (found in invocation of '".concat(activity.src, "' in in machine '").concat(_this.machine.id, "'). ") + "Please use `autoForward` instead."
                );
              }
              var autoForward = "autoForward" in activity ? activity.autoForward : !!activity.forward;
              if (!serviceCreator) {
                if (!IS_PRODUCTION) {
                  warn(false, "No service found for invocation '".concat(activity.src, "' in machine '").concat(_this.machine.id, "'."));
                }
                return;
              }
              var resolvedData = data ? mapContext(data, context, _event) : void 0;
              if (typeof serviceCreator === "string") {
                return;
              }
              var source = isFunction(serviceCreator) ? serviceCreator(context, _event.data, {
                data: resolvedData,
                src: invokeSource,
                meta: activity.meta
              }) : serviceCreator;
              if (!source) {
                return;
              }
              var options2 = void 0;
              if (isMachine(source)) {
                source = resolvedData ? source.withContext(resolvedData) : source;
                options2 = {
                  autoForward
                };
              }
              _this.spawn(source, id2, options2);
            } else {
              _this.spawnActivity(activity);
            }
            break;
          }
          case stop: {
            _this.stopChild(action.activity.id);
            break;
          }
          case log:
            var _a2 = action, label = _a2.label, value = _a2.value;
            if (label) {
              _this.logger(label, value);
            } else {
              _this.logger(value);
            }
            break;
          default:
            if (!IS_PRODUCTION) {
              warn(false, "No implementation found for action type '".concat(action.type, "'"));
            }
            break;
        }
      };
      var resolvedOptions = __assign(__assign({}, Interpreter2.defaultOptions), options);
      var clock = resolvedOptions.clock, logger = resolvedOptions.logger, parent = resolvedOptions.parent, id = resolvedOptions.id;
      var resolvedId = id !== void 0 ? id : machine.id;
      this.id = resolvedId;
      this.logger = logger;
      this.clock = clock;
      this.parent = parent;
      this.options = resolvedOptions;
      this.scheduler = new Scheduler({
        deferEvents: this.options.deferEvents
      });
      this.sessionId = registry.bookId();
    }
    Object.defineProperty(Interpreter2.prototype, "initialState", {
      get: function() {
        var _this = this;
        if (this._initialState) {
          return this._initialState;
        }
        return provide(this, function() {
          _this._initialState = _this.machine.initialState;
          return _this._initialState;
        });
      },
      enumerable: false,
      configurable: true
    });
    Object.defineProperty(Interpreter2.prototype, "state", {
      /**
       * @deprecated Use `.getSnapshot()` instead.
       */
      get: function() {
        if (!IS_PRODUCTION) {
          warn(this.status !== InterpreterStatus.NotStarted, "Attempted to read state from uninitialized service '".concat(this.id, "'. Make sure the service is started first."));
        }
        return this._state;
      },
      enumerable: false,
      configurable: true
    });
    Interpreter2.prototype.execute = function(state, actionsConfig) {
      var e_1, _a2;
      try {
        for (var _b = __values(state.actions), _c = _b.next(); !_c.done; _c = _b.next()) {
          var action = _c.value;
          this.exec(action, state, actionsConfig);
        }
      } catch (e_1_1) {
        e_1 = {
          error: e_1_1
        };
      } finally {
        try {
          if (_c && !_c.done && (_a2 = _b.return)) _a2.call(_b);
        } finally {
          if (e_1) throw e_1.error;
        }
      }
    };
    Interpreter2.prototype.update = function(state, _event) {
      var e_2, _a2, e_3, _b, e_4, _c, e_5, _d;
      var _this = this;
      state._sessionid = this.sessionId;
      this._state = state;
      if ((!this.machine.config.predictableActionArguments || // this is currently required to execute initial actions as the `initialState` gets cached
      // we can't just recompute it (and execute actions while doing so) because we try to preserve identity of actors created within initial assigns
      _event === initEvent) && this.options.execute) {
        this.execute(this.state);
      } else {
        var item = void 0;
        while (item = this._outgoingQueue.shift()) {
          item[0].send(item[1]);
        }
      }
      this.children.forEach(function(child) {
        _this.state.children[child.id] = child;
      });
      if (this.devTools) {
        this.devTools.send(_event.data, state);
      }
      if (state.event) {
        try {
          for (var _e = __values(this.eventListeners), _f = _e.next(); !_f.done; _f = _e.next()) {
            var listener = _f.value;
            listener(state.event);
          }
        } catch (e_2_1) {
          e_2 = {
            error: e_2_1
          };
        } finally {
          try {
            if (_f && !_f.done && (_a2 = _e.return)) _a2.call(_e);
          } finally {
            if (e_2) throw e_2.error;
          }
        }
      }
      try {
        for (var _g = __values(this.listeners), _h = _g.next(); !_h.done; _h = _g.next()) {
          var listener = _h.value;
          listener(state, state.event);
        }
      } catch (e_3_1) {
        e_3 = {
          error: e_3_1
        };
      } finally {
        try {
          if (_h && !_h.done && (_b = _g.return)) _b.call(_g);
        } finally {
          if (e_3) throw e_3.error;
        }
      }
      try {
        for (var _j = __values(this.contextListeners), _k = _j.next(); !_k.done; _k = _j.next()) {
          var contextListener = _k.value;
          contextListener(this.state.context, this.state.history ? this.state.history.context : void 0);
        }
      } catch (e_4_1) {
        e_4 = {
          error: e_4_1
        };
      } finally {
        try {
          if (_k && !_k.done && (_c = _j.return)) _c.call(_j);
        } finally {
          if (e_4) throw e_4.error;
        }
      }
      if (this.state.done) {
        var finalChildStateNode = state.configuration.find(function(sn) {
          return sn.type === "final" && sn.parent === _this.machine;
        });
        var doneData = finalChildStateNode && finalChildStateNode.doneData ? mapContext(finalChildStateNode.doneData, state.context, _event) : void 0;
        this._doneEvent = doneInvoke(this.id, doneData);
        try {
          for (var _l = __values(this.doneListeners), _m = _l.next(); !_m.done; _m = _l.next()) {
            var listener = _m.value;
            listener(this._doneEvent);
          }
        } catch (e_5_1) {
          e_5 = {
            error: e_5_1
          };
        } finally {
          try {
            if (_m && !_m.done && (_d = _l.return)) _d.call(_l);
          } finally {
            if (e_5) throw e_5.error;
          }
        }
        this._stop();
        this._stopChildren();
        registry.free(this.sessionId);
      }
    };
    Interpreter2.prototype.onTransition = function(listener) {
      this.listeners.add(listener);
      if (this.status === InterpreterStatus.Running) {
        listener(this.state, this.state.event);
      }
      return this;
    };
    Interpreter2.prototype.subscribe = function(nextListenerOrObserver, _, completeListener) {
      var _this = this;
      var observer = toObserver(nextListenerOrObserver, _, completeListener);
      this.listeners.add(observer.next);
      if (this.status !== InterpreterStatus.NotStarted) {
        observer.next(this.state);
      }
      var completeOnce = function() {
        _this.doneListeners.delete(completeOnce);
        _this.stopListeners.delete(completeOnce);
        observer.complete();
      };
      if (this.status === InterpreterStatus.Stopped) {
        observer.complete();
      } else {
        this.onDone(completeOnce);
        this.onStop(completeOnce);
      }
      return {
        unsubscribe: function() {
          _this.listeners.delete(observer.next);
          _this.doneListeners.delete(completeOnce);
          _this.stopListeners.delete(completeOnce);
        }
      };
    };
    Interpreter2.prototype.onEvent = function(listener) {
      this.eventListeners.add(listener);
      return this;
    };
    Interpreter2.prototype.onSend = function(listener) {
      this.sendListeners.add(listener);
      return this;
    };
    Interpreter2.prototype.onChange = function(listener) {
      this.contextListeners.add(listener);
      return this;
    };
    Interpreter2.prototype.onStop = function(listener) {
      this.stopListeners.add(listener);
      return this;
    };
    Interpreter2.prototype.onDone = function(listener) {
      if (this.status === InterpreterStatus.Stopped && this._doneEvent) {
        listener(this._doneEvent);
      } else {
        this.doneListeners.add(listener);
      }
      return this;
    };
    Interpreter2.prototype.off = function(listener) {
      this.listeners.delete(listener);
      this.eventListeners.delete(listener);
      this.sendListeners.delete(listener);
      this.stopListeners.delete(listener);
      this.doneListeners.delete(listener);
      this.contextListeners.delete(listener);
      return this;
    };
    Interpreter2.prototype.start = function(initialState) {
      var _this = this;
      if (this.status === InterpreterStatus.Running) {
        return this;
      }
      this.machine._init();
      registry.register(this.sessionId, this);
      this.initialized = true;
      this.status = InterpreterStatus.Running;
      var resolvedState = initialState === void 0 ? this.initialState : provide(this, function() {
        return isStateConfig(initialState) ? _this.machine.resolveState(initialState) : _this.machine.resolveState(State.from(initialState, _this.machine.context));
      });
      if (this.options.devTools) {
        this.attachDev();
      }
      this.scheduler.initialize(function() {
        _this.update(resolvedState, initEvent);
      });
      return this;
    };
    Interpreter2.prototype._stopChildren = function() {
      this.children.forEach(function(child) {
        if (isFunction(child.stop)) {
          child.stop();
        }
      });
      this.children.clear();
    };
    Interpreter2.prototype._stop = function() {
      var e_6, _a2, e_7, _b, e_8, _c, e_9, _d, e_10, _e;
      try {
        for (var _f = __values(this.listeners), _g = _f.next(); !_g.done; _g = _f.next()) {
          var listener = _g.value;
          this.listeners.delete(listener);
        }
      } catch (e_6_1) {
        e_6 = {
          error: e_6_1
        };
      } finally {
        try {
          if (_g && !_g.done && (_a2 = _f.return)) _a2.call(_f);
        } finally {
          if (e_6) throw e_6.error;
        }
      }
      try {
        for (var _h = __values(this.stopListeners), _j = _h.next(); !_j.done; _j = _h.next()) {
          var listener = _j.value;
          listener();
          this.stopListeners.delete(listener);
        }
      } catch (e_7_1) {
        e_7 = {
          error: e_7_1
        };
      } finally {
        try {
          if (_j && !_j.done && (_b = _h.return)) _b.call(_h);
        } finally {
          if (e_7) throw e_7.error;
        }
      }
      try {
        for (var _k = __values(this.contextListeners), _l = _k.next(); !_l.done; _l = _k.next()) {
          var listener = _l.value;
          this.contextListeners.delete(listener);
        }
      } catch (e_8_1) {
        e_8 = {
          error: e_8_1
        };
      } finally {
        try {
          if (_l && !_l.done && (_c = _k.return)) _c.call(_k);
        } finally {
          if (e_8) throw e_8.error;
        }
      }
      try {
        for (var _m = __values(this.doneListeners), _o = _m.next(); !_o.done; _o = _m.next()) {
          var listener = _o.value;
          this.doneListeners.delete(listener);
        }
      } catch (e_9_1) {
        e_9 = {
          error: e_9_1
        };
      } finally {
        try {
          if (_o && !_o.done && (_d = _m.return)) _d.call(_m);
        } finally {
          if (e_9) throw e_9.error;
        }
      }
      if (!this.initialized) {
        return this;
      }
      this.initialized = false;
      this.status = InterpreterStatus.Stopped;
      this._initialState = void 0;
      try {
        for (var _p = __values(Object.keys(this.delayedEventsMap)), _q = _p.next(); !_q.done; _q = _p.next()) {
          var key = _q.value;
          this.clock.clearTimeout(this.delayedEventsMap[key]);
        }
      } catch (e_10_1) {
        e_10 = {
          error: e_10_1
        };
      } finally {
        try {
          if (_q && !_q.done && (_e = _p.return)) _e.call(_p);
        } finally {
          if (e_10) throw e_10.error;
        }
      }
      this.scheduler.clear();
      this.scheduler = new Scheduler({
        deferEvents: this.options.deferEvents
      });
    };
    Interpreter2.prototype.stop = function() {
      var _this = this;
      var scheduler2 = this.scheduler;
      this._stop();
      scheduler2.schedule(function() {
        var _a2;
        if ((_a2 = _this._state) === null || _a2 === void 0 ? void 0 : _a2.done) {
          return;
        }
        var _event = toSCXMLEvent({
          type: "xstate.stop"
        });
        var nextState = provide(_this, function() {
          var exitActions = flatten(__spreadArray([], __read(_this.state.configuration), false).sort(function(a2, b) {
            return b.order - a2.order;
          }).map(function(stateNode) {
            return toActionObjects(stateNode.onExit, _this.machine.options.actions);
          }));
          var _a3 = __read(resolveActions(_this.machine, _this.state, _this.state.context, _event, [{
            type: "exit",
            actions: exitActions
          }], _this.machine.config.predictableActionArguments ? _this._exec : void 0, _this.machine.config.predictableActionArguments || _this.machine.config.preserveActionOrder), 2), resolvedActions = _a3[0], updatedContext = _a3[1];
          var newState = new State({
            value: _this.state.value,
            context: updatedContext,
            _event,
            _sessionid: _this.sessionId,
            historyValue: void 0,
            history: _this.state,
            actions: resolvedActions.filter(function(action) {
              return !isRaisableAction(action);
            }),
            activities: {},
            events: [],
            configuration: [],
            transitions: [],
            children: {},
            done: _this.state.done,
            tags: _this.state.tags,
            machine: _this.machine
          });
          newState.changed = true;
          return newState;
        });
        _this.update(nextState, _event);
        _this._stopChildren();
        registry.free(_this.sessionId);
      });
      return this;
    };
    Interpreter2.prototype.batch = function(events2) {
      var _this = this;
      if (this.status === InterpreterStatus.NotStarted && this.options.deferEvents) {
        if (!IS_PRODUCTION) {
          warn(false, "".concat(events2.length, ' event(s) were sent to uninitialized service "').concat(this.machine.id, '" and are deferred. Make sure .start() is called for this service.\nEvent: ').concat(JSON.stringify(event)));
        }
      } else if (this.status !== InterpreterStatus.Running) {
        throw new Error(
          // tslint:disable-next-line:max-line-length
          "".concat(events2.length, ' event(s) were sent to uninitialized service "').concat(this.machine.id, '". Make sure .start() is called for this service, or set { deferEvents: true } in the service options.')
        );
      }
      if (!events2.length) {
        return;
      }
      var exec = !!this.machine.config.predictableActionArguments && this._exec;
      this.scheduler.schedule(function() {
        var e_11, _a2;
        var nextState = _this.state;
        var batchChanged = false;
        var batchedActions = [];
        var _loop_1 = function(event_12) {
          var _event = toSCXMLEvent(event_12);
          _this.forward(_event);
          nextState = provide(_this, function() {
            return _this.machine.transition(nextState, _event, void 0, exec || void 0);
          });
          batchedActions.push.apply(batchedActions, __spreadArray([], __read(_this.machine.config.predictableActionArguments ? nextState.actions : nextState.actions.map(function(a2) {
            return bindActionToState(a2, nextState);
          })), false));
          batchChanged = batchChanged || !!nextState.changed;
        };
        try {
          for (var events_1 = __values(events2), events_1_1 = events_1.next(); !events_1_1.done; events_1_1 = events_1.next()) {
            var event_1 = events_1_1.value;
            _loop_1(event_1);
          }
        } catch (e_11_1) {
          e_11 = {
            error: e_11_1
          };
        } finally {
          try {
            if (events_1_1 && !events_1_1.done && (_a2 = events_1.return)) _a2.call(events_1);
          } finally {
            if (e_11) throw e_11.error;
          }
        }
        nextState.changed = batchChanged;
        nextState.actions = batchedActions;
        _this.update(nextState, toSCXMLEvent(events2[events2.length - 1]));
      });
    };
    Interpreter2.prototype.sender = function(event2) {
      return this.send.bind(this, event2);
    };
    Interpreter2.prototype._nextState = function(event2, exec) {
      var _this = this;
      if (exec === void 0) {
        exec = !!this.machine.config.predictableActionArguments && this._exec;
      }
      var _event = toSCXMLEvent(event2);
      if (_event.name.indexOf(errorPlatform) === 0 && !this.state.nextEvents.some(function(nextEvent) {
        return nextEvent.indexOf(errorPlatform) === 0;
      })) {
        throw _event.data.data;
      }
      var nextState = provide(this, function() {
        return _this.machine.transition(_this.state, _event, void 0, exec || void 0);
      });
      return nextState;
    };
    Interpreter2.prototype.nextState = function(event2) {
      return this._nextState(event2, false);
    };
    Interpreter2.prototype.forward = function(event2) {
      var e_12, _a2;
      try {
        for (var _b = __values(this.forwardTo), _c = _b.next(); !_c.done; _c = _b.next()) {
          var id = _c.value;
          var child = this.children.get(id);
          if (!child) {
            throw new Error("Unable to forward event '".concat(event2, "' from interpreter '").concat(this.id, "' to nonexistant child '").concat(id, "'."));
          }
          child.send(event2);
        }
      } catch (e_12_1) {
        e_12 = {
          error: e_12_1
        };
      } finally {
        try {
          if (_c && !_c.done && (_a2 = _b.return)) _a2.call(_b);
        } finally {
          if (e_12) throw e_12.error;
        }
      }
    };
    Interpreter2.prototype.defer = function(sendAction) {
      var _this = this;
      var timerId = this.clock.setTimeout(function() {
        if ("to" in sendAction && sendAction.to) {
          _this.sendTo(sendAction._event, sendAction.to, true);
        } else {
          _this.send(sendAction._event);
        }
      }, sendAction.delay);
      if (sendAction.id) {
        this.delayedEventsMap[sendAction.id] = timerId;
      }
    };
    Interpreter2.prototype.cancel = function(sendId) {
      this.clock.clearTimeout(this.delayedEventsMap[sendId]);
      delete this.delayedEventsMap[sendId];
    };
    Interpreter2.prototype.exec = function(action, state, actionFunctionMap) {
      if (actionFunctionMap === void 0) {
        actionFunctionMap = this.machine.options.actions;
      }
      this._exec(action, state.context, state._event, actionFunctionMap);
    };
    Interpreter2.prototype.removeChild = function(childId) {
      var _a2;
      this.children.delete(childId);
      this.forwardTo.delete(childId);
      (_a2 = this.state) === null || _a2 === void 0 ? true : delete _a2.children[childId];
    };
    Interpreter2.prototype.stopChild = function(childId) {
      var child = this.children.get(childId);
      if (!child) {
        return;
      }
      this.removeChild(childId);
      if (isFunction(child.stop)) {
        child.stop();
      }
    };
    Interpreter2.prototype.spawn = function(entity, name, options) {
      if (this.status !== InterpreterStatus.Running) {
        return createDeferredActor(entity, name);
      }
      if (isPromiseLike(entity)) {
        return this.spawnPromise(Promise.resolve(entity), name);
      } else if (isFunction(entity)) {
        return this.spawnCallback(entity, name);
      } else if (isSpawnedActor(entity)) {
        return this.spawnActor(entity, name);
      } else if (isObservable(entity)) {
        return this.spawnObservable(entity, name);
      } else if (isMachine(entity)) {
        return this.spawnMachine(entity, __assign(__assign({}, options), {
          id: name
        }));
      } else if (isBehavior(entity)) {
        return this.spawnBehavior(entity, name);
      } else {
        throw new Error('Unable to spawn entity "'.concat(name, '" of type "').concat(typeof entity, '".'));
      }
    };
    Interpreter2.prototype.spawnMachine = function(machine, options) {
      var _this = this;
      if (options === void 0) {
        options = {};
      }
      var childService = new Interpreter2(machine, __assign(__assign({}, this.options), {
        parent: this,
        id: options.id || machine.id
      }));
      var resolvedOptions = __assign(__assign({}, DEFAULT_SPAWN_OPTIONS), options);
      if (resolvedOptions.sync) {
        childService.onTransition(function(state) {
          _this.send(update, {
            state,
            id: childService.id
          });
        });
      }
      var actor = childService;
      this.children.set(childService.id, actor);
      if (resolvedOptions.autoForward) {
        this.forwardTo.add(childService.id);
      }
      childService.onDone(function(doneEvent) {
        _this.removeChild(childService.id);
        _this.send(toSCXMLEvent(doneEvent, {
          origin: childService.id
        }));
      }).start();
      return actor;
    };
    Interpreter2.prototype.spawnBehavior = function(behavior, id) {
      var actorRef = spawnBehavior(behavior, {
        id,
        parent: this
      });
      this.children.set(id, actorRef);
      return actorRef;
    };
    Interpreter2.prototype.spawnPromise = function(promise, id) {
      var _a2;
      var _this = this;
      var canceled = false;
      var resolvedData;
      promise.then(function(response) {
        if (!canceled) {
          resolvedData = response;
          _this.removeChild(id);
          _this.send(toSCXMLEvent(doneInvoke(id, response), {
            origin: id
          }));
        }
      }, function(errorData) {
        if (!canceled) {
          _this.removeChild(id);
          var errorEvent = error2(id, errorData);
          try {
            _this.send(toSCXMLEvent(errorEvent, {
              origin: id
            }));
          } catch (error3) {
            reportUnhandledExceptionOnInvocation(errorData, error3, id);
            if (_this.devTools) {
              _this.devTools.send(errorEvent, _this.state);
            }
            if (_this.machine.strict) {
              _this.stop();
            }
          }
        }
      });
      var actor = (_a2 = {
        id,
        send: function() {
          return void 0;
        },
        subscribe: function(next, handleError, complete) {
          var observer = toObserver(next, handleError, complete);
          var unsubscribed = false;
          promise.then(function(response) {
            if (unsubscribed) {
              return;
            }
            observer.next(response);
            if (unsubscribed) {
              return;
            }
            observer.complete();
          }, function(err) {
            if (unsubscribed) {
              return;
            }
            observer.error(err);
          });
          return {
            unsubscribe: function() {
              return unsubscribed = true;
            }
          };
        },
        stop: function() {
          canceled = true;
        },
        toJSON: function() {
          return {
            id
          };
        },
        getSnapshot: function() {
          return resolvedData;
        }
      }, _a2[symbolObservable] = function() {
        return this;
      }, _a2);
      this.children.set(id, actor);
      return actor;
    };
    Interpreter2.prototype.spawnCallback = function(callback, id) {
      var _a2;
      var _this = this;
      var canceled = false;
      var receivers = /* @__PURE__ */ new Set();
      var listeners = /* @__PURE__ */ new Set();
      var emitted;
      var receive = function(e) {
        emitted = e;
        listeners.forEach(function(listener) {
          return listener(e);
        });
        if (canceled) {
          return;
        }
        _this.send(toSCXMLEvent(e, {
          origin: id
        }));
      };
      var callbackStop;
      try {
        callbackStop = callback(receive, function(newListener) {
          receivers.add(newListener);
        });
      } catch (err) {
        this.send(error2(id, err));
      }
      if (isPromiseLike(callbackStop)) {
        return this.spawnPromise(callbackStop, id);
      }
      var actor = (_a2 = {
        id,
        send: function(event2) {
          return receivers.forEach(function(receiver) {
            return receiver(event2);
          });
        },
        subscribe: function(next) {
          var observer = toObserver(next);
          listeners.add(observer.next);
          return {
            unsubscribe: function() {
              listeners.delete(observer.next);
            }
          };
        },
        stop: function() {
          canceled = true;
          if (isFunction(callbackStop)) {
            callbackStop();
          }
        },
        toJSON: function() {
          return {
            id
          };
        },
        getSnapshot: function() {
          return emitted;
        }
      }, _a2[symbolObservable] = function() {
        return this;
      }, _a2);
      this.children.set(id, actor);
      return actor;
    };
    Interpreter2.prototype.spawnObservable = function(source, id) {
      var _a2;
      var _this = this;
      var emitted;
      var subscription = source.subscribe(function(value) {
        emitted = value;
        _this.send(toSCXMLEvent(value, {
          origin: id
        }));
      }, function(err) {
        _this.removeChild(id);
        _this.send(toSCXMLEvent(error2(id, err), {
          origin: id
        }));
      }, function() {
        _this.removeChild(id);
        _this.send(toSCXMLEvent(doneInvoke(id), {
          origin: id
        }));
      });
      var actor = (_a2 = {
        id,
        send: function() {
          return void 0;
        },
        subscribe: function(next, handleError, complete) {
          return source.subscribe(next, handleError, complete);
        },
        stop: function() {
          return subscription.unsubscribe();
        },
        getSnapshot: function() {
          return emitted;
        },
        toJSON: function() {
          return {
            id
          };
        }
      }, _a2[symbolObservable] = function() {
        return this;
      }, _a2);
      this.children.set(id, actor);
      return actor;
    };
    Interpreter2.prototype.spawnActor = function(actor, name) {
      this.children.set(name, actor);
      return actor;
    };
    Interpreter2.prototype.spawnActivity = function(activity) {
      var implementation = this.machine.options && this.machine.options.activities ? this.machine.options.activities[activity.type] : void 0;
      if (!implementation) {
        if (!IS_PRODUCTION) {
          warn(false, "No implementation found for activity '".concat(activity.type, "'"));
        }
        return;
      }
      var dispose = implementation(this.state.context, activity);
      this.spawnEffect(activity.id, dispose);
    };
    Interpreter2.prototype.spawnEffect = function(id, dispose) {
      var _a2;
      this.children.set(id, (_a2 = {
        id,
        send: function() {
          return void 0;
        },
        subscribe: function() {
          return {
            unsubscribe: function() {
              return void 0;
            }
          };
        },
        stop: dispose || void 0,
        getSnapshot: function() {
          return void 0;
        },
        toJSON: function() {
          return {
            id
          };
        }
      }, _a2[symbolObservable] = function() {
        return this;
      }, _a2));
    };
    Interpreter2.prototype.attachDev = function() {
      var global3 = getGlobal();
      if (this.options.devTools && global3) {
        if (global3.__REDUX_DEVTOOLS_EXTENSION__) {
          var devToolsOptions = typeof this.options.devTools === "object" ? this.options.devTools : void 0;
          this.devTools = global3.__REDUX_DEVTOOLS_EXTENSION__.connect(__assign(__assign({
            name: this.id,
            autoPause: true,
            stateSanitizer: function(state) {
              return {
                value: state.value,
                context: state.context,
                actions: state.actions
              };
            }
          }, devToolsOptions), {
            features: __assign({
              jump: false,
              skip: false
            }, devToolsOptions ? devToolsOptions.features : void 0)
          }), this.machine);
          this.devTools.init(this.state);
        }
        registerService(this);
      }
    };
    Interpreter2.prototype.toJSON = function() {
      return {
        id: this.id
      };
    };
    Interpreter2.prototype[symbolObservable] = function() {
      return this;
    };
    Interpreter2.prototype.getSnapshot = function() {
      if (this.status === InterpreterStatus.NotStarted) {
        return this.initialState;
      }
      return this._state;
    };
    Interpreter2.defaultOptions = {
      execute: true,
      deferEvents: true,
      clock: {
        setTimeout: function(fn, ms) {
          return setTimeout(fn, ms);
        },
        clearTimeout: function(id) {
          return clearTimeout(id);
        }
      },
      logger: console.log.bind(console),
      devTools: false
    };
    Interpreter2.interpret = interpret;
    return Interpreter2;
  }()
);
function interpret(machine, options) {
  var interpreter = new Interpreter(machine, options);
  return interpreter;
}

// node_modules/xstate/es/invokeUtils.js
function toInvokeSource2(src) {
  if (typeof src === "string") {
    var simpleSrc = {
      type: src
    };
    simpleSrc.toString = function() {
      return src;
    };
    return simpleSrc;
  }
  return src;
}
function toInvokeDefinition(invokeConfig) {
  return __assign(__assign({
    type: invoke
  }, invokeConfig), {
    toJSON: function() {
      invokeConfig.onDone;
      invokeConfig.onError;
      var invokeDef = __rest(invokeConfig, ["onDone", "onError"]);
      return __assign(__assign({}, invokeDef), {
        type: invoke,
        src: toInvokeSource2(invokeConfig.src)
      });
    }
  });
}

// node_modules/xstate/es/StateNode.js
var NULL_EVENT = "";
var STATE_IDENTIFIER = "#";
var WILDCARD = "*";
var EMPTY_OBJECT = {};
var isStateId = function(str) {
  return str[0] === STATE_IDENTIFIER;
};
var createDefaultOptions = function() {
  return {
    actions: {},
    guards: {},
    services: {},
    activities: {},
    delays: {}
  };
};
var validateArrayifiedTransitions = function(stateNode, event2, transitions) {
  var hasNonLastUnguardedTarget = transitions.slice(0, -1).some(function(transition) {
    return !("cond" in transition) && !("in" in transition) && (isString(transition.target) || isMachine(transition.target));
  });
  var eventText = event2 === NULL_EVENT ? "the transient event" : "event '".concat(event2, "'");
  warn(!hasNonLastUnguardedTarget, "One or more transitions for ".concat(eventText, " on state '").concat(stateNode.id, "' are unreachable. ") + "Make sure that the default transition is the last one defined.");
};
var StateNode = (
  /** @class */
  function() {
    function StateNode2(config2, options, _context, _stateInfo) {
      if (_context === void 0) {
        _context = "context" in config2 ? config2.context : void 0;
      }
      var _this = this;
      var _a2;
      this.config = config2;
      this._context = _context;
      this.order = -1;
      this.__xstatenode = true;
      this.__cache = {
        events: void 0,
        relativeValue: /* @__PURE__ */ new Map(),
        initialStateValue: void 0,
        initialState: void 0,
        on: void 0,
        transitions: void 0,
        candidates: {},
        delayedTransitions: void 0
      };
      this.idMap = {};
      this.tags = [];
      this.options = Object.assign(createDefaultOptions(), options);
      this.parent = _stateInfo === null || _stateInfo === void 0 ? void 0 : _stateInfo.parent;
      this.key = this.config.key || (_stateInfo === null || _stateInfo === void 0 ? void 0 : _stateInfo.key) || this.config.id || "(machine)";
      this.machine = this.parent ? this.parent.machine : this;
      this.path = this.parent ? this.parent.path.concat(this.key) : [];
      this.delimiter = this.config.delimiter || (this.parent ? this.parent.delimiter : STATE_DELIMITER);
      this.id = this.config.id || __spreadArray([this.machine.key], __read(this.path), false).join(this.delimiter);
      this.version = this.parent ? this.parent.version : this.config.version;
      this.type = this.config.type || (this.config.parallel ? "parallel" : this.config.states && Object.keys(this.config.states).length ? "compound" : this.config.history ? "history" : "atomic");
      this.schema = this.parent ? this.machine.schema : (_a2 = this.config.schema) !== null && _a2 !== void 0 ? _a2 : {};
      this.description = this.config.description;
      if (!IS_PRODUCTION) {
        warn(!("parallel" in this.config), 'The "parallel" property is deprecated and will be removed in version 4.1. '.concat(this.config.parallel ? "Replace with `type: 'parallel'`" : "Use `type: '".concat(this.type, "'`"), " in the config for state node '").concat(this.id, "' instead."));
      }
      this.initial = this.config.initial;
      this.states = this.config.states ? mapValues(this.config.states, function(stateConfig, key) {
        var _a3;
        var stateNode = new StateNode2(stateConfig, {}, void 0, {
          parent: _this,
          key
        });
        Object.assign(_this.idMap, __assign((_a3 = {}, _a3[stateNode.id] = stateNode, _a3), stateNode.idMap));
        return stateNode;
      }) : EMPTY_OBJECT;
      var order = 0;
      function dfs(stateNode) {
        var e_1, _a3;
        stateNode.order = order++;
        try {
          for (var _b = __values(getAllChildren(stateNode)), _c = _b.next(); !_c.done; _c = _b.next()) {
            var child = _c.value;
            dfs(child);
          }
        } catch (e_1_1) {
          e_1 = {
            error: e_1_1
          };
        } finally {
          try {
            if (_c && !_c.done && (_a3 = _b.return)) _a3.call(_b);
          } finally {
            if (e_1) throw e_1.error;
          }
        }
      }
      dfs(this);
      this.history = this.config.history === true ? "shallow" : this.config.history || false;
      this._transient = !!this.config.always || (!this.config.on ? false : Array.isArray(this.config.on) ? this.config.on.some(function(_a3) {
        var event2 = _a3.event;
        return event2 === NULL_EVENT;
      }) : NULL_EVENT in this.config.on);
      this.strict = !!this.config.strict;
      this.onEntry = toArray(this.config.entry || this.config.onEntry).map(function(action) {
        return toActionObject(action);
      });
      this.onExit = toArray(this.config.exit || this.config.onExit).map(function(action) {
        return toActionObject(action);
      });
      this.meta = this.config.meta;
      this.doneData = this.type === "final" ? this.config.data : void 0;
      this.invoke = toArray(this.config.invoke).map(function(invokeConfig, i2) {
        var _a3, _b;
        if (isMachine(invokeConfig)) {
          var invokeId = createInvokeId(_this.id, i2);
          _this.machine.options.services = __assign((_a3 = {}, _a3[invokeId] = invokeConfig, _a3), _this.machine.options.services);
          return toInvokeDefinition({
            src: invokeId,
            id: invokeId
          });
        } else if (isString(invokeConfig.src)) {
          var invokeId = invokeConfig.id || createInvokeId(_this.id, i2);
          return toInvokeDefinition(__assign(__assign({}, invokeConfig), {
            id: invokeId,
            src: invokeConfig.src
          }));
        } else if (isMachine(invokeConfig.src) || isFunction(invokeConfig.src)) {
          var invokeId = invokeConfig.id || createInvokeId(_this.id, i2);
          _this.machine.options.services = __assign((_b = {}, _b[invokeId] = invokeConfig.src, _b), _this.machine.options.services);
          return toInvokeDefinition(__assign(__assign({
            id: invokeId
          }, invokeConfig), {
            src: invokeId
          }));
        } else {
          var invokeSource = invokeConfig.src;
          return toInvokeDefinition(__assign(__assign({
            id: createInvokeId(_this.id, i2)
          }, invokeConfig), {
            src: invokeSource
          }));
        }
      });
      this.activities = toArray(this.config.activities).concat(this.invoke).map(function(activity) {
        return toActivityDefinition(activity);
      });
      this.transition = this.transition.bind(this);
      this.tags = toArray(this.config.tags);
    }
    StateNode2.prototype._init = function() {
      if (this.__cache.transitions) {
        return;
      }
      getAllStateNodes(this).forEach(function(stateNode) {
        return stateNode.on;
      });
    };
    StateNode2.prototype.withConfig = function(options, context) {
      var _a2 = this.options, actions = _a2.actions, activities = _a2.activities, guards = _a2.guards, services = _a2.services, delays = _a2.delays;
      return new StateNode2(this.config, {
        actions: __assign(__assign({}, actions), options.actions),
        activities: __assign(__assign({}, activities), options.activities),
        guards: __assign(__assign({}, guards), options.guards),
        services: __assign(__assign({}, services), options.services),
        delays: __assign(__assign({}, delays), options.delays)
      }, context !== null && context !== void 0 ? context : this.context);
    };
    StateNode2.prototype.withContext = function(context) {
      return new StateNode2(this.config, this.options, context);
    };
    Object.defineProperty(StateNode2.prototype, "context", {
      get: function() {
        return isFunction(this._context) ? this._context() : this._context;
      },
      enumerable: false,
      configurable: true
    });
    Object.defineProperty(StateNode2.prototype, "definition", {
      /**
       * The well-structured state node definition.
       */
      get: function() {
        return {
          id: this.id,
          key: this.key,
          version: this.version,
          context: this.context,
          type: this.type,
          initial: this.initial,
          history: this.history,
          states: mapValues(this.states, function(state) {
            return state.definition;
          }),
          on: this.on,
          transitions: this.transitions,
          entry: this.onEntry,
          exit: this.onExit,
          activities: this.activities || [],
          meta: this.meta,
          order: this.order || -1,
          data: this.doneData,
          invoke: this.invoke,
          description: this.description,
          tags: this.tags
        };
      },
      enumerable: false,
      configurable: true
    });
    StateNode2.prototype.toJSON = function() {
      return this.definition;
    };
    Object.defineProperty(StateNode2.prototype, "on", {
      /**
       * The mapping of events to transitions.
       */
      get: function() {
        if (this.__cache.on) {
          return this.__cache.on;
        }
        var transitions = this.transitions;
        return this.__cache.on = transitions.reduce(function(map, transition) {
          map[transition.eventType] = map[transition.eventType] || [];
          map[transition.eventType].push(transition);
          return map;
        }, {});
      },
      enumerable: false,
      configurable: true
    });
    Object.defineProperty(StateNode2.prototype, "after", {
      get: function() {
        return this.__cache.delayedTransitions || (this.__cache.delayedTransitions = this.getDelayedTransitions(), this.__cache.delayedTransitions);
      },
      enumerable: false,
      configurable: true
    });
    Object.defineProperty(StateNode2.prototype, "transitions", {
      /**
       * All the transitions that can be taken from this state node.
       */
      get: function() {
        return this.__cache.transitions || (this.__cache.transitions = this.formatTransitions(), this.__cache.transitions);
      },
      enumerable: false,
      configurable: true
    });
    StateNode2.prototype.getCandidates = function(eventName) {
      if (this.__cache.candidates[eventName]) {
        return this.__cache.candidates[eventName];
      }
      var transient = eventName === NULL_EVENT;
      var candidates = this.transitions.filter(function(transition) {
        var sameEventType = transition.eventType === eventName;
        return transient ? sameEventType : sameEventType || transition.eventType === WILDCARD;
      });
      this.__cache.candidates[eventName] = candidates;
      return candidates;
    };
    StateNode2.prototype.getDelayedTransitions = function() {
      var _this = this;
      var afterConfig = this.config.after;
      if (!afterConfig) {
        return [];
      }
      var mutateEntryExit = function(delay4, i2) {
        var delayRef = isFunction(delay4) ? "".concat(_this.id, ":delay[").concat(i2, "]") : delay4;
        var eventType = after2(delayRef, _this.id);
        _this.onEntry.push(send2(eventType, {
          delay: delay4
        }));
        _this.onExit.push(cancel2(eventType));
        return eventType;
      };
      var delayedTransitions = isArray(afterConfig) ? afterConfig.map(function(transition, i2) {
        var eventType = mutateEntryExit(transition.delay, i2);
        return __assign(__assign({}, transition), {
          event: eventType
        });
      }) : flatten(Object.keys(afterConfig).map(function(delay4, i2) {
        var configTransition = afterConfig[delay4];
        var resolvedTransition = isString(configTransition) ? {
          target: configTransition
        } : configTransition;
        var resolvedDelay = !isNaN(+delay4) ? +delay4 : delay4;
        var eventType = mutateEntryExit(resolvedDelay, i2);
        return toArray(resolvedTransition).map(function(transition) {
          return __assign(__assign({}, transition), {
            event: eventType,
            delay: resolvedDelay
          });
        });
      }));
      return delayedTransitions.map(function(delayedTransition) {
        var delay4 = delayedTransition.delay;
        return __assign(__assign({}, _this.formatTransition(delayedTransition)), {
          delay: delay4
        });
      });
    };
    StateNode2.prototype.getStateNodes = function(state) {
      var _a2;
      var _this = this;
      if (!state) {
        return [];
      }
      var stateValue = state instanceof State ? state.value : toStateValue(state, this.delimiter);
      if (isString(stateValue)) {
        var initialStateValue = this.getStateNode(stateValue).initial;
        return initialStateValue !== void 0 ? this.getStateNodes((_a2 = {}, _a2[stateValue] = initialStateValue, _a2)) : [this, this.states[stateValue]];
      }
      var subStateKeys = Object.keys(stateValue);
      var subStateNodes = [this];
      subStateNodes.push.apply(subStateNodes, __spreadArray([], __read(flatten(subStateKeys.map(function(subStateKey) {
        return _this.getStateNode(subStateKey).getStateNodes(stateValue[subStateKey]);
      }))), false));
      return subStateNodes;
    };
    StateNode2.prototype.handles = function(event2) {
      var eventType = getEventType(event2);
      return this.events.includes(eventType);
    };
    StateNode2.prototype.resolveState = function(state) {
      var stateFromConfig = state instanceof State ? state : State.create(state);
      var configuration = Array.from(getConfiguration([], this.getStateNodes(stateFromConfig.value)));
      return new State(__assign(__assign({}, stateFromConfig), {
        value: this.resolve(stateFromConfig.value),
        configuration,
        done: isInFinalState(configuration, this),
        tags: getTagsFromConfiguration(configuration),
        machine: this.machine
      }));
    };
    StateNode2.prototype.transitionLeafNode = function(stateValue, state, _event) {
      var stateNode = this.getStateNode(stateValue);
      var next = stateNode.next(state, _event);
      if (!next || !next.transitions.length) {
        return this.next(state, _event);
      }
      return next;
    };
    StateNode2.prototype.transitionCompoundNode = function(stateValue, state, _event) {
      var subStateKeys = Object.keys(stateValue);
      var stateNode = this.getStateNode(subStateKeys[0]);
      var next = stateNode._transition(stateValue[subStateKeys[0]], state, _event);
      if (!next || !next.transitions.length) {
        return this.next(state, _event);
      }
      return next;
    };
    StateNode2.prototype.transitionParallelNode = function(stateValue, state, _event) {
      var e_2, _a2;
      var transitionMap = {};
      try {
        for (var _b = __values(Object.keys(stateValue)), _c = _b.next(); !_c.done; _c = _b.next()) {
          var subStateKey = _c.value;
          var subStateValue = stateValue[subStateKey];
          if (!subStateValue) {
            continue;
          }
          var subStateNode = this.getStateNode(subStateKey);
          var next = subStateNode._transition(subStateValue, state, _event);
          if (next) {
            transitionMap[subStateKey] = next;
          }
        }
      } catch (e_2_1) {
        e_2 = {
          error: e_2_1
        };
      } finally {
        try {
          if (_c && !_c.done && (_a2 = _b.return)) _a2.call(_b);
        } finally {
          if (e_2) throw e_2.error;
        }
      }
      var stateTransitions = Object.keys(transitionMap).map(function(key) {
        return transitionMap[key];
      });
      var enabledTransitions = flatten(stateTransitions.map(function(st) {
        return st.transitions;
      }));
      var willTransition = stateTransitions.some(function(st) {
        return st.transitions.length > 0;
      });
      if (!willTransition) {
        return this.next(state, _event);
      }
      var configuration = flatten(Object.keys(transitionMap).map(function(key) {
        return transitionMap[key].configuration;
      }));
      return {
        transitions: enabledTransitions,
        exitSet: flatten(stateTransitions.map(function(t3) {
          return t3.exitSet;
        })),
        configuration,
        source: state,
        actions: flatten(Object.keys(transitionMap).map(function(key) {
          return transitionMap[key].actions;
        }))
      };
    };
    StateNode2.prototype._transition = function(stateValue, state, _event) {
      if (isString(stateValue)) {
        return this.transitionLeafNode(stateValue, state, _event);
      }
      if (Object.keys(stateValue).length === 1) {
        return this.transitionCompoundNode(stateValue, state, _event);
      }
      return this.transitionParallelNode(stateValue, state, _event);
    };
    StateNode2.prototype.getTransitionData = function(state, event2) {
      return this._transition(state.value, state, toSCXMLEvent(event2));
    };
    StateNode2.prototype.next = function(state, _event) {
      var e_3, _a2;
      var _this = this;
      var eventName = _event.name;
      var actions = [];
      var nextStateNodes = [];
      var selectedTransition;
      try {
        for (var _b = __values(this.getCandidates(eventName)), _c = _b.next(); !_c.done; _c = _b.next()) {
          var candidate = _c.value;
          var cond = candidate.cond, stateIn = candidate.in;
          var resolvedContext = state.context;
          var isInState = stateIn ? isString(stateIn) && isStateId(stateIn) ? (
            // Check if in state by ID
            state.matches(toStateValue(this.getStateNodeById(stateIn).path, this.delimiter))
          ) : (
            // Check if in state by relative grandparent
            matchesState(toStateValue(stateIn, this.delimiter), path(this.path.slice(0, -2))(state.value))
          ) : true;
          var guardPassed = false;
          try {
            guardPassed = !cond || evaluateGuard(this.machine, cond, resolvedContext, _event, state);
          } catch (err) {
            throw new Error("Unable to evaluate guard '".concat(cond.name || cond.type, "' in transition for event '").concat(eventName, "' in state node '").concat(this.id, "':\n").concat(err.message));
          }
          if (guardPassed && isInState) {
            if (candidate.target !== void 0) {
              nextStateNodes = candidate.target;
            }
            actions.push.apply(actions, __spreadArray([], __read(candidate.actions), false));
            selectedTransition = candidate;
            break;
          }
        }
      } catch (e_3_1) {
        e_3 = {
          error: e_3_1
        };
      } finally {
        try {
          if (_c && !_c.done && (_a2 = _b.return)) _a2.call(_b);
        } finally {
          if (e_3) throw e_3.error;
        }
      }
      if (!selectedTransition) {
        return void 0;
      }
      if (!nextStateNodes.length) {
        return {
          transitions: [selectedTransition],
          exitSet: [],
          configuration: state.value ? [this] : [],
          source: state,
          actions
        };
      }
      var allNextStateNodes = flatten(nextStateNodes.map(function(stateNode) {
        return _this.getRelativeStateNodes(stateNode, state.historyValue);
      }));
      var isInternal = !!selectedTransition.internal;
      return {
        transitions: [selectedTransition],
        exitSet: isInternal ? [] : flatten(nextStateNodes.map(function(targetNode) {
          return _this.getPotentiallyReenteringNodes(targetNode);
        })),
        configuration: allNextStateNodes,
        source: state,
        actions
      };
    };
    StateNode2.prototype.getPotentiallyReenteringNodes = function(targetNode) {
      if (this.order < targetNode.order) {
        return [this];
      }
      var nodes = [];
      var marker = this;
      var possibleAncestor = targetNode;
      while (marker && marker !== possibleAncestor) {
        nodes.push(marker);
        marker = marker.parent;
      }
      if (marker !== possibleAncestor) {
        return [];
      }
      nodes.push(possibleAncestor);
      return nodes;
    };
    StateNode2.prototype.getActions = function(resolvedConfig, isDone, transition, currentContext, _event, prevState, predictableExec) {
      var e_4, _a2, e_5, _b;
      var _this = this;
      var prevConfig = prevState ? getConfiguration([], this.getStateNodes(prevState.value)) : [];
      var entrySet = /* @__PURE__ */ new Set();
      try {
        for (var _c = __values(Array.from(resolvedConfig).sort(function(a2, b) {
          return a2.order - b.order;
        })), _d = _c.next(); !_d.done; _d = _c.next()) {
          var sn = _d.value;
          if (!has(prevConfig, sn) || has(transition.exitSet, sn) || sn.parent && entrySet.has(sn.parent)) {
            entrySet.add(sn);
          }
        }
      } catch (e_4_1) {
        e_4 = {
          error: e_4_1
        };
      } finally {
        try {
          if (_d && !_d.done && (_a2 = _c.return)) _a2.call(_c);
        } finally {
          if (e_4) throw e_4.error;
        }
      }
      try {
        for (var prevConfig_1 = __values(prevConfig), prevConfig_1_1 = prevConfig_1.next(); !prevConfig_1_1.done; prevConfig_1_1 = prevConfig_1.next()) {
          var sn = prevConfig_1_1.value;
          if (!has(resolvedConfig, sn) || has(transition.exitSet, sn.parent)) {
            transition.exitSet.push(sn);
          }
        }
      } catch (e_5_1) {
        e_5 = {
          error: e_5_1
        };
      } finally {
        try {
          if (prevConfig_1_1 && !prevConfig_1_1.done && (_b = prevConfig_1.return)) _b.call(prevConfig_1);
        } finally {
          if (e_5) throw e_5.error;
        }
      }
      transition.exitSet.sort(function(a2, b) {
        return b.order - a2.order;
      });
      var entryStates = Array.from(entrySet).sort(function(a2, b) {
        return a2.order - b.order;
      });
      var exitStates = new Set(transition.exitSet);
      var doneEvents = flatten(entryStates.map(function(sn2) {
        var events2 = [];
        if (sn2.type !== "final") {
          return events2;
        }
        var parent = sn2.parent;
        if (!parent.parent) {
          return events2;
        }
        events2.push(
          done(sn2.id, sn2.doneData),
          // TODO: deprecate - final states should not emit done events for their own state.
          done(parent.id, sn2.doneData ? mapContext(sn2.doneData, currentContext, _event) : void 0)
        );
        var grandparent = parent.parent;
        if (grandparent.type === "parallel") {
          if (getChildren(grandparent).every(function(parentNode) {
            return isInFinalState(transition.configuration, parentNode);
          })) {
            events2.push(done(grandparent.id));
          }
        }
        return events2;
      }));
      var entryActions = entryStates.map(function(stateNode) {
        var entryActions2 = stateNode.onEntry;
        var invokeActions = stateNode.activities.map(function(activity) {
          return start2(activity);
        });
        return {
          type: "entry",
          actions: toActionObjects(predictableExec ? __spreadArray(__spreadArray([], __read(entryActions2), false), __read(invokeActions), false) : __spreadArray(__spreadArray([], __read(invokeActions), false), __read(entryActions2), false), _this.machine.options.actions)
        };
      }).concat({
        type: "state_done",
        actions: doneEvents.map(function(event2) {
          return raise2(event2);
        })
      });
      var exitActions = Array.from(exitStates).map(function(stateNode) {
        return {
          type: "exit",
          actions: toActionObjects(__spreadArray(__spreadArray([], __read(stateNode.onExit), false), __read(stateNode.activities.map(function(activity) {
            return stop2(activity);
          })), false), _this.machine.options.actions)
        };
      });
      var actions = exitActions.concat({
        type: "transition",
        actions: toActionObjects(transition.actions, this.machine.options.actions)
      }).concat(entryActions);
      if (isDone) {
        var stopActions = toActionObjects(flatten(__spreadArray([], __read(resolvedConfig), false).sort(function(a2, b) {
          return b.order - a2.order;
        }).map(function(stateNode) {
          return stateNode.onExit;
        })), this.machine.options.actions).filter(function(action) {
          return !isRaisableAction(action);
        });
        return actions.concat({
          type: "stop",
          actions: stopActions
        });
      }
      return actions;
    };
    StateNode2.prototype.transition = function(state, event2, context, exec) {
      if (state === void 0) {
        state = this.initialState;
      }
      var _event = toSCXMLEvent(event2);
      var currentState;
      if (state instanceof State) {
        currentState = context === void 0 ? state : this.resolveState(State.from(state, context));
      } else {
        var resolvedStateValue = isString(state) ? this.resolve(pathToStateValue(this.getResolvedPath(state))) : this.resolve(state);
        var resolvedContext = context !== null && context !== void 0 ? context : this.machine.context;
        currentState = this.resolveState(State.from(resolvedStateValue, resolvedContext));
      }
      if (!IS_PRODUCTION && _event.name === WILDCARD) {
        throw new Error("An event cannot have the wildcard type ('".concat(WILDCARD, "')"));
      }
      if (this.strict) {
        if (!this.events.includes(_event.name) && !isBuiltInEvent(_event.name)) {
          throw new Error("Machine '".concat(this.id, "' does not accept event '").concat(_event.name, "'"));
        }
      }
      var stateTransition = this._transition(currentState.value, currentState, _event) || {
        transitions: [],
        configuration: [],
        exitSet: [],
        source: currentState,
        actions: []
      };
      var prevConfig = getConfiguration([], this.getStateNodes(currentState.value));
      var resolvedConfig = stateTransition.configuration.length ? getConfiguration(prevConfig, stateTransition.configuration) : prevConfig;
      stateTransition.configuration = __spreadArray([], __read(resolvedConfig), false);
      return this.resolveTransition(stateTransition, currentState, currentState.context, exec, _event);
    };
    StateNode2.prototype.resolveRaisedTransition = function(state, _event, originalEvent, predictableExec) {
      var _a2;
      var currentActions = state.actions;
      state = this.transition(state, _event, void 0, predictableExec);
      state._event = originalEvent;
      state.event = originalEvent.data;
      (_a2 = state.actions).unshift.apply(_a2, __spreadArray([], __read(currentActions), false));
      return state;
    };
    StateNode2.prototype.resolveTransition = function(stateTransition, currentState, context, predictableExec, _event) {
      var e_6, _a2, e_7, _b;
      var _this = this;
      if (_event === void 0) {
        _event = initEvent;
      }
      var configuration = stateTransition.configuration;
      var willTransition = !currentState || stateTransition.transitions.length > 0;
      var resolvedConfiguration = willTransition ? stateTransition.configuration : currentState ? currentState.configuration : [];
      var isDone = isInFinalState(resolvedConfiguration, this);
      var resolvedStateValue = willTransition ? getValue(this.machine, configuration) : void 0;
      var historyValue = currentState ? currentState.historyValue ? currentState.historyValue : stateTransition.source ? this.machine.historyValue(currentState.value) : void 0 : void 0;
      var actionBlocks = this.getActions(new Set(resolvedConfiguration), isDone, stateTransition, context, _event, currentState, predictableExec);
      var activities = currentState ? __assign({}, currentState.activities) : {};
      try {
        for (var actionBlocks_1 = __values(actionBlocks), actionBlocks_1_1 = actionBlocks_1.next(); !actionBlocks_1_1.done; actionBlocks_1_1 = actionBlocks_1.next()) {
          var block = actionBlocks_1_1.value;
          try {
            for (var _c = (e_7 = void 0, __values(block.actions)), _d = _c.next(); !_d.done; _d = _c.next()) {
              var action = _d.value;
              if (action.type === start) {
                activities[action.activity.id || action.activity.type] = action;
              } else if (action.type === stop) {
                activities[action.activity.id || action.activity.type] = false;
              }
            }
          } catch (e_7_1) {
            e_7 = {
              error: e_7_1
            };
          } finally {
            try {
              if (_d && !_d.done && (_b = _c.return)) _b.call(_c);
            } finally {
              if (e_7) throw e_7.error;
            }
          }
        }
      } catch (e_6_1) {
        e_6 = {
          error: e_6_1
        };
      } finally {
        try {
          if (actionBlocks_1_1 && !actionBlocks_1_1.done && (_a2 = actionBlocks_1.return)) _a2.call(actionBlocks_1);
        } finally {
          if (e_6) throw e_6.error;
        }
      }
      var _e = __read(resolveActions(this, currentState, context, _event, actionBlocks, predictableExec, this.machine.config.predictableActionArguments || this.machine.config.preserveActionOrder), 2), resolvedActions = _e[0], updatedContext = _e[1];
      var _f = __read(partition(resolvedActions, isRaisableAction), 2), raisedEvents = _f[0], nonRaisedActions = _f[1];
      var invokeActions = resolvedActions.filter(function(action2) {
        var _a3;
        return action2.type === start && ((_a3 = action2.activity) === null || _a3 === void 0 ? void 0 : _a3.type) === invoke;
      });
      var children2 = invokeActions.reduce(function(acc, action2) {
        acc[action2.activity.id] = createInvocableActor(action2.activity, _this.machine, updatedContext, _event);
        return acc;
      }, currentState ? __assign({}, currentState.children) : {});
      var nextState = new State({
        value: resolvedStateValue || currentState.value,
        context: updatedContext,
        _event,
        // Persist _sessionid between states
        _sessionid: currentState ? currentState._sessionid : null,
        historyValue: resolvedStateValue ? historyValue ? updateHistoryValue(historyValue, resolvedStateValue) : void 0 : currentState ? currentState.historyValue : void 0,
        history: !resolvedStateValue || stateTransition.source ? currentState : void 0,
        actions: resolvedStateValue ? nonRaisedActions : [],
        activities: resolvedStateValue ? activities : currentState ? currentState.activities : {},
        events: [],
        configuration: resolvedConfiguration,
        transitions: stateTransition.transitions,
        children: children2,
        done: isDone,
        tags: getTagsFromConfiguration(resolvedConfiguration),
        machine: this
      });
      var didUpdateContext = context !== updatedContext;
      nextState.changed = _event.name === update || didUpdateContext;
      var history = nextState.history;
      if (history) {
        delete history.history;
      }
      var hasAlwaysTransitions = !isDone && (this._transient || configuration.some(function(stateNode) {
        return stateNode._transient;
      }));
      if (!willTransition && (!hasAlwaysTransitions || _event.name === NULL_EVENT)) {
        return nextState;
      }
      var maybeNextState = nextState;
      if (!isDone) {
        if (hasAlwaysTransitions) {
          maybeNextState = this.resolveRaisedTransition(maybeNextState, {
            type: nullEvent
          }, _event, predictableExec);
        }
        while (raisedEvents.length) {
          var raisedEvent = raisedEvents.shift();
          maybeNextState = this.resolveRaisedTransition(maybeNextState, raisedEvent._event, _event, predictableExec);
        }
      }
      var changed = maybeNextState.changed || (history ? !!maybeNextState.actions.length || didUpdateContext || typeof history.value !== typeof maybeNextState.value || !stateValuesEqual(maybeNextState.value, history.value) : void 0);
      maybeNextState.changed = changed;
      maybeNextState.history = history;
      return maybeNextState;
    };
    StateNode2.prototype.getStateNode = function(stateKey) {
      if (isStateId(stateKey)) {
        return this.machine.getStateNodeById(stateKey);
      }
      if (!this.states) {
        throw new Error("Unable to retrieve child state '".concat(stateKey, "' from '").concat(this.id, "'; no child states exist."));
      }
      var result = this.states[stateKey];
      if (!result) {
        throw new Error("Child state '".concat(stateKey, "' does not exist on '").concat(this.id, "'"));
      }
      return result;
    };
    StateNode2.prototype.getStateNodeById = function(stateId) {
      var resolvedStateId = isStateId(stateId) ? stateId.slice(STATE_IDENTIFIER.length) : stateId;
      if (resolvedStateId === this.id) {
        return this;
      }
      var stateNode = this.machine.idMap[resolvedStateId];
      if (!stateNode) {
        throw new Error("Child state node '#".concat(resolvedStateId, "' does not exist on machine '").concat(this.id, "'"));
      }
      return stateNode;
    };
    StateNode2.prototype.getStateNodeByPath = function(statePath) {
      if (typeof statePath === "string" && isStateId(statePath)) {
        try {
          return this.getStateNodeById(statePath.slice(1));
        } catch (e) {
        }
      }
      var arrayStatePath = toStatePath(statePath, this.delimiter).slice();
      var currentStateNode = this;
      while (arrayStatePath.length) {
        var key = arrayStatePath.shift();
        if (!key.length) {
          break;
        }
        currentStateNode = currentStateNode.getStateNode(key);
      }
      return currentStateNode;
    };
    StateNode2.prototype.resolve = function(stateValue) {
      var _a2;
      var _this = this;
      if (!stateValue) {
        return this.initialStateValue || EMPTY_OBJECT;
      }
      switch (this.type) {
        case "parallel":
          return mapValues(this.initialStateValue, function(subStateValue, subStateKey) {
            return subStateValue ? _this.getStateNode(subStateKey).resolve(stateValue[subStateKey] || subStateValue) : EMPTY_OBJECT;
          });
        case "compound":
          if (isString(stateValue)) {
            var subStateNode = this.getStateNode(stateValue);
            if (subStateNode.type === "parallel" || subStateNode.type === "compound") {
              return _a2 = {}, _a2[stateValue] = subStateNode.initialStateValue, _a2;
            }
            return stateValue;
          }
          if (!Object.keys(stateValue).length) {
            return this.initialStateValue || {};
          }
          return mapValues(stateValue, function(subStateValue, subStateKey) {
            return subStateValue ? _this.getStateNode(subStateKey).resolve(subStateValue) : EMPTY_OBJECT;
          });
        default:
          return stateValue || EMPTY_OBJECT;
      }
    };
    StateNode2.prototype.getResolvedPath = function(stateIdentifier) {
      if (isStateId(stateIdentifier)) {
        var stateNode = this.machine.idMap[stateIdentifier.slice(STATE_IDENTIFIER.length)];
        if (!stateNode) {
          throw new Error("Unable to find state node '".concat(stateIdentifier, "'"));
        }
        return stateNode.path;
      }
      return toStatePath(stateIdentifier, this.delimiter);
    };
    Object.defineProperty(StateNode2.prototype, "initialStateValue", {
      get: function() {
        var _a2;
        if (this.__cache.initialStateValue) {
          return this.__cache.initialStateValue;
        }
        var initialStateValue;
        if (this.type === "parallel") {
          initialStateValue = mapFilterValues(this.states, function(state) {
            return state.initialStateValue || EMPTY_OBJECT;
          }, function(stateNode) {
            return !(stateNode.type === "history");
          });
        } else if (this.initial !== void 0) {
          if (!this.states[this.initial]) {
            throw new Error("Initial state '".concat(this.initial, "' not found on '").concat(this.key, "'"));
          }
          initialStateValue = isLeafNode(this.states[this.initial]) ? this.initial : (_a2 = {}, _a2[this.initial] = this.states[this.initial].initialStateValue, _a2);
        } else {
          initialStateValue = {};
        }
        this.__cache.initialStateValue = initialStateValue;
        return this.__cache.initialStateValue;
      },
      enumerable: false,
      configurable: true
    });
    StateNode2.prototype.getInitialState = function(stateValue, context) {
      this._init();
      var configuration = this.getStateNodes(stateValue);
      return this.resolveTransition({
        configuration,
        exitSet: [],
        transitions: [],
        source: void 0,
        actions: []
      }, void 0, context !== null && context !== void 0 ? context : this.machine.context, void 0);
    };
    Object.defineProperty(StateNode2.prototype, "initialState", {
      /**
       * The initial State instance, which includes all actions to be executed from
       * entering the initial state.
       */
      get: function() {
        var initialStateValue = this.initialStateValue;
        if (!initialStateValue) {
          throw new Error("Cannot retrieve initial state from simple state '".concat(this.id, "'."));
        }
        return this.getInitialState(initialStateValue);
      },
      enumerable: false,
      configurable: true
    });
    Object.defineProperty(StateNode2.prototype, "target", {
      /**
       * The target state value of the history state node, if it exists. This represents the
       * default state value to transition to if no history value exists yet.
       */
      get: function() {
        var target;
        if (this.type === "history") {
          var historyConfig = this.config;
          if (isString(historyConfig.target)) {
            target = isStateId(historyConfig.target) ? pathToStateValue(this.machine.getStateNodeById(historyConfig.target).path.slice(this.path.length - 1)) : historyConfig.target;
          } else {
            target = historyConfig.target;
          }
        }
        return target;
      },
      enumerable: false,
      configurable: true
    });
    StateNode2.prototype.getRelativeStateNodes = function(relativeStateId, historyValue, resolve) {
      if (resolve === void 0) {
        resolve = true;
      }
      return resolve ? relativeStateId.type === "history" ? relativeStateId.resolveHistory(historyValue) : relativeStateId.initialStateNodes : [relativeStateId];
    };
    Object.defineProperty(StateNode2.prototype, "initialStateNodes", {
      get: function() {
        var _this = this;
        if (isLeafNode(this)) {
          return [this];
        }
        if (this.type === "compound" && !this.initial) {
          if (!IS_PRODUCTION) {
            warn(false, "Compound state node '".concat(this.id, "' has no initial state."));
          }
          return [this];
        }
        var initialStateNodePaths = toStatePaths(this.initialStateValue);
        return flatten(initialStateNodePaths.map(function(initialPath) {
          return _this.getFromRelativePath(initialPath);
        }));
      },
      enumerable: false,
      configurable: true
    });
    StateNode2.prototype.getFromRelativePath = function(relativePath) {
      if (!relativePath.length) {
        return [this];
      }
      var _a2 = __read(relativePath), stateKey = _a2[0], childStatePath = _a2.slice(1);
      if (!this.states) {
        throw new Error("Cannot retrieve subPath '".concat(stateKey, "' from node with no states"));
      }
      var childStateNode = this.getStateNode(stateKey);
      if (childStateNode.type === "history") {
        return childStateNode.resolveHistory();
      }
      if (!this.states[stateKey]) {
        throw new Error("Child state '".concat(stateKey, "' does not exist on '").concat(this.id, "'"));
      }
      return this.states[stateKey].getFromRelativePath(childStatePath);
    };
    StateNode2.prototype.historyValue = function(relativeStateValue) {
      if (!Object.keys(this.states).length) {
        return void 0;
      }
      return {
        current: relativeStateValue || this.initialStateValue,
        states: mapFilterValues(this.states, function(stateNode, key) {
          if (!relativeStateValue) {
            return stateNode.historyValue();
          }
          var subStateValue = isString(relativeStateValue) ? void 0 : relativeStateValue[key];
          return stateNode.historyValue(subStateValue || stateNode.initialStateValue);
        }, function(stateNode) {
          return !stateNode.history;
        })
      };
    };
    StateNode2.prototype.resolveHistory = function(historyValue) {
      var _this = this;
      if (this.type !== "history") {
        return [this];
      }
      var parent = this.parent;
      if (!historyValue) {
        var historyTarget = this.target;
        return historyTarget ? flatten(toStatePaths(historyTarget).map(function(relativeChildPath) {
          return parent.getFromRelativePath(relativeChildPath);
        })) : parent.initialStateNodes;
      }
      var subHistoryValue = nestedPath(parent.path, "states")(historyValue).current;
      if (isString(subHistoryValue)) {
        return [parent.getStateNode(subHistoryValue)];
      }
      return flatten(toStatePaths(subHistoryValue).map(function(subStatePath) {
        return _this.history === "deep" ? parent.getFromRelativePath(subStatePath) : [parent.states[subStatePath[0]]];
      }));
    };
    Object.defineProperty(StateNode2.prototype, "stateIds", {
      /**
       * All the state node IDs of this state node and its descendant state nodes.
       */
      get: function() {
        var _this = this;
        var childStateIds = flatten(Object.keys(this.states).map(function(stateKey) {
          return _this.states[stateKey].stateIds;
        }));
        return [this.id].concat(childStateIds);
      },
      enumerable: false,
      configurable: true
    });
    Object.defineProperty(StateNode2.prototype, "events", {
      /**
       * All the event types accepted by this state node and its descendants.
       */
      get: function() {
        var e_8, _a2, e_9, _b;
        if (this.__cache.events) {
          return this.__cache.events;
        }
        var states = this.states;
        var events2 = new Set(this.ownEvents);
        if (states) {
          try {
            for (var _c = __values(Object.keys(states)), _d = _c.next(); !_d.done; _d = _c.next()) {
              var stateId = _d.value;
              var state = states[stateId];
              if (state.states) {
                try {
                  for (var _e = (e_9 = void 0, __values(state.events)), _f = _e.next(); !_f.done; _f = _e.next()) {
                    var event_1 = _f.value;
                    events2.add("".concat(event_1));
                  }
                } catch (e_9_1) {
                  e_9 = {
                    error: e_9_1
                  };
                } finally {
                  try {
                    if (_f && !_f.done && (_b = _e.return)) _b.call(_e);
                  } finally {
                    if (e_9) throw e_9.error;
                  }
                }
              }
            }
          } catch (e_8_1) {
            e_8 = {
              error: e_8_1
            };
          } finally {
            try {
              if (_d && !_d.done && (_a2 = _c.return)) _a2.call(_c);
            } finally {
              if (e_8) throw e_8.error;
            }
          }
        }
        return this.__cache.events = Array.from(events2);
      },
      enumerable: false,
      configurable: true
    });
    Object.defineProperty(StateNode2.prototype, "ownEvents", {
      /**
       * All the events that have transitions directly from this state node.
       *
       * Excludes any inert events.
       */
      get: function() {
        var events2 = new Set(this.transitions.filter(function(transition) {
          return !(!transition.target && !transition.actions.length && transition.internal);
        }).map(function(transition) {
          return transition.eventType;
        }));
        return Array.from(events2);
      },
      enumerable: false,
      configurable: true
    });
    StateNode2.prototype.resolveTarget = function(_target) {
      var _this = this;
      if (_target === void 0) {
        return void 0;
      }
      return _target.map(function(target) {
        if (!isString(target)) {
          return target;
        }
        var isInternalTarget = target[0] === _this.delimiter;
        if (isInternalTarget && !_this.parent) {
          return _this.getStateNodeByPath(target.slice(1));
        }
        var resolvedTarget = isInternalTarget ? _this.key + target : target;
        if (_this.parent) {
          try {
            var targetStateNode = _this.parent.getStateNodeByPath(resolvedTarget);
            return targetStateNode;
          } catch (err) {
            throw new Error("Invalid transition definition for state node '".concat(_this.id, "':\n").concat(err.message));
          }
        } else {
          return _this.getStateNodeByPath(resolvedTarget);
        }
      });
    };
    StateNode2.prototype.formatTransition = function(transitionConfig) {
      var _this = this;
      var normalizedTarget = normalizeTarget(transitionConfig.target);
      var internal = "internal" in transitionConfig ? transitionConfig.internal : normalizedTarget ? normalizedTarget.some(function(_target) {
        return isString(_target) && _target[0] === _this.delimiter;
      }) : true;
      var guards = this.machine.options.guards;
      var target = this.resolveTarget(normalizedTarget);
      var transition = __assign(__assign({}, transitionConfig), {
        actions: toActionObjects(toArray(transitionConfig.actions)),
        cond: toGuard(transitionConfig.cond, guards),
        target,
        source: this,
        internal,
        eventType: transitionConfig.event,
        toJSON: function() {
          return __assign(__assign({}, transition), {
            target: transition.target ? transition.target.map(function(t3) {
              return "#".concat(t3.id);
            }) : void 0,
            source: "#".concat(_this.id)
          });
        }
      });
      return transition;
    };
    StateNode2.prototype.formatTransitions = function() {
      var e_10, _a2;
      var _this = this;
      var onConfig;
      if (!this.config.on) {
        onConfig = [];
      } else if (Array.isArray(this.config.on)) {
        onConfig = this.config.on;
      } else {
        var _b = this.config.on, _c = WILDCARD, _d = _b[_c], wildcardConfigs = _d === void 0 ? [] : _d, strictTransitionConfigs_1 = __rest(_b, [typeof _c === "symbol" ? _c : _c + ""]);
        onConfig = flatten(Object.keys(strictTransitionConfigs_1).map(function(key) {
          if (!IS_PRODUCTION && key === NULL_EVENT) {
            warn(false, "Empty string transition configs (e.g., `{ on: { '': ... }}`) for transient transitions are deprecated. Specify the transition in the `{ always: ... }` property instead. " + 'Please check the `on` configuration for "#'.concat(_this.id, '".'));
          }
          var transitionConfigArray = toTransitionConfigArray(key, strictTransitionConfigs_1[key]);
          if (!IS_PRODUCTION) {
            validateArrayifiedTransitions(_this, key, transitionConfigArray);
          }
          return transitionConfigArray;
        }).concat(toTransitionConfigArray(WILDCARD, wildcardConfigs)));
      }
      var eventlessConfig = this.config.always ? toTransitionConfigArray("", this.config.always) : [];
      var doneConfig = this.config.onDone ? toTransitionConfigArray(String(done(this.id)), this.config.onDone) : [];
      if (!IS_PRODUCTION) {
        warn(!(this.config.onDone && !this.parent), 'Root nodes cannot have an ".onDone" transition. Please check the config of "'.concat(this.id, '".'));
      }
      var invokeConfig = flatten(this.invoke.map(function(invokeDef) {
        var settleTransitions = [];
        if (invokeDef.onDone) {
          settleTransitions.push.apply(settleTransitions, __spreadArray([], __read(toTransitionConfigArray(String(doneInvoke(invokeDef.id)), invokeDef.onDone)), false));
        }
        if (invokeDef.onError) {
          settleTransitions.push.apply(settleTransitions, __spreadArray([], __read(toTransitionConfigArray(String(error2(invokeDef.id)), invokeDef.onError)), false));
        }
        return settleTransitions;
      }));
      var delayedTransitions = this.after;
      var formattedTransitions = flatten(__spreadArray(__spreadArray(__spreadArray(__spreadArray([], __read(doneConfig), false), __read(invokeConfig), false), __read(onConfig), false), __read(eventlessConfig), false).map(function(transitionConfig) {
        return toArray(transitionConfig).map(function(transition) {
          return _this.formatTransition(transition);
        });
      }));
      try {
        for (var delayedTransitions_1 = __values(delayedTransitions), delayedTransitions_1_1 = delayedTransitions_1.next(); !delayedTransitions_1_1.done; delayedTransitions_1_1 = delayedTransitions_1.next()) {
          var delayedTransition = delayedTransitions_1_1.value;
          formattedTransitions.push(delayedTransition);
        }
      } catch (e_10_1) {
        e_10 = {
          error: e_10_1
        };
      } finally {
        try {
          if (delayedTransitions_1_1 && !delayedTransitions_1_1.done && (_a2 = delayedTransitions_1.return)) _a2.call(delayedTransitions_1);
        } finally {
          if (e_10) throw e_10.error;
        }
      }
      return formattedTransitions;
    };
    return StateNode2;
  }()
);

// node_modules/xstate/es/Machine.js
function Machine(config2, options, initialContext) {
  if (initialContext === void 0) {
    initialContext = config2.context;
  }
  return new StateNode(config2, options, initialContext);
}

// node_modules/xstate/es/index.js
var assign3 = assign2;

// node_modules/react-spring-bottom-sheet/node_modules/@xstate/react/es/types.js
var ReactEffectType;
(function(ReactEffectType2) {
  ReactEffectType2[ReactEffectType2["Effect"] = 1] = "Effect";
  ReactEffectType2[ReactEffectType2["LayoutEffect"] = 2] = "LayoutEffect";
})(ReactEffectType || (ReactEffectType = {}));

// node_modules/react-spring-bottom-sheet/node_modules/@xstate/react/es/useInterpret.js
var import_react5 = __toESM(require_react());

// node_modules/use-isomorphic-layout-effect/dist/use-isomorphic-layout-effect.browser.esm.js
var import_react3 = __toESM(require_react());
var index = import_react3.useLayoutEffect;

// node_modules/react-spring-bottom-sheet/node_modules/@xstate/react/es/useConstant.js
var React2 = __toESM(require_react());
function useConstant(fn) {
  var ref = React2.useRef();
  if (!ref.current) {
    ref.current = { v: fn() };
  }
  return ref.current.v;
}

// node_modules/react-spring-bottom-sheet/node_modules/@xstate/react/es/useReactEffectActions.js
var import_react4 = __toESM(require_react());

// node_modules/react-spring-bottom-sheet/node_modules/@xstate/react/es/utils.js
var __read2 = function(o2, n2) {
  var m = typeof Symbol === "function" && o2[Symbol.iterator];
  if (!m) return o2;
  var i2 = m.call(o2), r2, ar = [], e;
  try {
    while ((n2 === void 0 || n2-- > 0) && !(r2 = i2.next()).done) ar.push(r2.value);
  } catch (error3) {
    e = { error: error3 };
  } finally {
    try {
      if (r2 && !r2.done && (m = i2["return"])) m.call(i2);
    } finally {
      if (e) throw e.error;
    }
  }
  return ar;
};
var __values2 = function(o2) {
  var s2 = typeof Symbol === "function" && Symbol.iterator, m = s2 && o2[s2], i2 = 0;
  if (m) return m.call(o2);
  if (o2 && typeof o2.length === "number") return {
    next: function() {
      if (o2 && i2 >= o2.length) o2 = void 0;
      return { value: o2 && o2[i2++], done: !o2 };
    }
  };
  throw new TypeError(s2 ? "Object is not iterable." : "Symbol.iterator is not defined.");
};
function partition2(items, predicate) {
  var e_1, _a2;
  var _b = __read2([[], []], 2), truthy = _b[0], falsy = _b[1];
  try {
    for (var items_1 = __values2(items), items_1_1 = items_1.next(); !items_1_1.done; items_1_1 = items_1.next()) {
      var item = items_1_1.value;
      if (predicate(item)) {
        truthy.push(item);
      } else {
        falsy.push(item);
      }
    }
  } catch (e_1_1) {
    e_1 = { error: e_1_1 };
  } finally {
    try {
      if (items_1_1 && !items_1_1.done && (_a2 = items_1.return)) _a2.call(items_1);
    } finally {
      if (e_1) throw e_1.error;
    }
  }
  return [truthy, falsy];
}

// node_modules/react-spring-bottom-sheet/node_modules/@xstate/react/es/useReactEffectActions.js
var __read3 = function(o2, n2) {
  var m = typeof Symbol === "function" && o2[Symbol.iterator];
  if (!m) return o2;
  var i2 = m.call(o2), r2, ar = [], e;
  try {
    while ((n2 === void 0 || n2-- > 0) && !(r2 = i2.next()).done) ar.push(r2.value);
  } catch (error3) {
    e = { error: error3 };
  } finally {
    try {
      if (r2 && !r2.done && (m = i2["return"])) m.call(i2);
    } finally {
      if (e) throw e.error;
    }
  }
  return ar;
};
var __spreadArray2 = function(to, from, pack) {
  if (pack || arguments.length === 2) for (var i2 = 0, l2 = from.length, ar; i2 < l2; i2++) {
    if (ar || !(i2 in from)) {
      if (!ar) ar = Array.prototype.slice.call(from, 0, i2);
      ar[i2] = from[i2];
    }
  }
  return to.concat(ar || Array.prototype.slice.call(from));
};
function executeEffect(action, state) {
  var exec = action.exec;
  var originalExec = exec(state.context, state._event.data, {
    action,
    state,
    _event: state._event
  });
  originalExec();
}
function useReactEffectActions(service) {
  var effectActionsRef = (0, import_react4.useRef)([]);
  var layoutEffectActionsRef = (0, import_react4.useRef)([]);
  index(function() {
    var sub = service.subscribe(function(currentState) {
      var _a2, _b;
      if (currentState.actions.length) {
        var reactEffectActions = currentState.actions.filter(function(action) {
          return typeof action.exec === "function" && "__effect" in action.exec;
        });
        var _c = __read3(partition2(reactEffectActions, function(action) {
          return action.exec.__effect === ReactEffectType.Effect;
        }), 2), effectActions = _c[0], layoutEffectActions = _c[1];
        (_a2 = effectActionsRef.current).push.apply(_a2, __spreadArray2([], __read3(effectActions.map(function(effectAction) {
          return [effectAction, currentState];
        })), false));
        (_b = layoutEffectActionsRef.current).push.apply(_b, __spreadArray2([], __read3(layoutEffectActions.map(function(layoutEffectAction) {
          return [layoutEffectAction, currentState];
        })), false));
      }
    });
    return function() {
      sub.unsubscribe();
    };
  }, []);
  index(function() {
    while (layoutEffectActionsRef.current.length) {
      var _a2 = __read3(layoutEffectActionsRef.current.shift(), 2), layoutEffectAction = _a2[0], effectState = _a2[1];
      executeEffect(layoutEffectAction, effectState);
    }
  });
  (0, import_react4.useEffect)(function() {
    while (effectActionsRef.current.length) {
      var _a2 = __read3(effectActionsRef.current.shift(), 2), effectAction = _a2[0], effectState = _a2[1];
      executeEffect(effectAction, effectState);
    }
  });
}

// node_modules/react-spring-bottom-sheet/node_modules/@xstate/react/es/useInterpret.js
var __assign2 = function() {
  __assign2 = Object.assign || function(t3) {
    for (var s2, i2 = 1, n2 = arguments.length; i2 < n2; i2++) {
      s2 = arguments[i2];
      for (var p in s2) if (Object.prototype.hasOwnProperty.call(s2, p))
        t3[p] = s2[p];
    }
    return t3;
  };
  return __assign2.apply(this, arguments);
};
var __rest2 = function(s2, e) {
  var t3 = {};
  for (var p in s2) if (Object.prototype.hasOwnProperty.call(s2, p) && e.indexOf(p) < 0)
    t3[p] = s2[p];
  if (s2 != null && typeof Object.getOwnPropertySymbols === "function")
    for (var i2 = 0, p = Object.getOwnPropertySymbols(s2); i2 < p.length; i2++) {
      if (e.indexOf(p[i2]) < 0 && Object.prototype.propertyIsEnumerable.call(s2, p[i2]))
        t3[p[i2]] = s2[p[i2]];
    }
  return t3;
};
var __read4 = function(o2, n2) {
  var m = typeof Symbol === "function" && o2[Symbol.iterator];
  if (!m) return o2;
  var i2 = m.call(o2), r2, ar = [], e;
  try {
    while ((n2 === void 0 || n2-- > 0) && !(r2 = i2.next()).done) ar.push(r2.value);
  } catch (error3) {
    e = { error: error3 };
  } finally {
    try {
      if (r2 && !r2.done && (m = i2["return"])) m.call(i2);
    } finally {
      if (e) throw e.error;
    }
  }
  return ar;
};
function toObserver2(nextHandler, errorHandler, completionHandler) {
  if (typeof nextHandler === "object") {
    return nextHandler;
  }
  var noop3 = function() {
    return void 0;
  };
  return {
    next: nextHandler,
    error: errorHandler || noop3,
    complete: completionHandler || noop3
  };
}
function useInterpret(getMachine, options, observerOrListener) {
  if (options === void 0) {
    options = {};
  }
  var machine = useConstant(function() {
    return typeof getMachine === "function" ? getMachine() : getMachine;
  });
  if (typeof getMachine !== "function") {
    var _a2 = __read4((0, import_react5.useState)(machine), 1), initialMachine = _a2[0];
    if (getMachine !== initialMachine) {
      console.warn("Machine given to `useMachine` has changed between renders. This is not supported and might lead to unexpected results.\nPlease make sure that you pass the same Machine as argument each time.");
    }
  }
  var context = options.context, guards = options.guards, actions = options.actions, activities = options.activities, services = options.services, delays = options.delays, rehydratedState = options.state, interpreterOptions = __rest2(options, ["context", "guards", "actions", "activities", "services", "delays", "state"]);
  var service = useConstant(function() {
    var machineConfig = {
      context,
      guards,
      actions,
      activities,
      services,
      delays
    };
    var machineWithConfig = machine.withConfig(machineConfig, function() {
      return __assign2(__assign2({}, machine.context), context);
    });
    return interpret(machineWithConfig, __assign2({ deferEvents: true }, interpreterOptions));
  });
  index(function() {
    var sub;
    if (observerOrListener) {
      sub = service.subscribe(toObserver2(observerOrListener));
    }
    return function() {
      sub === null || sub === void 0 ? void 0 : sub.unsubscribe();
    };
  }, [observerOrListener]);
  index(function() {
    service.start(rehydratedState ? State.create(rehydratedState) : void 0);
    return function() {
      service.stop();
    };
  }, []);
  index(function() {
    Object.assign(service.machine.options.actions, actions);
    Object.assign(service.machine.options.guards, guards);
    Object.assign(service.machine.options.activities, activities);
    Object.assign(service.machine.options.services, services);
    Object.assign(service.machine.options.delays, delays);
  }, [actions, guards, activities, services, delays]);
  useReactEffectActions(service);
  return service;
}

// node_modules/react-spring-bottom-sheet/node_modules/@xstate/react/es/useMachine.js
var __read5 = function(o2, n2) {
  var m = typeof Symbol === "function" && o2[Symbol.iterator];
  if (!m) return o2;
  var i2 = m.call(o2), r2, ar = [], e;
  try {
    while ((n2 === void 0 || n2-- > 0) && !(r2 = i2.next()).done) ar.push(r2.value);
  } catch (error3) {
    e = { error: error3 };
  } finally {
    try {
      if (r2 && !r2.done && (m = i2["return"])) m.call(i2);
    } finally {
      if (e) throw e.error;
    }
  }
  return ar;
};
function useMachine(getMachine, options) {
  if (options === void 0) {
    options = {};
  }
  var listener = (0, import_react6.useCallback)(function(nextState) {
    var initialStateChanged = nextState.changed === void 0 && Object.keys(nextState.children).length;
    if (nextState.changed || initialStateChanged) {
      setState(nextState);
    }
  }, []);
  var service = useInterpret(getMachine, options, listener);
  var _a2 = __read5((0, import_react6.useState)(function() {
    var initialState = service.machine.initialState;
    return options.state ? State.create(options.state) : initialState;
  }), 2), state = _a2[0], setState = _a2[1];
  return [state, service.send, service];
}

// node_modules/react-spring-bottom-sheet/node_modules/@xstate/react/es/useActor.js
var import_react7 = __toESM(require_react());

// node_modules/react-spring-bottom-sheet/node_modules/@xstate/react/es/useSelector.js
var import_react8 = __toESM(require_react());
var import_use_subscription = __toESM(require_use_subscription());

// node_modules/react-spring-bottom-sheet/node_modules/@xstate/react/es/useSpawn.js
var import_behaviors3 = __toESM(require_behaviors());

// node_modules/react-spring/web.js
var import_react9 = __toESM(require_react());
var is = {
  arr: Array.isArray,
  obj: (a2) => Object.prototype.toString.call(a2) === "[object Object]",
  fun: (a2) => typeof a2 === "function",
  str: (a2) => typeof a2 === "string",
  num: (a2) => typeof a2 === "number",
  und: (a2) => a2 === void 0,
  nul: (a2) => a2 === null,
  set: (a2) => a2 instanceof Set,
  map: (a2) => a2 instanceof Map,
  equ(a2, b) {
    if (typeof a2 !== typeof b) return false;
    if (is.str(a2) || is.num(a2)) return a2 === b;
    if (is.obj(a2) && is.obj(b) && Object.keys(a2).length + Object.keys(b).length === 0) return true;
    let i2;
    for (i2 in a2) if (!(i2 in b)) return false;
    for (i2 in b) if (a2[i2] !== b[i2]) return false;
    return is.und(i2) ? a2 === b : true;
  }
};
function merge(target, lowercase) {
  if (lowercase === void 0) {
    lowercase = true;
  }
  return (object) => (is.arr(object) ? object : Object.keys(object)).reduce((acc, element) => {
    const key = lowercase ? element[0].toLowerCase() + element.substring(1) : element;
    acc[key] = target(key);
    return acc;
  }, target);
}
function useForceUpdate2() {
  const _useState = (0, import_react9.useState)(false), f = _useState[1];
  const forceUpdate = (0, import_react9.useCallback)(() => f((v) => !v), []);
  return forceUpdate;
}
function withDefault(value, defaultValue) {
  return is.und(value) || is.nul(value) ? defaultValue : value;
}
function toArray2(a2) {
  return !is.und(a2) ? is.arr(a2) ? a2 : [a2] : [];
}
function callProp(obj) {
  for (var _len = arguments.length, args = new Array(_len > 1 ? _len - 1 : 0), _key = 1; _key < _len; _key++) {
    args[_key - 1] = arguments[_key];
  }
  return is.fun(obj) ? obj(...args) : obj;
}
function getForwardProps(props) {
  const to = props.to, from = props.from, config2 = props.config, onStart = props.onStart, onRest = props.onRest, onFrame = props.onFrame, children2 = props.children, reset = props.reset, reverse = props.reverse, force = props.force, immediate = props.immediate, delay4 = props.delay, attach = props.attach, destroyed = props.destroyed, interpolateTo2 = props.interpolateTo, ref = props.ref, lazy = props.lazy, forward = _objectWithoutPropertiesLoose(props, ["to", "from", "config", "onStart", "onRest", "onFrame", "children", "reset", "reverse", "force", "immediate", "delay", "attach", "destroyed", "interpolateTo", "ref", "lazy"]);
  return forward;
}
function interpolateTo(props) {
  const forward = getForwardProps(props);
  if (is.und(forward)) return _extends({
    to: forward
  }, props);
  const rest = Object.keys(props).reduce((a2, k2) => !is.und(forward[k2]) ? a2 : _extends({}, a2, {
    [k2]: props[k2]
  }), {});
  return _extends({
    to: forward
  }, rest);
}
function handleRef(ref, forward) {
  if (forward) {
    if (is.fun(forward)) forward(ref);
    else if (is.obj(forward)) {
      forward.current = ref;
    }
  }
  return ref;
}
var Animated = class {
  constructor() {
    this.payload = void 0;
    this.children = [];
  }
  getAnimatedValue() {
    return this.getValue();
  }
  getPayload() {
    return this.payload || this;
  }
  attach() {
  }
  detach() {
  }
  getChildren() {
    return this.children;
  }
  addChild(child) {
    if (this.children.length === 0) this.attach();
    this.children.push(child);
  }
  removeChild(child) {
    const index2 = this.children.indexOf(child);
    this.children.splice(index2, 1);
    if (this.children.length === 0) this.detach();
  }
};
var AnimatedArray = class extends Animated {
  constructor() {
    super(...arguments);
    this.payload = [];
    this.attach = () => this.payload.forEach((p) => p instanceof Animated && p.addChild(this));
    this.detach = () => this.payload.forEach((p) => p instanceof Animated && p.removeChild(this));
  }
};
var AnimatedObject = class extends Animated {
  constructor() {
    super(...arguments);
    this.payload = {};
    this.attach = () => Object.values(this.payload).forEach((s2) => s2 instanceof Animated && s2.addChild(this));
    this.detach = () => Object.values(this.payload).forEach((s2) => s2 instanceof Animated && s2.removeChild(this));
  }
  getValue(animated) {
    if (animated === void 0) {
      animated = false;
    }
    const payload = {};
    for (const key in this.payload) {
      const value = this.payload[key];
      if (animated && !(value instanceof Animated)) continue;
      payload[key] = value instanceof Animated ? value[animated ? "getAnimatedValue" : "getValue"]() : value;
    }
    return payload;
  }
  getAnimatedValue() {
    return this.getValue(true);
  }
};
var applyAnimatedValues;
function injectApplyAnimatedValues(fn, transform) {
  applyAnimatedValues = {
    fn,
    transform
  };
}
var colorNames;
function injectColorNames(names) {
  colorNames = names;
}
var requestFrame = (cb) => typeof window !== "undefined" ? window.requestAnimationFrame(cb) : -1;
var cancelFrame = (id) => {
  typeof window !== "undefined" && window.cancelAnimationFrame(id);
};
function injectFrame(raf, caf) {
  requestFrame = raf;
  cancelFrame = caf;
}
var interpolation;
function injectStringInterpolator(fn) {
  interpolation = fn;
}
var now = () => Date.now();
function injectNow(nowFn) {
  now = nowFn;
}
var defaultElement;
function injectDefaultElement(el) {
  defaultElement = el;
}
var animatedApi = (node) => node.current;
function injectAnimatedApi(fn) {
  animatedApi = fn;
}
var createAnimatedStyle;
function injectCreateAnimatedStyle(factory) {
  createAnimatedStyle = factory;
}
var manualFrameloop;
function injectManualFrameloop(callback) {
  manualFrameloop = callback;
}
var Globals = Object.freeze({
  get applyAnimatedValues() {
    return applyAnimatedValues;
  },
  injectApplyAnimatedValues,
  get colorNames() {
    return colorNames;
  },
  injectColorNames,
  get requestFrame() {
    return requestFrame;
  },
  get cancelFrame() {
    return cancelFrame;
  },
  injectFrame,
  get interpolation() {
    return interpolation;
  },
  injectStringInterpolator,
  get now() {
    return now;
  },
  injectNow,
  get defaultElement() {
    return defaultElement;
  },
  injectDefaultElement,
  get animatedApi() {
    return animatedApi;
  },
  injectAnimatedApi,
  get createAnimatedStyle() {
    return createAnimatedStyle;
  },
  injectCreateAnimatedStyle,
  get manualFrameloop() {
    return manualFrameloop;
  },
  injectManualFrameloop
});
var AnimatedProps = class extends AnimatedObject {
  constructor(props, callback) {
    super();
    this.update = void 0;
    this.payload = !props.style ? props : _extends({}, props, {
      style: createAnimatedStyle(props.style)
    });
    this.update = callback;
    this.attach();
  }
};
var isFunctionComponent = (val) => is.fun(val) && !(val.prototype instanceof import_react9.default.Component);
var createAnimatedComponent = (Component) => {
  const AnimatedComponent = (0, import_react9.forwardRef)((props, ref) => {
    const forceUpdate = useForceUpdate2();
    const mounted = (0, import_react9.useRef)(true);
    const propsAnimated = (0, import_react9.useRef)(null);
    const node = (0, import_react9.useRef)(null);
    const attachProps = (0, import_react9.useCallback)((props2) => {
      const oldPropsAnimated = propsAnimated.current;
      const callback = () => {
        let didUpdate = false;
        if (node.current) {
          didUpdate = applyAnimatedValues.fn(node.current, propsAnimated.current.getAnimatedValue());
        }
        if (!node.current || didUpdate === false) {
          forceUpdate();
        }
      };
      propsAnimated.current = new AnimatedProps(props2, callback);
      oldPropsAnimated && oldPropsAnimated.detach();
    }, []);
    (0, import_react9.useEffect)(() => () => {
      mounted.current = false;
      propsAnimated.current && propsAnimated.current.detach();
    }, []);
    (0, import_react9.useImperativeHandle)(ref, () => animatedApi(node, mounted, forceUpdate));
    attachProps(props);
    const _getValue = propsAnimated.current.getValue(), scrollTop = _getValue.scrollTop, scrollLeft = _getValue.scrollLeft, animatedProps = _objectWithoutPropertiesLoose(_getValue, ["scrollTop", "scrollLeft"]);
    const refFn = isFunctionComponent(Component) ? void 0 : (childRef) => node.current = handleRef(childRef, ref);
    return import_react9.default.createElement(Component, _extends({}, animatedProps, {
      ref: refFn
    }));
  });
  return AnimatedComponent;
};
var active = false;
var controllers = /* @__PURE__ */ new Set();
var update2 = () => {
  if (!active) return false;
  let time2 = now();
  for (let controller of controllers) {
    let isActive = false;
    for (let configIdx = 0; configIdx < controller.configs.length; configIdx++) {
      let config2 = controller.configs[configIdx];
      let endOfAnimation, lastTime;
      for (let valIdx = 0; valIdx < config2.animatedValues.length; valIdx++) {
        let animation = config2.animatedValues[valIdx];
        if (animation.done) continue;
        let from = config2.fromValues[valIdx];
        let to = config2.toValues[valIdx];
        let position = animation.lastPosition;
        let isAnimated = to instanceof Animated;
        let velocity = Array.isArray(config2.initialVelocity) ? config2.initialVelocity[valIdx] : config2.initialVelocity;
        if (isAnimated) to = to.getValue();
        if (config2.immediate) {
          animation.setValue(to);
          animation.done = true;
          continue;
        }
        if (typeof from === "string" || typeof to === "string") {
          animation.setValue(to);
          animation.done = true;
          continue;
        }
        if (config2.duration !== void 0) {
          position = from + config2.easing((time2 - animation.startTime) / config2.duration) * (to - from);
          endOfAnimation = time2 >= animation.startTime + config2.duration;
        } else if (config2.decay) {
          position = from + velocity / (1 - 0.998) * (1 - Math.exp(-(1 - 0.998) * (time2 - animation.startTime)));
          endOfAnimation = Math.abs(animation.lastPosition - position) < 0.1;
          if (endOfAnimation) to = position;
        } else {
          lastTime = animation.lastTime !== void 0 ? animation.lastTime : time2;
          velocity = animation.lastVelocity !== void 0 ? animation.lastVelocity : config2.initialVelocity;
          if (time2 > lastTime + 64) lastTime = time2;
          let numSteps = Math.floor(time2 - lastTime);
          for (let i2 = 0; i2 < numSteps; ++i2) {
            let force = -config2.tension * (position - to);
            let damping = -config2.friction * velocity;
            let acceleration = (force + damping) / config2.mass;
            velocity = velocity + acceleration * 1 / 1e3;
            position = position + velocity * 1 / 1e3;
          }
          let isOvershooting = config2.clamp && config2.tension !== 0 ? from < to ? position > to : position < to : false;
          let isVelocity = Math.abs(velocity) <= config2.precision;
          let isDisplacement = config2.tension !== 0 ? Math.abs(to - position) <= config2.precision : true;
          endOfAnimation = isOvershooting || isVelocity && isDisplacement;
          animation.lastVelocity = velocity;
          animation.lastTime = time2;
        }
        if (isAnimated && !config2.toValues[valIdx].done) endOfAnimation = false;
        if (endOfAnimation) {
          if (animation.value !== to) position = to;
          animation.done = true;
        } else isActive = true;
        animation.setValue(position);
        animation.lastPosition = position;
      }
      if (controller.props.onFrame) controller.values[config2.name] = config2.interpolation.getValue();
    }
    if (controller.props.onFrame) controller.props.onFrame(controller.values);
    if (!isActive) {
      controllers.delete(controller);
      controller.stop(true);
    }
  }
  if (controllers.size) {
    if (manualFrameloop) manualFrameloop();
    else requestFrame(update2);
  } else {
    active = false;
  }
  return active;
};
var start3 = (controller) => {
  if (!controllers.has(controller)) controllers.add(controller);
  if (!active) {
    active = true;
    if (manualFrameloop) requestFrame(manualFrameloop);
    else requestFrame(update2);
  }
};
var stop3 = (controller) => {
  if (controllers.has(controller)) controllers.delete(controller);
};
function createInterpolator(range, output, extrapolate) {
  if (typeof range === "function") {
    return range;
  }
  if (Array.isArray(range)) {
    return createInterpolator({
      range,
      output,
      extrapolate
    });
  }
  if (interpolation && typeof range.output[0] === "string") {
    return interpolation(range);
  }
  const config2 = range;
  const outputRange = config2.output;
  const inputRange = config2.range || [0, 1];
  const extrapolateLeft = config2.extrapolateLeft || config2.extrapolate || "extend";
  const extrapolateRight = config2.extrapolateRight || config2.extrapolate || "extend";
  const easing = config2.easing || ((t3) => t3);
  return (input) => {
    const range2 = findRange(input, inputRange);
    return interpolate(input, inputRange[range2], inputRange[range2 + 1], outputRange[range2], outputRange[range2 + 1], easing, extrapolateLeft, extrapolateRight, config2.map);
  };
}
function interpolate(input, inputMin, inputMax, outputMin, outputMax, easing, extrapolateLeft, extrapolateRight, map) {
  let result = map ? map(input) : input;
  if (result < inputMin) {
    if (extrapolateLeft === "identity") return result;
    else if (extrapolateLeft === "clamp") result = inputMin;
  }
  if (result > inputMax) {
    if (extrapolateRight === "identity") return result;
    else if (extrapolateRight === "clamp") result = inputMax;
  }
  if (outputMin === outputMax) return outputMin;
  if (inputMin === inputMax) return input <= inputMin ? outputMin : outputMax;
  if (inputMin === -Infinity) result = -result;
  else if (inputMax === Infinity) result = result - inputMin;
  else result = (result - inputMin) / (inputMax - inputMin);
  result = easing(result);
  if (outputMin === -Infinity) result = -result;
  else if (outputMax === Infinity) result = result + outputMin;
  else result = result * (outputMax - outputMin) + outputMin;
  return result;
}
function findRange(input, inputRange) {
  for (var i2 = 1; i2 < inputRange.length - 1; ++i2) if (inputRange[i2] >= input) break;
  return i2 - 1;
}
var AnimatedInterpolation = class _AnimatedInterpolation extends AnimatedArray {
  constructor(parents, range, output, extrapolate) {
    super();
    this.calc = void 0;
    this.payload = parents instanceof AnimatedArray && !(parents instanceof _AnimatedInterpolation) ? parents.getPayload() : Array.isArray(parents) ? parents : [parents];
    this.calc = createInterpolator(range, output, extrapolate);
  }
  getValue() {
    return this.calc(...this.payload.map((value) => value.getValue()));
  }
  updateConfig(range, output, extrapolate) {
    this.calc = createInterpolator(range, output, extrapolate);
  }
  interpolate(range, output, extrapolate) {
    return new _AnimatedInterpolation(this, range, output, extrapolate);
  }
};
var interpolate$1 = (parents, range, output) => parents && new AnimatedInterpolation(parents, range, output);
var config = {
  default: {
    tension: 170,
    friction: 26
  },
  gentle: {
    tension: 120,
    friction: 14
  },
  wobbly: {
    tension: 180,
    friction: 12
  },
  stiff: {
    tension: 210,
    friction: 20
  },
  slow: {
    tension: 280,
    friction: 60
  },
  molasses: {
    tension: 280,
    friction: 120
  }
};
function addAnimatedStyles(node, styles) {
  if ("update" in node) {
    styles.add(node);
  } else {
    node.getChildren().forEach((child) => addAnimatedStyles(child, styles));
  }
}
var AnimatedValue = class extends Animated {
  constructor(_value) {
    var _this;
    super();
    _this = this;
    this.animatedStyles = /* @__PURE__ */ new Set();
    this.value = void 0;
    this.startPosition = void 0;
    this.lastPosition = void 0;
    this.lastVelocity = void 0;
    this.startTime = void 0;
    this.lastTime = void 0;
    this.done = false;
    this.setValue = function(value, flush) {
      if (flush === void 0) {
        flush = true;
      }
      _this.value = value;
      if (flush) _this.flush();
    };
    this.value = _value;
    this.startPosition = _value;
    this.lastPosition = _value;
  }
  flush() {
    if (this.animatedStyles.size === 0) {
      addAnimatedStyles(this, this.animatedStyles);
    }
    this.animatedStyles.forEach((animatedStyle) => animatedStyle.update());
  }
  clearStyles() {
    this.animatedStyles.clear();
  }
  getValue() {
    return this.value;
  }
  interpolate(range, output, extrapolate) {
    return new AnimatedInterpolation(this, range, output, extrapolate);
  }
};
var AnimatedValueArray = class extends AnimatedArray {
  constructor(values) {
    super();
    this.payload = values.map((n2) => new AnimatedValue(n2));
  }
  setValue(value, flush) {
    if (flush === void 0) {
      flush = true;
    }
    if (Array.isArray(value)) {
      if (value.length === this.payload.length) {
        value.forEach((v, i2) => this.payload[i2].setValue(v, flush));
      }
    } else {
      this.payload.forEach((p) => p.setValue(value, flush));
    }
  }
  getValue() {
    return this.payload.map((v) => v.getValue());
  }
  interpolate(range, output) {
    return new AnimatedInterpolation(this, range, output);
  }
};
var G = 0;
var Controller = class {
  constructor() {
    this.id = void 0;
    this.idle = true;
    this.hasChanged = false;
    this.guid = 0;
    this.local = 0;
    this.props = {};
    this.merged = {};
    this.animations = {};
    this.interpolations = {};
    this.values = {};
    this.configs = [];
    this.listeners = [];
    this.queue = [];
    this.localQueue = void 0;
    this.getValues = () => this.interpolations;
    this.id = G++;
  }
  /** update(props)
   *  This function filters input props and creates an array of tasks which are executed in .start()
   *  Each task is allowed to carry a delay, which means it can execute asnychroneously */
  update(args) {
    if (!args) return this;
    const _ref = interpolateTo(args), _ref$delay = _ref.delay, delay4 = _ref$delay === void 0 ? 0 : _ref$delay, to = _ref.to, props = _objectWithoutPropertiesLoose(_ref, ["delay", "to"]);
    if (is.arr(to) || is.fun(to)) {
      this.queue.push(_extends({}, props, {
        delay: delay4,
        to
      }));
    } else if (to) {
      let ops = {};
      Object.entries(to).forEach((_ref2) => {
        let k2 = _ref2[0], v = _ref2[1];
        const entry = _extends({
          to: {
            [k2]: v
          },
          delay: callProp(delay4, k2)
        }, props);
        const previous = ops[entry.delay] && ops[entry.delay].to;
        ops[entry.delay] = _extends({}, ops[entry.delay], entry, {
          to: _extends({}, previous, entry.to)
        });
      });
      this.queue = Object.values(ops);
    }
    this.queue = this.queue.sort((a2, b) => a2.delay - b.delay);
    this.diff(props);
    return this;
  }
  /** start(onEnd)
   *  This function either executes a queue, if present, or starts the frameloop, which animates */
  start(onEnd) {
    if (this.queue.length) {
      this.idle = false;
      if (this.localQueue) {
        this.localQueue.forEach((_ref3) => {
          let _ref3$from = _ref3.from, from = _ref3$from === void 0 ? {} : _ref3$from, _ref3$to = _ref3.to, to = _ref3$to === void 0 ? {} : _ref3$to;
          if (is.obj(from)) this.merged = _extends({}, from, this.merged);
          if (is.obj(to)) this.merged = _extends({}, this.merged, to);
        });
      }
      const local = this.local = ++this.guid;
      const queue = this.localQueue = this.queue;
      this.queue = [];
      queue.forEach((_ref4, index2) => {
        let delay4 = _ref4.delay, props = _objectWithoutPropertiesLoose(_ref4, ["delay"]);
        const cb = (finished) => {
          if (index2 === queue.length - 1 && local === this.guid && finished) {
            this.idle = true;
            if (this.props.onRest) this.props.onRest(this.merged);
          }
          if (onEnd) onEnd();
        };
        let async = is.arr(props.to) || is.fun(props.to);
        if (delay4) {
          setTimeout(() => {
            if (local === this.guid) {
              if (async) this.runAsync(props, cb);
              else this.diff(props).start(cb);
            }
          }, delay4);
        } else if (async) this.runAsync(props, cb);
        else this.diff(props).start(cb);
      });
    } else {
      if (is.fun(onEnd)) this.listeners.push(onEnd);
      if (this.props.onStart) this.props.onStart();
      start3(this);
    }
    return this;
  }
  stop(finished) {
    this.listeners.forEach((onEnd) => onEnd(finished));
    this.listeners = [];
    return this;
  }
  /** Pause sets onEnd listeners free, but also removes the controller from the frameloop */
  pause(finished) {
    this.stop(true);
    if (finished) stop3(this);
    return this;
  }
  runAsync(_ref5, onEnd) {
    var _this = this;
    let delay4 = _ref5.delay, props = _objectWithoutPropertiesLoose(_ref5, ["delay"]);
    const local = this.local;
    let queue = Promise.resolve(void 0);
    if (is.arr(props.to)) {
      for (let i2 = 0; i2 < props.to.length; i2++) {
        const index2 = i2;
        const fresh = _extends({}, props, interpolateTo(props.to[index2]));
        if (is.arr(fresh.config)) fresh.config = fresh.config[index2];
        queue = queue.then(() => {
          if (local === this.guid) return new Promise((r2) => this.diff(fresh).start(r2));
        });
      }
    } else if (is.fun(props.to)) {
      let index2 = 0;
      let last;
      queue = queue.then(() => props.to(
        // next(props)
        (p) => {
          const fresh = _extends({}, props, interpolateTo(p));
          if (is.arr(fresh.config)) fresh.config = fresh.config[index2];
          index2++;
          if (local === this.guid) return last = new Promise((r2) => this.diff(fresh).start(r2));
          return;
        },
        // cancel()
        function(finished) {
          if (finished === void 0) {
            finished = true;
          }
          return _this.stop(finished);
        }
      ).then(() => last));
    }
    queue.then(onEnd);
  }
  diff(props) {
    this.props = _extends({}, this.props, props);
    let _this$props = this.props, _this$props$from = _this$props.from, from = _this$props$from === void 0 ? {} : _this$props$from, _this$props$to = _this$props.to, to = _this$props$to === void 0 ? {} : _this$props$to, _this$props$config = _this$props.config, config2 = _this$props$config === void 0 ? {} : _this$props$config, reverse = _this$props.reverse, attach = _this$props.attach, reset = _this$props.reset, immediate = _this$props.immediate;
    if (reverse) {
      var _ref6 = [to, from];
      from = _ref6[0];
      to = _ref6[1];
    }
    this.merged = _extends({}, from, this.merged, to);
    this.hasChanged = false;
    let target = attach && attach(this);
    this.animations = Object.entries(this.merged).reduce((acc, _ref7) => {
      let name = _ref7[0], value = _ref7[1];
      let entry = acc[name] || {};
      const isNumber = is.num(value);
      const isString2 = is.str(value) && !value.startsWith("#") && !/\d/.test(value) && !colorNames[value];
      const isArray2 = is.arr(value);
      const isInterpolation = !isNumber && !isArray2 && !isString2;
      let fromValue = !is.und(from[name]) ? from[name] : value;
      let toValue = isNumber || isArray2 ? value : isString2 ? value : 1;
      let toConfig = callProp(config2, name);
      if (target) toValue = target.animations[name].parent;
      let parent = entry.parent, interpolation$$1 = entry.interpolation, toValues = toArray2(target ? toValue.getPayload() : toValue), animatedValues;
      let newValue = value;
      if (isInterpolation) newValue = interpolation({
        range: [0, 1],
        output: [value, value]
      })(1);
      let currentValue = interpolation$$1 && interpolation$$1.getValue();
      const isFirst = is.und(parent);
      const isActive = !isFirst && entry.animatedValues.some((v) => !v.done);
      const currentValueDiffersFromGoal = !is.equ(newValue, currentValue);
      const hasNewGoal = !is.equ(newValue, entry.previous);
      const hasNewConfig = !is.equ(toConfig, entry.config);
      if (reset || hasNewGoal && currentValueDiffersFromGoal || hasNewConfig) {
        if (isNumber || isString2) parent = interpolation$$1 = entry.parent || new AnimatedValue(fromValue);
        else if (isArray2) parent = interpolation$$1 = entry.parent || new AnimatedValueArray(fromValue);
        else if (isInterpolation) {
          let prev = entry.interpolation && entry.interpolation.calc(entry.parent.value);
          prev = prev !== void 0 && !reset ? prev : fromValue;
          if (entry.parent) {
            parent = entry.parent;
            parent.setValue(0, false);
          } else parent = new AnimatedValue(0);
          const range = {
            output: [prev, value]
          };
          if (entry.interpolation) {
            interpolation$$1 = entry.interpolation;
            entry.interpolation.updateConfig(range);
          } else interpolation$$1 = parent.interpolate(range);
        }
        toValues = toArray2(target ? toValue.getPayload() : toValue);
        animatedValues = toArray2(parent.getPayload());
        if (reset && !isInterpolation) parent.setValue(fromValue, false);
        this.hasChanged = true;
        animatedValues.forEach((value2) => {
          value2.startPosition = value2.value;
          value2.lastPosition = value2.value;
          value2.lastVelocity = isActive ? value2.lastVelocity : void 0;
          value2.lastTime = isActive ? value2.lastTime : void 0;
          value2.startTime = now();
          value2.done = false;
          value2.animatedStyles.clear();
        });
        if (callProp(immediate, name)) {
          parent.setValue(isInterpolation ? toValue : value, false);
        }
        return _extends({}, acc, {
          [name]: _extends({}, entry, {
            name,
            parent,
            interpolation: interpolation$$1,
            animatedValues,
            toValues,
            previous: newValue,
            config: toConfig,
            fromValues: toArray2(parent.getValue()),
            immediate: callProp(immediate, name),
            initialVelocity: withDefault(toConfig.velocity, 0),
            clamp: withDefault(toConfig.clamp, false),
            precision: withDefault(toConfig.precision, 0.01),
            tension: withDefault(toConfig.tension, 170),
            friction: withDefault(toConfig.friction, 26),
            mass: withDefault(toConfig.mass, 1),
            duration: toConfig.duration,
            easing: withDefault(toConfig.easing, (t3) => t3),
            decay: toConfig.decay
          })
        });
      } else {
        if (!currentValueDiffersFromGoal) {
          if (isInterpolation) {
            parent.setValue(1, false);
            interpolation$$1.updateConfig({
              output: [newValue, newValue]
            });
          }
          parent.done = true;
          this.hasChanged = true;
          return _extends({}, acc, {
            [name]: _extends({}, acc[name], {
              previous: newValue
            })
          });
        }
        return acc;
      }
    }, this.animations);
    if (this.hasChanged) {
      this.configs = Object.values(this.animations);
      this.values = {};
      this.interpolations = {};
      for (let key in this.animations) {
        this.interpolations[key] = this.animations[key].interpolation;
        this.values[key] = this.animations[key].interpolation.getValue();
      }
    }
    return this;
  }
  destroy() {
    this.stop();
    this.props = {};
    this.merged = {};
    this.animations = {};
    this.interpolations = {};
    this.values = {};
    this.configs = [];
    this.local = 0;
  }
};
var useSprings = (length, props) => {
  const mounted = (0, import_react9.useRef)(false);
  const ctrl = (0, import_react9.useRef)();
  const isFn = is.fun(props);
  const _useMemo = (0, import_react9.useMemo)(() => {
    if (ctrl.current) {
      ctrl.current.map((c2) => c2.destroy());
      ctrl.current = void 0;
    }
    let ref2;
    return [new Array(length).fill().map((_, i2) => {
      const ctrl2 = new Controller();
      const newProps = isFn ? callProp(props, i2, ctrl2) : props[i2];
      if (i2 === 0) ref2 = newProps.ref;
      ctrl2.update(newProps);
      if (!ref2) ctrl2.start();
      return ctrl2;
    }), ref2];
  }, [length]), controllers2 = _useMemo[0], ref = _useMemo[1];
  ctrl.current = controllers2;
  const api = (0, import_react9.useImperativeHandle)(ref, () => ({
    start: () => Promise.all(ctrl.current.map((c2) => new Promise((r2) => c2.start(r2)))),
    stop: (finished) => ctrl.current.forEach((c2) => c2.stop(finished)),
    get controllers() {
      return ctrl.current;
    }
  }));
  const updateCtrl = (0, import_react9.useMemo)(() => (updateProps) => ctrl.current.map((c2, i2) => {
    c2.update(isFn ? callProp(updateProps, i2, c2) : updateProps[i2]);
    if (!ref) c2.start();
  }), [length]);
  (0, import_react9.useEffect)(() => {
    if (mounted.current) {
      if (!isFn) updateCtrl(props);
    } else if (!ref) ctrl.current.forEach((c2) => c2.start());
  });
  (0, import_react9.useEffect)(() => (mounted.current = true, () => ctrl.current.forEach((c2) => c2.destroy())), []);
  const propValues = ctrl.current.map((c2) => c2.getValues());
  return isFn ? [propValues, updateCtrl, (finished) => ctrl.current.forEach((c2) => c2.pause(finished))] : propValues;
};
var useSpring = (props) => {
  const isFn = is.fun(props);
  const _useSprings = useSprings(1, isFn ? props : [props]), result = _useSprings[0], set = _useSprings[1], pause = _useSprings[2];
  return isFn ? [result[0], set, pause] : result;
};
var AnimatedStyle = class extends AnimatedObject {
  constructor(style) {
    if (style === void 0) {
      style = {};
    }
    super();
    if (style.transform && !(style.transform instanceof Animated)) {
      style = applyAnimatedValues.transform(style);
    }
    this.payload = style;
  }
};
var colors = {
  transparent: 0,
  aliceblue: 4042850303,
  antiquewhite: 4209760255,
  aqua: 16777215,
  aquamarine: 2147472639,
  azure: 4043309055,
  beige: 4126530815,
  bisque: 4293182719,
  black: 255,
  blanchedalmond: 4293643775,
  blue: 65535,
  blueviolet: 2318131967,
  brown: 2771004159,
  burlywood: 3736635391,
  burntsienna: 3934150143,
  cadetblue: 1604231423,
  chartreuse: 2147418367,
  chocolate: 3530104575,
  coral: 4286533887,
  cornflowerblue: 1687547391,
  cornsilk: 4294499583,
  crimson: 3692313855,
  cyan: 16777215,
  darkblue: 35839,
  darkcyan: 9145343,
  darkgoldenrod: 3095792639,
  darkgray: 2846468607,
  darkgreen: 6553855,
  darkgrey: 2846468607,
  darkkhaki: 3182914559,
  darkmagenta: 2332068863,
  darkolivegreen: 1433087999,
  darkorange: 4287365375,
  darkorchid: 2570243327,
  darkred: 2332033279,
  darksalmon: 3918953215,
  darkseagreen: 2411499519,
  darkslateblue: 1211993087,
  darkslategray: 793726975,
  darkslategrey: 793726975,
  darkturquoise: 13554175,
  darkviolet: 2483082239,
  deeppink: 4279538687,
  deepskyblue: 12582911,
  dimgray: 1768516095,
  dimgrey: 1768516095,
  dodgerblue: 512819199,
  firebrick: 2988581631,
  floralwhite: 4294635775,
  forestgreen: 579543807,
  fuchsia: 4278255615,
  gainsboro: 3705462015,
  ghostwhite: 4177068031,
  gold: 4292280575,
  goldenrod: 3668254975,
  gray: 2155905279,
  green: 8388863,
  greenyellow: 2919182335,
  grey: 2155905279,
  honeydew: 4043305215,
  hotpink: 4285117695,
  indianred: 3445382399,
  indigo: 1258324735,
  ivory: 4294963455,
  khaki: 4041641215,
  lavender: 3873897215,
  lavenderblush: 4293981695,
  lawngreen: 2096890111,
  lemonchiffon: 4294626815,
  lightblue: 2916673279,
  lightcoral: 4034953471,
  lightcyan: 3774873599,
  lightgoldenrodyellow: 4210742015,
  lightgray: 3553874943,
  lightgreen: 2431553791,
  lightgrey: 3553874943,
  lightpink: 4290167295,
  lightsalmon: 4288707327,
  lightseagreen: 548580095,
  lightskyblue: 2278488831,
  lightslategray: 2005441023,
  lightslategrey: 2005441023,
  lightsteelblue: 2965692159,
  lightyellow: 4294959359,
  lime: 16711935,
  limegreen: 852308735,
  linen: 4210091775,
  magenta: 4278255615,
  maroon: 2147483903,
  mediumaquamarine: 1724754687,
  mediumblue: 52735,
  mediumorchid: 3126187007,
  mediumpurple: 2473647103,
  mediumseagreen: 1018393087,
  mediumslateblue: 2070474495,
  mediumspringgreen: 16423679,
  mediumturquoise: 1221709055,
  mediumvioletred: 3340076543,
  midnightblue: 421097727,
  mintcream: 4127193855,
  mistyrose: 4293190143,
  moccasin: 4293178879,
  navajowhite: 4292783615,
  navy: 33023,
  oldlace: 4260751103,
  olive: 2155872511,
  olivedrab: 1804477439,
  orange: 4289003775,
  orangered: 4282712319,
  orchid: 3664828159,
  palegoldenrod: 4008225535,
  palegreen: 2566625535,
  paleturquoise: 2951671551,
  palevioletred: 3681588223,
  papayawhip: 4293907967,
  peachpuff: 4292524543,
  peru: 3448061951,
  pink: 4290825215,
  plum: 3718307327,
  powderblue: 2967529215,
  purple: 2147516671,
  rebeccapurple: 1714657791,
  red: 4278190335,
  rosybrown: 3163525119,
  royalblue: 1097458175,
  saddlebrown: 2336560127,
  salmon: 4202722047,
  sandybrown: 4104413439,
  seagreen: 780883967,
  seashell: 4294307583,
  sienna: 2689740287,
  silver: 3233857791,
  skyblue: 2278484991,
  slateblue: 1784335871,
  slategray: 1887473919,
  slategrey: 1887473919,
  snow: 4294638335,
  springgreen: 16744447,
  steelblue: 1182971135,
  tan: 3535047935,
  teal: 8421631,
  thistle: 3636451583,
  tomato: 4284696575,
  turquoise: 1088475391,
  violet: 4001558271,
  wheat: 4125012991,
  white: 4294967295,
  whitesmoke: 4126537215,
  yellow: 4294902015,
  yellowgreen: 2597139199
};
var NUMBER = "[-+]?\\d*\\.?\\d+";
var PERCENTAGE = NUMBER + "%";
function call() {
  for (var _len = arguments.length, parts = new Array(_len), _key = 0; _key < _len; _key++) {
    parts[_key] = arguments[_key];
  }
  return "\\(\\s*(" + parts.join(")\\s*,\\s*(") + ")\\s*\\)";
}
var rgb = new RegExp("rgb" + call(NUMBER, NUMBER, NUMBER));
var rgba = new RegExp("rgba" + call(NUMBER, NUMBER, NUMBER, NUMBER));
var hsl = new RegExp("hsl" + call(NUMBER, PERCENTAGE, PERCENTAGE));
var hsla = new RegExp("hsla" + call(NUMBER, PERCENTAGE, PERCENTAGE, NUMBER));
var hex3 = /^#([0-9a-fA-F]{1})([0-9a-fA-F]{1})([0-9a-fA-F]{1})$/;
var hex4 = /^#([0-9a-fA-F]{1})([0-9a-fA-F]{1})([0-9a-fA-F]{1})([0-9a-fA-F]{1})$/;
var hex6 = /^#([0-9a-fA-F]{6})$/;
var hex8 = /^#([0-9a-fA-F]{8})$/;
function normalizeColor(color) {
  let match;
  if (typeof color === "number") {
    return color >>> 0 === color && color >= 0 && color <= 4294967295 ? color : null;
  }
  if (match = hex6.exec(color)) return parseInt(match[1] + "ff", 16) >>> 0;
  if (colors.hasOwnProperty(color)) return colors[color];
  if (match = rgb.exec(color)) {
    return (parse255(match[1]) << 24 | // r
    parse255(match[2]) << 16 | // g
    parse255(match[3]) << 8 | // b
    255) >>> // a
    0;
  }
  if (match = rgba.exec(color)) {
    return (parse255(match[1]) << 24 | // r
    parse255(match[2]) << 16 | // g
    parse255(match[3]) << 8 | // b
    parse1(match[4])) >>> // a
    0;
  }
  if (match = hex3.exec(color)) {
    return parseInt(
      match[1] + match[1] + // r
      match[2] + match[2] + // g
      match[3] + match[3] + // b
      "ff",
      // a
      16
    ) >>> 0;
  }
  if (match = hex8.exec(color)) return parseInt(match[1], 16) >>> 0;
  if (match = hex4.exec(color)) {
    return parseInt(
      match[1] + match[1] + // r
      match[2] + match[2] + // g
      match[3] + match[3] + // b
      match[4] + match[4],
      // a
      16
    ) >>> 0;
  }
  if (match = hsl.exec(color)) {
    return (hslToRgb(
      parse360(match[1]),
      // h
      parsePercentage(match[2]),
      // s
      parsePercentage(match[3])
      // l
    ) | 255) >>> // a
    0;
  }
  if (match = hsla.exec(color)) {
    return (hslToRgb(
      parse360(match[1]),
      // h
      parsePercentage(match[2]),
      // s
      parsePercentage(match[3])
      // l
    ) | parse1(match[4])) >>> // a
    0;
  }
  return null;
}
function hue2rgb(p, q2, t3) {
  if (t3 < 0) t3 += 1;
  if (t3 > 1) t3 -= 1;
  if (t3 < 1 / 6) return p + (q2 - p) * 6 * t3;
  if (t3 < 1 / 2) return q2;
  if (t3 < 2 / 3) return p + (q2 - p) * (2 / 3 - t3) * 6;
  return p;
}
function hslToRgb(h, s2, l2) {
  const q2 = l2 < 0.5 ? l2 * (1 + s2) : l2 + s2 - l2 * s2;
  const p = 2 * l2 - q2;
  const r2 = hue2rgb(p, q2, h + 1 / 3);
  const g = hue2rgb(p, q2, h);
  const b = hue2rgb(p, q2, h - 1 / 3);
  return Math.round(r2 * 255) << 24 | Math.round(g * 255) << 16 | Math.round(b * 255) << 8;
}
function parse255(str) {
  const int = parseInt(str, 10);
  if (int < 0) return 0;
  if (int > 255) return 255;
  return int;
}
function parse360(str) {
  const int = parseFloat(str);
  return (int % 360 + 360) % 360 / 360;
}
function parse1(str) {
  const num = parseFloat(str);
  if (num < 0) return 0;
  if (num > 1) return 255;
  return Math.round(num * 255);
}
function parsePercentage(str) {
  const int = parseFloat(str);
  if (int < 0) return 0;
  if (int > 100) return 1;
  return int / 100;
}
function colorToRgba(input) {
  let int32Color = normalizeColor(input);
  if (int32Color === null) return input;
  int32Color = int32Color || 0;
  let r2 = (int32Color & 4278190080) >>> 24;
  let g = (int32Color & 16711680) >>> 16;
  let b = (int32Color & 65280) >>> 8;
  let a2 = (int32Color & 255) / 255;
  return `rgba(${r2}, ${g}, ${b}, ${a2})`;
}
var stringShapeRegex = /[+\-]?(?:0|[1-9]\d*)(?:\.\d*)?(?:[eE][+\-]?\d+)?/g;
var colorRegex = /(#(?:[0-9a-f]{2}){2,4}|(#[0-9a-f]{3})|(rgb|hsl)a?\((-?\d+%?[,\s]+){2,3}\s*[\d\.]+%?\))/gi;
var colorNamesRegex = new RegExp(`(${Object.keys(colors).join("|")})`, "g");
var createStringInterpolator = (config2) => {
  const outputRange = config2.output.map((rangeValue) => rangeValue.replace(colorRegex, colorToRgba)).map((rangeValue) => rangeValue.replace(colorNamesRegex, colorToRgba));
  const outputRanges = outputRange[0].match(stringShapeRegex).map(() => []);
  outputRange.forEach((value) => {
    value.match(stringShapeRegex).forEach((number, i2) => outputRanges[i2].push(+number));
  });
  const interpolations = outputRange[0].match(stringShapeRegex).map((_value, i2) => createInterpolator(_extends({}, config2, {
    output: outputRanges[i2]
  })));
  return (input) => {
    let i2 = 0;
    return outputRange[0].replace(stringShapeRegex, () => interpolations[i2++](input)).replace(/rgba\(([0-9\.-]+), ([0-9\.-]+), ([0-9\.-]+), ([0-9\.-]+)\)/gi, (_, p1, p2, p3, p4) => `rgba(${Math.round(p1)}, ${Math.round(p2)}, ${Math.round(p3)}, ${p4})`);
  };
};
var isUnitlessNumber = {
  animationIterationCount: true,
  borderImageOutset: true,
  borderImageSlice: true,
  borderImageWidth: true,
  boxFlex: true,
  boxFlexGroup: true,
  boxOrdinalGroup: true,
  columnCount: true,
  columns: true,
  flex: true,
  flexGrow: true,
  flexPositive: true,
  flexShrink: true,
  flexNegative: true,
  flexOrder: true,
  gridRow: true,
  gridRowEnd: true,
  gridRowSpan: true,
  gridRowStart: true,
  gridColumn: true,
  gridColumnEnd: true,
  gridColumnSpan: true,
  gridColumnStart: true,
  fontWeight: true,
  lineClamp: true,
  lineHeight: true,
  opacity: true,
  order: true,
  orphans: true,
  tabSize: true,
  widows: true,
  zIndex: true,
  zoom: true,
  // SVG-related properties
  fillOpacity: true,
  floodOpacity: true,
  stopOpacity: true,
  strokeDasharray: true,
  strokeDashoffset: true,
  strokeMiterlimit: true,
  strokeOpacity: true,
  strokeWidth: true
};
var prefixKey = (prefix, key) => prefix + key.charAt(0).toUpperCase() + key.substring(1);
var prefixes = ["Webkit", "Ms", "Moz", "O"];
isUnitlessNumber = Object.keys(isUnitlessNumber).reduce((acc, prop) => {
  prefixes.forEach((prefix) => acc[prefixKey(prefix, prop)] = acc[prop]);
  return acc;
}, isUnitlessNumber);
function dangerousStyleValue(name, value, isCustomProperty) {
  if (value == null || typeof value === "boolean" || value === "") return "";
  if (!isCustomProperty && typeof value === "number" && value !== 0 && !(isUnitlessNumber.hasOwnProperty(name) && isUnitlessNumber[name])) return value + "px";
  return ("" + value).trim();
}
var attributeCache = {};
injectCreateAnimatedStyle((style) => new AnimatedStyle(style));
injectDefaultElement("div");
injectStringInterpolator(createStringInterpolator);
injectColorNames(colors);
injectApplyAnimatedValues((instance, props) => {
  if (instance.nodeType && instance.setAttribute !== void 0) {
    const style = props.style, children2 = props.children, scrollTop = props.scrollTop, scrollLeft = props.scrollLeft, attributes = _objectWithoutPropertiesLoose(props, ["style", "children", "scrollTop", "scrollLeft"]);
    const filter = instance.nodeName === "filter" || instance.parentNode && instance.parentNode.nodeName === "filter";
    if (scrollTop !== void 0) instance.scrollTop = scrollTop;
    if (scrollLeft !== void 0) instance.scrollLeft = scrollLeft;
    if (children2 !== void 0) instance.textContent = children2;
    for (let styleName in style) {
      if (!style.hasOwnProperty(styleName)) continue;
      var isCustomProperty = styleName.indexOf("--") === 0;
      var styleValue = dangerousStyleValue(styleName, style[styleName], isCustomProperty);
      if (styleName === "float") styleName = "cssFloat";
      if (isCustomProperty) instance.style.setProperty(styleName, styleValue);
      else instance.style[styleName] = styleValue;
    }
    for (let name in attributes) {
      const dashCase = filter ? name : attributeCache[name] || (attributeCache[name] = name.replace(/([A-Z])/g, (n2) => "-" + n2.toLowerCase()));
      if (typeof instance.getAttribute(dashCase) !== "undefined") instance.setAttribute(dashCase, attributes[name]);
    }
    return;
  } else return false;
}, (style) => style);
var domElements = [
  "a",
  "abbr",
  "address",
  "area",
  "article",
  "aside",
  "audio",
  "b",
  "base",
  "bdi",
  "bdo",
  "big",
  "blockquote",
  "body",
  "br",
  "button",
  "canvas",
  "caption",
  "cite",
  "code",
  "col",
  "colgroup",
  "data",
  "datalist",
  "dd",
  "del",
  "details",
  "dfn",
  "dialog",
  "div",
  "dl",
  "dt",
  "em",
  "embed",
  "fieldset",
  "figcaption",
  "figure",
  "footer",
  "form",
  "h1",
  "h2",
  "h3",
  "h4",
  "h5",
  "h6",
  "head",
  "header",
  "hgroup",
  "hr",
  "html",
  "i",
  "iframe",
  "img",
  "input",
  "ins",
  "kbd",
  "keygen",
  "label",
  "legend",
  "li",
  "link",
  "main",
  "map",
  "mark",
  "menu",
  "menuitem",
  "meta",
  "meter",
  "nav",
  "noscript",
  "object",
  "ol",
  "optgroup",
  "option",
  "output",
  "p",
  "param",
  "picture",
  "pre",
  "progress",
  "q",
  "rp",
  "rt",
  "ruby",
  "s",
  "samp",
  "script",
  "section",
  "select",
  "small",
  "source",
  "span",
  "strong",
  "style",
  "sub",
  "summary",
  "sup",
  "table",
  "tbody",
  "td",
  "textarea",
  "tfoot",
  "th",
  "thead",
  "time",
  "title",
  "tr",
  "track",
  "u",
  "ul",
  "var",
  "video",
  "wbr",
  // SVG
  "circle",
  "clipPath",
  "defs",
  "ellipse",
  "foreignObject",
  "g",
  "image",
  "line",
  "linearGradient",
  "mask",
  "path",
  "pattern",
  "polygon",
  "polyline",
  "radialGradient",
  "rect",
  "stop",
  "svg",
  "text",
  "tspan"
];
var apply = merge(createAnimatedComponent, false);
var extendedAnimated = apply(domElements);

// node_modules/react-use-gesture/dist/react-use-gesture.esm.js
var import_react10 = __toESM(require_react());
function addV(v1, v2) {
  return v1.map(function(v, i2) {
    return v + v2[i2];
  });
}
function subV(v1, v2) {
  return v1.map(function(v, i2) {
    return v - v2[i2];
  });
}
function calculateDistance(movement) {
  return Math.hypot.apply(Math, movement);
}
function calculateAllGeometry(movement, delta) {
  if (delta === void 0) {
    delta = movement;
  }
  var dl = calculateDistance(delta);
  var alpha = dl === 0 ? 0 : 1 / dl;
  var direction = delta.map(function(v) {
    return alpha * v;
  });
  var distance = calculateDistance(movement);
  return {
    distance,
    direction
  };
}
function calculateAllKinematics(movement, delta, dt) {
  var dl = calculateDistance(delta);
  var alpha = dl === 0 ? 0 : 1 / dl;
  var beta = dt === 0 ? 0 : 1 / dt;
  var velocity = beta * dl;
  var velocities = delta.map(function(v) {
    return beta * v;
  });
  var direction = delta.map(function(v) {
    return alpha * v;
  });
  var distance = calculateDistance(movement);
  return {
    velocities,
    velocity,
    distance,
    direction
  };
}
function sign(x2) {
  if (Math.sign) return Math.sign(x2);
  return Number(x2 > 0) - Number(x2 < 0) || +x2;
}
function minMax(value, min, max) {
  return Math.max(min, Math.min(value, max));
}
function rubberband2(distance, constant) {
  return Math.pow(distance, constant * 5);
}
function rubberband(distance, dimension, constant) {
  if (dimension === 0 || Math.abs(dimension) === Infinity) return rubberband2(distance, constant);
  return distance * dimension * constant / (dimension + constant * distance);
}
function rubberbandIfOutOfBounds(position, min, max, constant) {
  if (constant === void 0) {
    constant = 0.15;
  }
  if (constant === 0) return minMax(position, min, max);
  if (position < min) return -rubberband(min - position, max - min, constant) + min;
  if (position > max) return +rubberband(position - max, max - min, constant) + max;
  return position;
}
function _defineProperties(target, props) {
  for (var i2 = 0; i2 < props.length; i2++) {
    var descriptor = props[i2];
    descriptor.enumerable = descriptor.enumerable || false;
    descriptor.configurable = true;
    if ("value" in descriptor) descriptor.writable = true;
    Object.defineProperty(target, descriptor.key, descriptor);
  }
}
function _createClass(Constructor, protoProps, staticProps) {
  if (protoProps) _defineProperties(Constructor.prototype, protoProps);
  if (staticProps) _defineProperties(Constructor, staticProps);
  return Constructor;
}
function _extends2() {
  _extends2 = Object.assign || function(target) {
    for (var i2 = 1; i2 < arguments.length; i2++) {
      var source = arguments[i2];
      for (var key in source) {
        if (Object.prototype.hasOwnProperty.call(source, key)) {
          target[key] = source[key];
        }
      }
    }
    return target;
  };
  return _extends2.apply(this, arguments);
}
function _inheritsLoose(subClass, superClass) {
  subClass.prototype = Object.create(superClass.prototype);
  subClass.prototype.constructor = subClass;
  subClass.__proto__ = superClass;
}
function _objectWithoutPropertiesLoose2(source, excluded) {
  if (source == null) return {};
  var target = {};
  var sourceKeys = Object.keys(source);
  var key, i2;
  for (i2 = 0; i2 < sourceKeys.length; i2++) {
    key = sourceKeys[i2];
    if (excluded.indexOf(key) >= 0) continue;
    target[key] = source[key];
  }
  return target;
}
function _assertThisInitialized(self2) {
  if (self2 === void 0) {
    throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
  }
  return self2;
}
function _unsupportedIterableToArray(o2, minLen) {
  if (!o2) return;
  if (typeof o2 === "string") return _arrayLikeToArray(o2, minLen);
  var n2 = Object.prototype.toString.call(o2).slice(8, -1);
  if (n2 === "Object" && o2.constructor) n2 = o2.constructor.name;
  if (n2 === "Map" || n2 === "Set") return Array.from(o2);
  if (n2 === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n2)) return _arrayLikeToArray(o2, minLen);
}
function _arrayLikeToArray(arr, len) {
  if (len == null || len > arr.length) len = arr.length;
  for (var i2 = 0, arr2 = new Array(len); i2 < len; i2++) arr2[i2] = arr[i2];
  return arr2;
}
function _createForOfIteratorHelperLoose(o2, allowArrayLike) {
  var it;
  if (typeof Symbol === "undefined" || o2[Symbol.iterator] == null) {
    if (Array.isArray(o2) || (it = _unsupportedIterableToArray(o2)) || allowArrayLike && o2 && typeof o2.length === "number") {
      if (it) o2 = it;
      var i2 = 0;
      return function() {
        if (i2 >= o2.length) return {
          done: true
        };
        return {
          done: false,
          value: o2[i2++]
        };
      };
    }
    throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
  }
  it = o2[Symbol.iterator]();
  return it.next.bind(it);
}
function noop2() {
}
function chainFns() {
  for (var _len = arguments.length, fns = new Array(_len), _key = 0; _key < _len; _key++) {
    fns[_key] = arguments[_key];
  }
  if (fns.length === 0) return noop2;
  if (fns.length === 1) return fns[0];
  return function() {
    var result;
    for (var _iterator = _createForOfIteratorHelperLoose(fns), _step; !(_step = _iterator()).done; ) {
      var fn = _step.value;
      result = fn.apply(this, arguments) || result;
    }
    return result;
  };
}
function ensureVector(value, fallback) {
  if (value === void 0) {
    if (fallback === void 0) {
      throw new Error("Must define fallback value if undefined is expected");
    }
    value = fallback;
  }
  if (Array.isArray(value)) return value;
  return [value, value];
}
function assignDefault(value, fallback) {
  return Object.assign({}, fallback, value || {});
}
function valueFn(v) {
  if (typeof v === "function") {
    for (var _len2 = arguments.length, args = new Array(_len2 > 1 ? _len2 - 1 : 0), _key2 = 1; _key2 < _len2; _key2++) {
      args[_key2 - 1] = arguments[_key2];
    }
    return v.apply(void 0, args);
  } else {
    return v;
  }
}
function resolveWith(config2, resolvers) {
  if (config2 === void 0) {
    config2 = {};
  }
  var result = {};
  for (var _i = 0, _Object$entries = Object.entries(resolvers); _i < _Object$entries.length; _i++) {
    var _Object$entries$_i = _Object$entries[_i], key = _Object$entries$_i[0], resolver = _Object$entries$_i[1];
    switch (typeof resolver) {
      case "function":
        result[key] = resolver.call(result, config2[key], key, config2);
        break;
      case "object":
        result[key] = resolveWith(config2[key], resolver);
        break;
      case "boolean":
        if (resolver) result[key] = config2[key];
        break;
    }
  }
  return result;
}
var DEFAULT_DRAG_DELAY = 180;
var DEFAULT_RUBBERBAND = 0.15;
var DEFAULT_SWIPE_VELOCITY = 0.5;
var DEFAULT_SWIPE_DISTANCE = 60;
var InternalGestureOptionsNormalizers = {
  threshold: function threshold(value) {
    if (value === void 0) {
      value = 0;
    }
    return ensureVector(value);
  },
  rubberband: function rubberband3(value) {
    if (value === void 0) {
      value = 0;
    }
    switch (value) {
      case true:
        return ensureVector(DEFAULT_RUBBERBAND);
      case false:
        return ensureVector(0);
      default:
        return ensureVector(value);
    }
  },
  enabled: function enabled(value) {
    if (value === void 0) {
      value = true;
    }
    return value;
  },
  triggerAllEvents: function triggerAllEvents(value) {
    if (value === void 0) {
      value = false;
    }
    return value;
  },
  initial: function initial(value) {
    if (value === void 0) {
      value = 0;
    }
    if (typeof value === "function") return value;
    return ensureVector(value);
  }
};
var InternalCoordinatesOptionsNormalizers = _extends2({}, InternalGestureOptionsNormalizers, {
  axis: true,
  lockDirection: function lockDirection(value) {
    if (value === void 0) {
      value = false;
    }
    return value;
  },
  bounds: function bounds(value) {
    if (value === void 0) {
      value = {};
    }
    if (typeof value === "function") return function(state) {
      return InternalCoordinatesOptionsNormalizers.bounds(value(state));
    };
    var _value2 = value, _value2$left = _value2.left, left = _value2$left === void 0 ? -Infinity : _value2$left, _value2$right = _value2.right, right = _value2$right === void 0 ? Infinity : _value2$right, _value2$top = _value2.top, top = _value2$top === void 0 ? -Infinity : _value2$top, _value2$bottom = _value2.bottom, bottom = _value2$bottom === void 0 ? Infinity : _value2$bottom;
    return [[left, right], [top, bottom]];
  }
});
var isBrowser = typeof window !== "undefined" && window.document && window.document.createElement;
var InternalGenericOptionsNormalizers = {
  enabled: function enabled2(value) {
    if (value === void 0) {
      value = true;
    }
    return value;
  },
  domTarget: true,
  window: function(_window) {
    function window2(_x) {
      return _window.apply(this, arguments);
    }
    window2.toString = function() {
      return _window.toString();
    };
    return window2;
  }(function(value) {
    if (value === void 0) {
      value = isBrowser ? window : void 0;
    }
    return value;
  }),
  eventOptions: function eventOptions(_temp) {
    var _ref = _temp === void 0 ? {} : _temp, _ref$passive = _ref.passive, passive = _ref$passive === void 0 ? true : _ref$passive, _ref$capture = _ref.capture, capture = _ref$capture === void 0 ? false : _ref$capture;
    return {
      passive,
      capture
    };
  }
};
var InternalDistanceAngleOptionsNormalizers = _extends2({}, InternalGestureOptionsNormalizers, {
  bounds: function bounds2(_value, _key, _ref2) {
    var _ref2$distanceBounds = _ref2.distanceBounds, distanceBounds = _ref2$distanceBounds === void 0 ? {} : _ref2$distanceBounds, _ref2$angleBounds = _ref2.angleBounds, angleBounds = _ref2$angleBounds === void 0 ? {} : _ref2$angleBounds;
    var _distanceBounds = function _distanceBounds2(state) {
      var D2 = assignDefault(valueFn(distanceBounds, state), {
        min: -Infinity,
        max: Infinity
      });
      return [D2.min, D2.max];
    };
    var _angleBounds = function _angleBounds2(state) {
      var A2 = assignDefault(valueFn(angleBounds, state), {
        min: -Infinity,
        max: Infinity
      });
      return [A2.min, A2.max];
    };
    if (typeof distanceBounds !== "function" && typeof angleBounds !== "function") return [_distanceBounds(), _angleBounds()];
    return function(state) {
      return [_distanceBounds(state), _angleBounds(state)];
    };
  }
});
var InternalDragOptionsNormalizers = _extends2({}, InternalCoordinatesOptionsNormalizers, {
  threshold: function threshold2(v, _k, _ref3) {
    var _ref3$filterTaps = _ref3.filterTaps, filterTaps = _ref3$filterTaps === void 0 ? false : _ref3$filterTaps, _ref3$lockDirection = _ref3.lockDirection, lockDirection2 = _ref3$lockDirection === void 0 ? false : _ref3$lockDirection, _ref3$axis = _ref3.axis, axis = _ref3$axis === void 0 ? void 0 : _ref3$axis;
    var A2 = ensureVector(v, filterTaps ? 3 : lockDirection2 ? 1 : axis ? 1 : 0);
    this.filterTaps = filterTaps || A2[0] + A2[1] > 0;
    return A2;
  },
  swipeVelocity: function swipeVelocity(v) {
    if (v === void 0) {
      v = DEFAULT_SWIPE_VELOCITY;
    }
    return ensureVector(v);
  },
  swipeDistance: function swipeDistance(v) {
    if (v === void 0) {
      v = DEFAULT_SWIPE_DISTANCE;
    }
    return ensureVector(v);
  },
  delay: function delay(value) {
    if (value === void 0) {
      value = 0;
    }
    switch (value) {
      case true:
        return DEFAULT_DRAG_DELAY;
      case false:
        return 0;
      default:
        return value;
    }
  }
});
function getInternalGenericOptions(config2) {
  if (config2 === void 0) {
    config2 = {};
  }
  return resolveWith(config2, InternalGenericOptionsNormalizers);
}
function getInternalDragOptions(config2) {
  if (config2 === void 0) {
    config2 = {};
  }
  return resolveWith(config2, InternalDragOptionsNormalizers);
}
function _buildDragConfig(_ref3) {
  var domTarget = _ref3.domTarget, eventOptions2 = _ref3.eventOptions, window2 = _ref3.window, enabled3 = _ref3.enabled, rest = _objectWithoutPropertiesLoose2(_ref3, ["domTarget", "eventOptions", "window", "enabled"]);
  var opts = getInternalGenericOptions({
    domTarget,
    eventOptions: eventOptions2,
    window: window2,
    enabled: enabled3
  });
  opts.drag = getInternalDragOptions(rest);
  return opts;
}
function getInitial(mixed) {
  return _extends2({
    _active: false,
    _blocked: false,
    _intentional: [false, false],
    _movement: [0, 0],
    _initial: [0, 0],
    _bounds: [[-Infinity, Infinity], [-Infinity, Infinity]],
    _lastEventType: void 0,
    event: void 0,
    // currentTarget: undefined,
    // pointerId: undefined,
    intentional: false,
    values: [0, 0],
    velocities: [0, 0],
    delta: [0, 0],
    movement: [0, 0],
    offset: [0, 0],
    lastOffset: [0, 0],
    direction: [0, 0],
    initial: [0, 0],
    previous: [0, 0],
    first: false,
    last: false,
    active: false,
    timeStamp: 0,
    startTime: 0,
    elapsedTime: 0,
    cancel: noop2,
    canceled: false,
    memo: void 0,
    args: void 0
  }, mixed);
}
function getInitialState() {
  var shared = {
    hovering: false,
    scrolling: false,
    wheeling: false,
    dragging: false,
    moving: false,
    pinching: false,
    touches: 0,
    buttons: 0,
    down: false,
    shiftKey: false,
    altKey: false,
    metaKey: false,
    ctrlKey: false
  };
  var drag = getInitial({
    axis: void 0,
    xy: [0, 0],
    vxvy: [0, 0],
    velocity: 0,
    distance: 0,
    _isTap: true,
    _delayedEvent: false,
    _pointerId: void 0,
    tap: false,
    swipe: [0, 0]
  });
  var pinch = getInitial({
    da: [0, 0],
    vdva: [0, 0],
    // @ts-ignore origin can never be passed as undefined in userland
    origin: void 0,
    turns: 0
  });
  var wheel = getInitial({
    axis: void 0,
    xy: [0, 0],
    vxvy: [0, 0],
    velocity: 0,
    distance: 0
  });
  var move = getInitial({
    axis: void 0,
    xy: [0, 0],
    vxvy: [0, 0],
    velocity: 0,
    distance: 0
  });
  var scroll = getInitial({
    axis: void 0,
    xy: [0, 0],
    vxvy: [0, 0],
    velocity: 0,
    distance: 0
  });
  return {
    shared,
    drag,
    pinch,
    wheel,
    move,
    scroll
  };
}
var RecognizersMap = /* @__PURE__ */ new Map();
var Recognizer = function() {
  function Recognizer2(controller, args) {
    var _this = this;
    if (args === void 0) {
      args = [];
    }
    this.controller = controller;
    this.args = args;
    this.debounced = true;
    this.setTimeout = function(callback, ms) {
      var _window;
      if (ms === void 0) {
        ms = 140;
      }
      clearTimeout(_this.controller.timeouts[_this.stateKey]);
      for (var _len = arguments.length, args2 = new Array(_len > 2 ? _len - 2 : 0), _key = 2; _key < _len; _key++) {
        args2[_key - 2] = arguments[_key];
      }
      _this.controller.timeouts[_this.stateKey] = (_window = window).setTimeout.apply(_window, [callback, ms].concat(args2));
    };
    this.clearTimeout = function() {
      clearTimeout(_this.controller.timeouts[_this.stateKey]);
    };
    this.fireGestureHandler = function(forceFlag) {
      if (forceFlag === void 0) {
        forceFlag = false;
      }
      if (_this.state._blocked) {
        if (!_this.debounced) {
          _this.state._active = false;
          _this.clean();
        }
        return null;
      }
      if (!forceFlag && !_this.state.intentional && !_this.config.triggerAllEvents) return null;
      if (_this.state.intentional) {
        var prev_active = _this.state.active;
        var next_active = _this.state._active;
        _this.state.active = next_active;
        _this.state.first = next_active && !prev_active;
        _this.state.last = prev_active && !next_active;
        _this.controller.state.shared[_this.ingKey] = next_active;
      }
      var state = _extends2({}, _this.controller.state.shared, _this.state, _this.mapStateValues(_this.state));
      var newMemo = _this.handler(state);
      _this.state.memo = newMemo !== void 0 ? newMemo : _this.state.memo;
      if (!_this.state._active) _this.clean();
      return state;
    };
  }
  var _proto = Recognizer2.prototype;
  _proto.updateSharedState = function updateSharedState(sharedState) {
    Object.assign(this.controller.state.shared, sharedState);
  };
  _proto.updateGestureState = function updateGestureState(gestureState) {
    Object.assign(this.state, gestureState);
  };
  _proto.checkIntentionality = function checkIntentionality(_intentional, _movement) {
    return {
      _intentional,
      _blocked: false
    };
  };
  _proto.getMovement = function getMovement(values) {
    var _this$config = this.config, initial2 = _this$config.initial, bounds3 = _this$config.bounds, rubberband4 = _this$config.rubberband, T2 = _this$config.threshold;
    var _this$state = this.state, _bounds = _this$state._bounds, _initial = _this$state._initial, _active = _this$state._active, wasIntentional = _this$state._intentional, lastOffset = _this$state.lastOffset, prevMovement = _this$state.movement;
    var M2 = this.getInternalMovement(values, this.state);
    var i0 = wasIntentional[0] === false ? getIntentionalDisplacement(M2[0], T2[0]) : wasIntentional[0];
    var i1 = wasIntentional[1] === false ? getIntentionalDisplacement(M2[1], T2[1]) : wasIntentional[1];
    var intentionalityCheck = this.checkIntentionality([i0, i1], M2);
    if (intentionalityCheck._blocked) {
      return _extends2({}, intentionalityCheck, {
        _movement: M2,
        delta: [0, 0]
      });
    }
    var _intentional = intentionalityCheck._intentional;
    var _movement = M2;
    var __cachedBounds;
    var __cachedInitial;
    if (_intentional[0] !== false && wasIntentional[0] === false) {
      __cachedInitial = valueFn(initial2, this.state);
      __cachedBounds = valueFn(bounds3, this.state);
      _initial[0] = __cachedInitial[0];
      _bounds[0] = __cachedBounds[0];
    }
    if (_intentional[1] !== false && wasIntentional[1] === false) {
      var _cachedInitial, _cachedBounds;
      __cachedInitial = (_cachedInitial = __cachedInitial) != null ? _cachedInitial : valueFn(initial2, this.state);
      __cachedBounds = (_cachedBounds = __cachedBounds) != null ? _cachedBounds : valueFn(bounds3, this.state);
      _initial[1] = __cachedInitial[1];
      _bounds[1] = __cachedBounds[1];
    }
    var movement = [_intentional[0] !== false ? M2[0] - _intentional[0] : _initial[0], _intentional[1] !== false ? M2[1] - _intentional[1] : _initial[1]];
    var offset = addV(movement, lastOffset);
    var _rubberband = _active ? rubberband4 : [0, 0];
    movement = computeRubberband(_bounds, addV(movement, _initial), _rubberband);
    return _extends2({}, intentionalityCheck, {
      intentional: _intentional[0] !== false || _intentional[1] !== false,
      _initial,
      _movement,
      movement,
      values,
      offset: computeRubberband(_bounds, offset, _rubberband),
      delta: subV(movement, prevMovement)
    });
  };
  _proto.clean = function clean() {
    this.clearTimeout();
  };
  _createClass(Recognizer2, [{
    key: "config",
    get: function get() {
      return this.controller.config[this.stateKey];
    }
    // Is the gesture enabled
  }, {
    key: "enabled",
    get: function get() {
      return this.controller.config.enabled && this.config.enabled;
    }
    // Returns the controller state for a given gesture
  }, {
    key: "state",
    get: function get() {
      return this.controller.state[this.stateKey];
    }
    // Returns the gesture handler
  }, {
    key: "handler",
    get: function get() {
      return this.controller.handlers[this.stateKey];
    }
  }]);
  return Recognizer2;
}();
function getIntentionalDisplacement(movement, threshold3) {
  if (Math.abs(movement) >= threshold3) {
    return sign(movement) * threshold3;
  } else {
    return false;
  }
}
function computeRubberband(bounds3, _ref, _ref2) {
  var Vx = _ref[0], Vy = _ref[1];
  var Rx = _ref2[0], Ry = _ref2[1];
  var _bounds$ = bounds3[0], X1 = _bounds$[0], X2 = _bounds$[1], _bounds$2 = bounds3[1], Y1 = _bounds$2[0], Y2 = _bounds$2[1];
  return [rubberbandIfOutOfBounds(Vx, X1, X2, Rx), rubberbandIfOutOfBounds(Vy, Y1, Y2, Ry)];
}
function getGenericPayload(_ref3, event2, isStartEvent) {
  var state = _ref3.state, args = _ref3.args;
  var timeStamp = event2.timeStamp, _lastEventType = event2.type;
  var previous = state.values;
  var elapsedTime = isStartEvent ? 0 : timeStamp - state.startTime;
  return {
    _lastEventType,
    event: event2,
    timeStamp,
    elapsedTime,
    args,
    previous
  };
}
function getStartGestureState(recognizer, values, event2) {
  var offset = recognizer.state.offset;
  var startTime = event2.timeStamp;
  return _extends2({}, getInitialState()[recognizer.stateKey], {
    _active: true,
    values,
    initial: values,
    offset,
    lastOffset: offset,
    startTime
  });
}
function partial(func, state) {
  return function(event2) {
    for (var _len = arguments.length, args = new Array(_len > 1 ? _len - 1 : 0), _key = 1; _key < _len; _key++) {
      args[_key - 1] = arguments[_key];
    }
    return func.call.apply(func, [this, _extends2({}, state, {
      event: event2
    })].concat(args));
  };
}
var Controller2 = function Controller3(classes) {
  var _this = this;
  this.classes = classes;
  this.bind = function() {
    var bindings = {};
    for (var _len2 = arguments.length, args = new Array(_len2), _key2 = 0; _key2 < _len2; _key2++) {
      args[_key2] = arguments[_key2];
    }
    for (var _iterator = _createForOfIteratorHelperLoose(_this.classes), _step; !(_step = _iterator()).done; ) {
      var RecognizerClass = _step.value;
      new RecognizerClass(_this, args).addBindings(bindings);
    }
    for (var _i = 0, _Object$entries = Object.entries(_this.nativeRefs); _i < _Object$entries.length; _i++) {
      var _Object$entries$_i = _Object$entries[_i], event2 = _Object$entries$_i[0], handler = _Object$entries$_i[1];
      addBindings(bindings, event2, partial(handler, _extends2({}, _this.state.shared, {
        args
      })));
    }
    if (_this.config.domTarget) {
      return updateDomListeners(_this, bindings);
    } else {
      return getPropsListener(_this, bindings);
    }
  };
  this.effect = function() {
    if (_this.config.domTarget) _this.bind();
    return _this.clean;
  };
  this.clean = function() {
    var domTarget = getDomTargetFromConfig(_this.config);
    var eventOptions2 = _this.config.eventOptions;
    if (domTarget) removeListeners(domTarget, takeAll(_this.domListeners), eventOptions2);
    Object.values(_this.timeouts).forEach(clearTimeout);
    clearAllWindowListeners(_this);
  };
  this.state = getInitialState();
  this.timeouts = {};
  this.domListeners = [];
  this.windowListeners = {};
};
function clearAllWindowListeners(controller) {
  var _controller$config = controller.config, el = _controller$config.window, eventOptions2 = _controller$config.eventOptions, windowListeners = controller.windowListeners;
  if (!el) return;
  for (var stateKey in windowListeners) {
    var handlers = windowListeners[stateKey];
    removeListeners(el, handlers, eventOptions2);
  }
  controller.windowListeners = {};
}
function clearWindowListeners(_ref, stateKey) {
  var config2 = _ref.config, windowListeners = _ref.windowListeners;
  if (!config2.window) return;
  removeListeners(config2.window, windowListeners[stateKey], config2.eventOptions);
  delete windowListeners[stateKey];
}
function updateWindowListeners(_ref2, stateKey, listeners) {
  var config2 = _ref2.config, windowListeners = _ref2.windowListeners;
  if (listeners === void 0) {
    listeners = [];
  }
  if (!config2.window) return;
  removeListeners(config2.window, windowListeners[stateKey], config2.eventOptions);
  addListeners(config2.window, windowListeners[stateKey] = listeners, config2.eventOptions);
}
function updateDomListeners(_ref3, bindings) {
  var config2 = _ref3.config, domListeners = _ref3.domListeners;
  var domTarget = getDomTargetFromConfig(config2);
  if (!domTarget) throw new Error("domTarget must be defined");
  var eventOptions2 = config2.eventOptions;
  removeListeners(domTarget, takeAll(domListeners), eventOptions2);
  for (var _i2 = 0, _Object$entries2 = Object.entries(bindings); _i2 < _Object$entries2.length; _i2++) {
    var _Object$entries2$_i = _Object$entries2[_i2], key = _Object$entries2$_i[0], fns = _Object$entries2$_i[1];
    var name = key.slice(2).toLowerCase();
    domListeners.push([name, chainFns.apply(void 0, fns)]);
  }
  addListeners(domTarget, domListeners, eventOptions2);
}
function getPropsListener(_ref4, bindings) {
  var config2 = _ref4.config;
  var props = {};
  var captureString = config2.eventOptions.capture ? "Capture" : "";
  for (var _i3 = 0, _Object$entries3 = Object.entries(bindings); _i3 < _Object$entries3.length; _i3++) {
    var _Object$entries3$_i = _Object$entries3[_i3], event2 = _Object$entries3$_i[0], fns = _Object$entries3$_i[1];
    var fnsArray = Array.isArray(fns) ? fns : [fns];
    var key = event2 + captureString;
    props[key] = chainFns.apply(void 0, fnsArray);
  }
  return props;
}
function takeAll(array) {
  if (array === void 0) {
    array = [];
  }
  return array.splice(0, array.length);
}
function getDomTargetFromConfig(_ref5) {
  var domTarget = _ref5.domTarget;
  return domTarget && "current" in domTarget ? domTarget.current : domTarget;
}
function addBindings(bindings, name, fn) {
  if (!bindings[name]) bindings[name] = [];
  bindings[name].push(fn);
}
function addListeners(el, listeners, options) {
  if (listeners === void 0) {
    listeners = [];
  }
  if (options === void 0) {
    options = {};
  }
  for (var _iterator2 = _createForOfIteratorHelperLoose(listeners), _step2; !(_step2 = _iterator2()).done; ) {
    var _step2$value = _step2.value, eventName = _step2$value[0], eventHandler = _step2$value[1];
    el.addEventListener(eventName, eventHandler, options);
  }
}
function removeListeners(el, listeners, options) {
  if (listeners === void 0) {
    listeners = [];
  }
  if (options === void 0) {
    options = {};
  }
  for (var _iterator3 = _createForOfIteratorHelperLoose(listeners), _step3; !(_step3 = _iterator3()).done; ) {
    var _step3$value = _step3.value, eventName = _step3$value[0], eventHandler = _step3$value[1];
    el.removeEventListener(eventName, eventHandler, options);
  }
}
function useRecognizers(handlers, config2, nativeHandlers) {
  if (nativeHandlers === void 0) {
    nativeHandlers = {};
  }
  var classes = resolveClasses(handlers);
  var controller = import_react10.default.useMemo(function() {
    return new Controller2(classes);
  }, []);
  controller.config = config2;
  controller.handlers = handlers;
  controller.nativeRefs = nativeHandlers;
  import_react10.default.useEffect(controller.effect, []);
  if (controller.config.domTarget) return deprecationNoticeForDomTarget;
  return controller.bind;
}
function deprecationNoticeForDomTarget() {
  if (true) {
    console.warn("Deprecation notice: When the `domTarget` option is specified, you don't need to write `useEffect(bind, [bind])` anymore: event binding is now made handled internally to this lib.\n\nNext version won't return anything when `domTarget` is provided, therefore your code will break if you try to call `useEffect`.");
  }
}
function resolveClasses(internalHandlers) {
  var classes = /* @__PURE__ */ new Set();
  if (internalHandlers.drag) classes.add(RecognizersMap.get("drag"));
  if (internalHandlers.wheel) classes.add(RecognizersMap.get("wheel"));
  if (internalHandlers.scroll) classes.add(RecognizersMap.get("scroll"));
  if (internalHandlers.move) classes.add(RecognizersMap.get("move"));
  if (internalHandlers.pinch) classes.add(RecognizersMap.get("pinch"));
  if (internalHandlers.hover) classes.add(RecognizersMap.get("hover"));
  return classes;
}
var CoordinatesRecognizer = function(_Recognizer) {
  _inheritsLoose(CoordinatesRecognizer2, _Recognizer);
  function CoordinatesRecognizer2() {
    return _Recognizer.apply(this, arguments) || this;
  }
  var _proto = CoordinatesRecognizer2.prototype;
  _proto.getInternalMovement = function getInternalMovement(values, state) {
    return subV(values, state.initial);
  };
  _proto.checkIntentionality = function checkIntentionality(_intentional, _movement) {
    if (_intentional[0] === false && _intentional[1] === false) {
      return {
        _intentional,
        axis: this.state.axis
      };
    }
    var _movement$map = _movement.map(Math.abs), absX = _movement$map[0], absY = _movement$map[1];
    var axis = this.state.axis || (absX > absY ? "x" : absX < absY ? "y" : void 0);
    if (!this.config.axis && !this.config.lockDirection) return {
      _intentional,
      _blocked: false,
      axis
    };
    if (!axis) return {
      _intentional: [false, false],
      _blocked: false,
      axis
    };
    if (!!this.config.axis && axis !== this.config.axis) return {
      _intentional,
      _blocked: true,
      axis
    };
    _intentional[axis === "x" ? 1 : 0] = false;
    return {
      _intentional,
      _blocked: false,
      axis
    };
  };
  _proto.getKinematics = function getKinematics(values, event2) {
    var state = this.getMovement(values);
    if (!state._blocked) {
      var dt = event2.timeStamp - this.state.timeStamp;
      Object.assign(state, calculateAllKinematics(state.movement, state.delta, dt));
    }
    return state;
  };
  _proto.mapStateValues = function mapStateValues(state) {
    return {
      xy: state.values,
      vxvy: state.velocities
    };
  };
  return CoordinatesRecognizer2;
}(Recognizer);
var WEBKIT_DISTANCE_SCALE_FACTOR = 260;
function supportsGestureEvents() {
  try {
    return "constructor" in GestureEvent;
  } catch (e) {
    return false;
  }
}
function supportsTouchEvents() {
  return typeof window !== "undefined" && window.ontouchstart === null;
}
function getTouchEvents(event2) {
  if ("touches" in event2) {
    var targetTouches = event2.targetTouches, changedTouches = event2.changedTouches;
    return targetTouches.length > 0 ? targetTouches : changedTouches;
  }
  return null;
}
function getGenericEventData(event2) {
  var buttons = "buttons" in event2 ? event2.buttons : 0;
  var touchEvents = getTouchEvents(event2);
  var touches = touchEvents && touchEvents.length || 0;
  var down = touches > 0 || buttons > 0;
  var shiftKey = event2.shiftKey, altKey = event2.altKey, metaKey = event2.metaKey, ctrlKey = event2.ctrlKey;
  return {
    touches,
    down,
    buttons,
    shiftKey,
    altKey,
    metaKey,
    ctrlKey
  };
}
function getPointerEventValues(event2) {
  var touchEvents = getTouchEvents(event2);
  var _ref = touchEvents ? touchEvents[0] : event2, clientX = _ref.clientX, clientY = _ref.clientY;
  return [clientX, clientY];
}
function getScrollEventValues(event2) {
  var _event$currentTarget = event2.currentTarget, scrollX = _event$currentTarget.scrollX, scrollY = _event$currentTarget.scrollY, scrollLeft = _event$currentTarget.scrollLeft, scrollTop = _event$currentTarget.scrollTop;
  return [scrollX || scrollLeft || 0, scrollY || scrollTop || 0];
}
function getWheelEventValues(event2) {
  var deltaX = event2.deltaX, deltaY = event2.deltaY;
  return [deltaX, deltaY];
}
function getWebkitGestureEventValues(event2) {
  return [event2.scale * WEBKIT_DISTANCE_SCALE_FACTOR, event2.rotation];
}
function getTwoTouchesEventData(event2) {
  var _e$rotation;
  var targetTouches = event2.targetTouches;
  var A2 = targetTouches[0], B2 = targetTouches[1];
  var dx = B2.clientX - A2.clientX;
  var dy = B2.clientY - A2.clientY;
  var cx = (B2.clientX + A2.clientX) / 2;
  var cy = (B2.clientY + A2.clientY) / 2;
  var e = "nativeEvent" in event2 ? event2.nativeEvent : event2;
  var distance = Math.hypot(dx, dy);
  var angle = (_e$rotation = e.rotation) != null ? _e$rotation : -(Math.atan2(dx, dy) * 180) / Math.PI;
  var values = [distance, angle];
  var origin = [cx, cy];
  return {
    values,
    origin
  };
}
var TAP_DISTANCE_THRESHOLD = 3;
var SWIPE_MAX_ELAPSED_TIME = 220;
var DragRecognizer = function(_CoordinatesRecognize) {
  _inheritsLoose(DragRecognizer2, _CoordinatesRecognize);
  function DragRecognizer2() {
    var _this;
    _this = _CoordinatesRecognize.apply(this, arguments) || this;
    _this.ingKey = "dragging";
    _this.stateKey = "drag";
    _this.onDragStart = function(event2) {
      if (!_this.enabled || _this.state._active) return;
      updateWindowListeners(_this.controller, _this.stateKey, [["pointermove", _this.onDragChange], ["pointerup", _this.onDragEnd], ["pointercancel", _this.onDragEnd]]);
      _this.updateGestureState({
        _pointerId: event2.pointerId
      });
      if (_this.config.delay > 0) {
        _this.state._delayedEvent = true;
        if ("persist" in event2 && typeof event2.persist === "function") event2.persist();
        _this.setTimeout(_this.startDrag.bind(_assertThisInitialized(_this)), _this.config.delay, event2);
      } else {
        _this.startDrag(event2);
      }
    };
    _this.onDragChange = function(event2) {
      if (_this.state.canceled) return;
      if (event2.pointerId !== _this.state._pointerId) return;
      if (!_this.state._active) {
        if (_this.state._delayedEvent) {
          _this.clearTimeout();
          _this.startDrag(event2);
        }
        return;
      }
      var genericEventData = getGenericEventData(event2);
      if (!genericEventData.down) {
        _this.onDragEnd(event2);
        return;
      }
      _this.updateSharedState(genericEventData);
      var values = getPointerEventValues(event2);
      var kinematics = _this.getKinematics(values, event2);
      var genericPayload = getGenericPayload(_assertThisInitialized(_this), event2);
      var _isTap = _this.state._isTap;
      var realDistance = calculateDistance(kinematics._movement);
      if (_isTap && realDistance >= TAP_DISTANCE_THRESHOLD) _isTap = false;
      _this.updateGestureState(_extends2({}, genericPayload, kinematics, {
        _isTap
      }));
      _this.fireGestureHandler();
    };
    _this.onDragEnd = function(event2) {
      if (event2.pointerId !== _this.state._pointerId) return;
      _this.state._active = false;
      _this.updateSharedState({
        down: false,
        buttons: 0,
        touches: 0
      });
      var tap = _this.state._isTap;
      var _this$state$velocitie = _this.state.velocities, vx = _this$state$velocitie[0], vy = _this$state$velocitie[1];
      var _this$state$movement = _this.state.movement, mx = _this$state$movement[0], my = _this$state$movement[1];
      var _this$state$_intentio = _this.state._intentional, ix = _this$state$_intentio[0], iy = _this$state$_intentio[1];
      var _this$config$swipeVel = _this.config.swipeVelocity, svx = _this$config$swipeVel[0], svy = _this$config$swipeVel[1];
      var _this$config$swipeDis = _this.config.swipeDistance, sx = _this$config$swipeDis[0], sy = _this$config$swipeDis[1];
      var endState = _extends2({}, getGenericPayload(_assertThisInitialized(_this), event2), _this.getMovement(_this.state.values));
      var swipe = [0, 0];
      if (endState.elapsedTime < SWIPE_MAX_ELAPSED_TIME) {
        if (ix !== false && Math.abs(vx) > svx && Math.abs(mx) > sx) swipe[0] = sign(vx);
        if (iy !== false && Math.abs(vy) > svy && Math.abs(my) > sy) swipe[1] = sign(vy);
      }
      _this.updateGestureState(_extends2({}, endState, {
        tap,
        swipe
      }));
      _this.fireGestureHandler(tap === true);
    };
    _this.clean = function() {
      _CoordinatesRecognize.prototype.clean.call(_assertThisInitialized(_this));
      _this.state._delayedEvent = false;
      clearWindowListeners(_this.controller, _this.stateKey);
    };
    _this.onCancel = function() {
      if (_this.state.canceled) return;
      _this.updateGestureState({
        canceled: true
      });
      _this.state._active = false;
      _this.updateSharedState({
        down: false,
        buttons: 0,
        touches: 0
      });
      requestAnimationFrame(function() {
        return _this.fireGestureHandler();
      });
    };
    _this.onClick = function(event2) {
      if (!_this.state._isTap) event2.stopPropagation();
    };
    return _this;
  }
  var _proto = DragRecognizer2.prototype;
  _proto.startDrag = function startDrag(event2) {
    var values = getPointerEventValues(event2);
    this.updateSharedState(getGenericEventData(event2));
    this.updateGestureState(_extends2({}, getStartGestureState(this, values, event2), getGenericPayload(this, event2, true), {
      _pointerId: event2.pointerId,
      cancel: this.onCancel
    }));
    this.updateGestureState(this.getMovement(values));
    this.fireGestureHandler();
  };
  _proto.addBindings = function addBindings$1(bindings) {
    addBindings(bindings, "onPointerDown", this.onDragStart);
    if (this.config.filterTaps) {
      var handler = this.controller.config.eventOptions.capture ? "onClick" : "onClickCapture";
      addBindings(bindings, handler, this.onClick);
    }
  };
  return DragRecognizer2;
}(CoordinatesRecognizer);
function memoizeOne(resultFn, isEqual2) {
  var lastThis;
  var lastArgs = [];
  var lastResult;
  var calledOnce = false;
  function memoized() {
    for (var _len = arguments.length, newArgs = new Array(_len), _key = 0; _key < _len; _key++) {
      newArgs[_key] = arguments[_key];
    }
    if (calledOnce && lastThis === this && isEqual2(newArgs, lastArgs)) {
      return lastResult;
    }
    lastResult = resultFn.apply(this, newArgs);
    calledOnce = true;
    lastThis = this;
    lastArgs = newArgs;
    return lastResult;
  }
  return memoized;
}
function equal(a2, b) {
  if (a2 === b) return true;
  if (a2 && b && typeof a2 == "object" && typeof b == "object") {
    if (a2.constructor !== b.constructor) return false;
    var length, i2, keys;
    if (Array.isArray(a2)) {
      length = a2.length;
      if (length !== b.length) return false;
      for (i2 = length; i2-- !== 0; ) {
        if (!equal(a2[i2], b[i2])) return false;
      }
      return true;
    }
    var it;
    if (typeof Map === "function" && a2 instanceof Map && b instanceof Map) {
      if (a2.size !== b.size) return false;
      it = a2.entries();
      while (!(i2 = it.next()).done) {
        if (!b.has(i2.value[0])) return false;
      }
      it = a2.entries();
      while (!(i2 = it.next()).done) {
        if (!equal(i2.value[1], b.get(i2.value[0]))) return false;
      }
      return true;
    }
    if (typeof Set === "function" && a2 instanceof Set && b instanceof Set) {
      if (a2.size !== b.size) return false;
      it = a2.entries();
      while (!(i2 = it.next()).done) {
        if (!b.has(i2.value[0])) return false;
      }
      return true;
    }
    if (a2.constructor === RegExp) return a2.source === b.source && a2.flags === b.flags;
    if (a2.valueOf !== Object.prototype.valueOf) return a2.valueOf() === b.valueOf();
    if (a2.toString !== Object.prototype.toString) return a2.toString() === b.toString();
    keys = Object.keys(a2);
    length = keys.length;
    if (length !== Object.keys(b).length) return false;
    for (i2 = length; i2-- !== 0; ) {
      if (!Object.prototype.hasOwnProperty.call(b, keys[i2])) return false;
    }
    if (typeof Element !== "undefined" && a2 instanceof Element) return false;
    for (i2 = length; i2-- !== 0; ) {
      if (keys[i2] === "_owner" && a2.$$typeof) continue;
      if (!equal(a2[keys[i2]], b[keys[i2]])) return false;
    }
    return true;
  }
  return a2 !== a2 && b !== b;
}
function isEqual(a2, b) {
  try {
    return equal(a2, b);
  } catch (error3) {
    if ((error3.message || "").match(/stack|recursion/i)) {
      console.warn("react-fast-compare cannot handle circular refs");
      return false;
    }
    throw error3;
  }
}
function useDrag(handler, config2) {
  if (config2 === void 0) {
    config2 = {};
  }
  RecognizersMap.set("drag", DragRecognizer);
  var buildDragConfig = (0, import_react10.useRef)();
  if (!buildDragConfig.current) {
    buildDragConfig.current = memoizeOne(_buildDragConfig, isEqual);
  }
  return useRecognizers({
    drag: handler
  }, buildDragConfig.current(config2));
}
var DistanceAngleRecognizer = function(_Recognizer) {
  _inheritsLoose(DistanceAngleRecognizer2, _Recognizer);
  function DistanceAngleRecognizer2() {
    return _Recognizer.apply(this, arguments) || this;
  }
  var _proto = DistanceAngleRecognizer2.prototype;
  _proto.getInternalMovement = function getInternalMovement(values, state) {
    var prev_a = state.values[1];
    var d = values[0], _values$ = values[1], a2 = _values$ === void 0 ? prev_a : _values$;
    var delta_a = a2 - prev_a;
    var next_turns = state.turns;
    if (Math.abs(delta_a) > 270) next_turns += sign(delta_a);
    return subV([d, a2 - 360 * next_turns], state.initial);
  };
  _proto.getKinematics = function getKinematics(values, event2) {
    var state = this.getMovement(values);
    var turns = (values[1] - state.movement[1] - this.state.initial[1]) / 360;
    var dt = event2.timeStamp - this.state.timeStamp;
    var kinematics = calculateAllKinematics(state.movement, state.delta, dt);
    return _extends2({
      turns
    }, state, kinematics);
  };
  _proto.mapStateValues = function mapStateValues(state) {
    return {
      da: state.values,
      vdva: state.velocities
    };
  };
  return DistanceAngleRecognizer2;
}(Recognizer);
var PinchRecognizer = function(_DistanceAngleRecogni) {
  _inheritsLoose(PinchRecognizer2, _DistanceAngleRecogni);
  function PinchRecognizer2() {
    var _this;
    _this = _DistanceAngleRecogni.apply(this, arguments) || this;
    _this.ingKey = "pinching";
    _this.stateKey = "pinch";
    _this.pinchShouldStart = function(event2) {
      var _getGenericEventData = getGenericEventData(event2), touches = _getGenericEventData.touches;
      return _this.enabled && touches === 2;
    };
    _this.onPinchStart = function(event2) {
      if (!_this.pinchShouldStart(event2)) return;
      var _getTwoTouchesEventDa = getTwoTouchesEventData(event2), values = _getTwoTouchesEventDa.values, origin = _getTwoTouchesEventDa.origin;
      _this.updateSharedState(getGenericEventData(event2));
      _this.updateGestureState(_extends2({}, getStartGestureState(_assertThisInitialized(_this), values, event2), getGenericPayload(_assertThisInitialized(_this), event2, true), {
        cancel: _this.onCancel,
        origin
      }));
      _this.updateGestureState(_this.getMovement(values));
      _this.fireGestureHandler();
    };
    _this.onPinchChange = function(event2) {
      var _this$state = _this.state, canceled = _this$state.canceled, _active = _this$state._active;
      if (canceled || !_active) return;
      var genericEventData = getGenericEventData(event2);
      _this.updateSharedState(genericEventData);
      var _getTwoTouchesEventDa2 = getTwoTouchesEventData(event2), values = _getTwoTouchesEventDa2.values, origin = _getTwoTouchesEventDa2.origin;
      var kinematics = _this.getKinematics(values, event2);
      _this.updateGestureState(_extends2({}, getGenericPayload(_assertThisInitialized(_this), event2), kinematics, {
        origin
      }));
      _this.fireGestureHandler();
    };
    _this.onPinchEnd = function(event2) {
      if (!_this.state.active) return;
      _this.state._active = false;
      _this.updateSharedState({
        down: false,
        touches: 0
      });
      _this.updateGestureState(_extends2({}, getGenericPayload(_assertThisInitialized(_this), event2), _this.getMovement(_this.state.values)));
      _this.fireGestureHandler();
    };
    _this.onCancel = function() {
      if (_this.state.canceled) return;
      _this.state._active = false;
      _this.updateGestureState({
        canceled: true
      });
      _this.updateSharedState({
        down: false,
        touches: 0
      });
      requestAnimationFrame(function() {
        return _this.fireGestureHandler();
      });
    };
    _this.onGestureStart = function(event2) {
      if (!_this.enabled) return;
      event2.preventDefault();
      var values = getWebkitGestureEventValues(event2);
      _this.updateSharedState(getGenericEventData(event2));
      _this.updateGestureState(_extends2({}, getStartGestureState(_assertThisInitialized(_this), values, event2), getGenericPayload(_assertThisInitialized(_this), event2, true), {
        origin: [event2.clientX, event2.clientY],
        cancel: _this.onCancel
      }));
      _this.updateGestureState(_this.getMovement(values));
      _this.fireGestureHandler();
    };
    _this.onGestureChange = function(event2) {
      var _this$state2 = _this.state, canceled = _this$state2.canceled, _active = _this$state2._active;
      if (canceled || !_active) return;
      event2.preventDefault();
      var genericEventData = getGenericEventData(event2);
      _this.updateSharedState(genericEventData);
      var values = getWebkitGestureEventValues(event2);
      var kinematics = _this.getKinematics(values, event2);
      _this.updateGestureState(_extends2({}, getGenericPayload(_assertThisInitialized(_this), event2), kinematics, {
        origin: [event2.clientX, event2.clientY]
      }));
      _this.fireGestureHandler();
    };
    _this.onGestureEnd = function(event2) {
      event2.preventDefault();
      if (!_this.state.active) return;
      _this.state._active = false;
      _this.updateSharedState({
        down: false,
        touches: 0
      });
      _this.updateGestureState(_extends2({}, getGenericPayload(_assertThisInitialized(_this), event2), _this.getMovement(_this.state.values), {
        origin: [event2.clientX, event2.clientY]
      }));
      _this.fireGestureHandler();
    };
    _this.wheelShouldRun = function(event2) {
      return _this.enabled && event2.ctrlKey;
    };
    _this.getWheelValuesFromEvent = function(event2) {
      var _getWheelEventValues = getWheelEventValues(event2), delta_d = _getWheelEventValues[1];
      var _this$state$values = _this.state.values, prev_d = _this$state$values[0], prev_a = _this$state$values[1];
      var d = prev_d - delta_d;
      var a2 = prev_a !== void 0 ? prev_a : 0;
      return {
        values: [d, a2],
        origin: [event2.clientX, event2.clientY],
        delta: [0, delta_d]
      };
    };
    _this.onWheel = function(event2) {
      if (!_this.wheelShouldRun(event2)) return;
      _this.setTimeout(_this.onWheelEnd);
      if (!_this.state._active) _this.onWheelStart(event2);
      else _this.onWheelChange(event2);
    };
    _this.onWheelStart = function(event2) {
      var _this$getWheelValuesF = _this.getWheelValuesFromEvent(event2), values = _this$getWheelValuesF.values, delta = _this$getWheelValuesF.delta, origin = _this$getWheelValuesF.origin;
      if (event2.cancelable) event2.preventDefault();
      else if (true) {
        console.warn("To properly support zoom on trackpads, try using the `domTarget` option and `config.eventOptions.passive` set to `false`. This message will only appear in development mode.");
      }
      _this.updateSharedState(getGenericEventData(event2));
      _this.updateGestureState(_extends2({}, getStartGestureState(_assertThisInitialized(_this), values, event2), getGenericPayload(_assertThisInitialized(_this), event2, true), {
        initial: _this.state.values,
        offset: values,
        delta,
        origin
      }));
      _this.updateGestureState(_this.getMovement(values));
      _this.fireGestureHandler();
    };
    _this.onWheelChange = function(event2) {
      _this.updateSharedState(getGenericEventData(event2));
      var _this$getWheelValuesF2 = _this.getWheelValuesFromEvent(event2), values = _this$getWheelValuesF2.values, origin = _this$getWheelValuesF2.origin, delta = _this$getWheelValuesF2.delta;
      _this.updateGestureState(_extends2({}, getGenericPayload(_assertThisInitialized(_this), event2), _this.getKinematics(values, event2), {
        origin,
        delta
      }));
      _this.fireGestureHandler();
    };
    _this.onWheelEnd = function() {
      _this.state._active = false;
      _this.updateGestureState(_this.getMovement(_this.state.values));
      _this.fireGestureHandler();
    };
    return _this;
  }
  var _proto = PinchRecognizer2.prototype;
  _proto.addBindings = function addBindings$1(bindings) {
    if (this.controller.config.domTarget && !supportsTouchEvents() && supportsGestureEvents()) {
      addBindings(bindings, "onGestureStart", this.onGestureStart);
      addBindings(bindings, "onGestureChange", this.onGestureChange);
      addBindings(bindings, "onGestureEnd", this.onGestureEnd);
    } else {
      addBindings(bindings, "onTouchStart", this.onPinchStart);
      addBindings(bindings, "onTouchMove", this.onPinchChange);
      addBindings(bindings, "onTouchEnd", this.onPinchEnd);
      addBindings(bindings, "onTouchCancel", this.onPinchEnd);
      addBindings(bindings, "onWheel", this.onWheel);
    }
  };
  return PinchRecognizer2;
}(DistanceAngleRecognizer);
var WheelRecognizer = function(_CoordinatesRecognize) {
  _inheritsLoose(WheelRecognizer2, _CoordinatesRecognize);
  function WheelRecognizer2() {
    var _this;
    _this = _CoordinatesRecognize.apply(this, arguments) || this;
    _this.ingKey = "wheeling";
    _this.stateKey = "wheel";
    _this.debounced = true;
    _this.handleEvent = function(event2) {
      if (event2.ctrlKey && "pinch" in _this.controller.handlers) return;
      if (!_this.enabled) return;
      _this.setTimeout(_this.onEnd);
      _this.updateSharedState(getGenericEventData(event2));
      var values = addV(getWheelEventValues(event2), _this.state.values);
      if (!_this.state._active) {
        _this.updateGestureState(_extends2({}, getStartGestureState(_assertThisInitialized(_this), values, event2), getGenericPayload(_assertThisInitialized(_this), event2, true), {
          initial: _this.state.values
        }));
        var movement = _this.getMovement(values);
        var geometry = calculateAllGeometry(movement.delta);
        _this.updateGestureState(movement);
        _this.updateGestureState(geometry);
      } else {
        _this.updateGestureState(_extends2({}, getGenericPayload(_assertThisInitialized(_this), event2), _this.getKinematics(values, event2)));
      }
      _this.fireGestureHandler();
    };
    _this.onEnd = function() {
      var movement = _this.getMovement(_this.state.values);
      _this.updateGestureState(movement);
      _this.updateGestureState({
        _active: false,
        velocities: [0, 0],
        velocity: 0
      });
      _this.fireGestureHandler();
    };
    return _this;
  }
  var _proto = WheelRecognizer2.prototype;
  _proto.addBindings = function addBindings$1(bindings) {
    addBindings(bindings, "onWheel", this.handleEvent);
  };
  return WheelRecognizer2;
}(CoordinatesRecognizer);
var MoveRecognizer = function(_CoordinatesRecognize) {
  _inheritsLoose(MoveRecognizer2, _CoordinatesRecognize);
  function MoveRecognizer2() {
    var _this;
    _this = _CoordinatesRecognize.apply(this, arguments) || this;
    _this.ingKey = "moving";
    _this.stateKey = "move";
    _this.debounced = true;
    _this.onMove = function(event2) {
      if (!_this.enabled) return;
      _this.setTimeout(_this.onMoveEnd);
      if (!_this.state._active) _this.onMoveStart(event2);
      else _this.onMoveChange(event2);
    };
    _this.onMoveStart = function(event2) {
      _this.updateSharedState(getGenericEventData(event2));
      var values = getPointerEventValues(event2);
      _this.updateGestureState(_extends2({}, getStartGestureState(_assertThisInitialized(_this), values, event2), getGenericPayload(_assertThisInitialized(_this), event2, true)));
      _this.updateGestureState(_this.getMovement(values));
      _this.fireGestureHandler();
    };
    _this.onMoveChange = function(event2) {
      _this.updateSharedState(getGenericEventData(event2));
      var values = getPointerEventValues(event2);
      _this.updateGestureState(_extends2({}, getGenericPayload(_assertThisInitialized(_this), event2), _this.getKinematics(values, event2)));
      _this.fireGestureHandler();
    };
    _this.onMoveEnd = function() {
      var values = _this.state.values;
      _this.updateGestureState(_this.getMovement(values));
      _this.updateGestureState({
        velocities: [0, 0],
        velocity: 0,
        _active: false
      });
      _this.fireGestureHandler();
    };
    _this.onPointerEnter = function(event2) {
      _this.controller.state.shared.hovering = true;
      if (!_this.controller.config.enabled) return;
      if (_this.controller.config.hover.enabled) {
        var values = getPointerEventValues(event2);
        var state = _extends2({}, _this.controller.state.shared, _this.state, getGenericPayload(_assertThisInitialized(_this), event2, true), {
          values,
          active: true,
          hovering: true
        });
        _this.controller.handlers.hover(_extends2({}, state, _this.mapStateValues(state)));
      }
      if ("move" in _this.controller.handlers) _this.onMoveStart(event2);
    };
    _this.onPointerLeave = function(event2) {
      _this.controller.state.shared.hovering = false;
      if ("move" in _this.controller.handlers) _this.onMoveEnd();
      if (!_this.controller.config.hover.enabled) return;
      var values = getPointerEventValues(event2);
      var state = _extends2({}, _this.controller.state.shared, _this.state, getGenericPayload(_assertThisInitialized(_this), event2), {
        values,
        active: false
      });
      _this.controller.handlers.hover(_extends2({}, state, _this.mapStateValues(state)));
    };
    return _this;
  }
  var _proto = MoveRecognizer2.prototype;
  _proto.addBindings = function addBindings$1(bindings) {
    if ("move" in this.controller.handlers) {
      addBindings(bindings, "onPointerMove", this.onMove);
    }
    if ("hover" in this.controller.handlers) {
      addBindings(bindings, "onPointerEnter", this.onPointerEnter);
      addBindings(bindings, "onPointerLeave", this.onPointerLeave);
    }
  };
  return MoveRecognizer2;
}(CoordinatesRecognizer);
var ScrollRecognizer = function(_CoordinatesRecognize) {
  _inheritsLoose(ScrollRecognizer2, _CoordinatesRecognize);
  function ScrollRecognizer2() {
    var _this;
    _this = _CoordinatesRecognize.apply(this, arguments) || this;
    _this.ingKey = "scrolling";
    _this.stateKey = "scroll";
    _this.debounced = true;
    _this.handleEvent = function(event2) {
      if (!_this.enabled) return;
      _this.clearTimeout();
      _this.setTimeout(_this.onEnd);
      var values = getScrollEventValues(event2);
      _this.updateSharedState(getGenericEventData(event2));
      if (!_this.state._active) {
        _this.updateGestureState(_extends2({}, getStartGestureState(_assertThisInitialized(_this), values, event2), getGenericPayload(_assertThisInitialized(_this), event2, true), {
          initial: _this.state.values
        }));
        var movementDetection = _this.getMovement(values);
        var geometry = calculateAllGeometry(movementDetection.delta);
        _this.updateGestureState(movementDetection);
        _this.updateGestureState(geometry);
      } else {
        _this.updateGestureState(_extends2({}, getGenericPayload(_assertThisInitialized(_this), event2), _this.getKinematics(values, event2)));
      }
      _this.fireGestureHandler();
    };
    _this.onEnd = function() {
      _this.state._active = false;
      _this.updateGestureState(_extends2({}, _this.getMovement(_this.state.values), {
        velocities: [0, 0],
        velocity: 0
      }));
      _this.fireGestureHandler();
    };
    return _this;
  }
  var _proto = ScrollRecognizer2.prototype;
  _proto.addBindings = function addBindings$1(bindings) {
    addBindings(bindings, "onScroll", this.handleEvent);
  };
  return ScrollRecognizer2;
}(CoordinatesRecognizer);

// node_modules/tabbable/dist/index.esm.js
var candidateSelectors = ["input", "select", "textarea", "a[href]", "button", "[tabindex]:not(slot)", "audio[controls]", "video[controls]", '[contenteditable]:not([contenteditable="false"])', "details>summary:first-of-type", "details"];
var candidateSelector = candidateSelectors.join(",");
var NoElement = typeof Element === "undefined";
var matches = NoElement ? function() {
} : Element.prototype.matches || Element.prototype.msMatchesSelector || Element.prototype.webkitMatchesSelector;
var getRootNode = !NoElement && Element.prototype.getRootNode ? function(element) {
  return element.getRootNode();
} : function(element) {
  return element.ownerDocument;
};
var getCandidates = function getCandidates2(el, includeContainer, filter) {
  var candidates = Array.prototype.slice.apply(el.querySelectorAll(candidateSelector));
  if (includeContainer && matches.call(el, candidateSelector)) {
    candidates.unshift(el);
  }
  candidates = candidates.filter(filter);
  return candidates;
};
var getCandidatesIteratively = function getCandidatesIteratively2(elements, includeContainer, options) {
  var candidates = [];
  var elementsToCheck = Array.from(elements);
  while (elementsToCheck.length) {
    var element = elementsToCheck.shift();
    if (element.tagName === "SLOT") {
      var assigned = element.assignedElements();
      var content = assigned.length ? assigned : element.children;
      var nestedCandidates = getCandidatesIteratively2(content, true, options);
      if (options.flatten) {
        candidates.push.apply(candidates, nestedCandidates);
      } else {
        candidates.push({
          scope: element,
          candidates: nestedCandidates
        });
      }
    } else {
      var validCandidate = matches.call(element, candidateSelector);
      if (validCandidate && options.filter(element) && (includeContainer || !elements.includes(element))) {
        candidates.push(element);
      }
      var shadowRoot = element.shadowRoot || // check for an undisclosed shadow
      typeof options.getShadowRoot === "function" && options.getShadowRoot(element);
      var validShadowRoot = !options.shadowRootFilter || options.shadowRootFilter(element);
      if (shadowRoot && validShadowRoot) {
        var _nestedCandidates = getCandidatesIteratively2(shadowRoot === true ? element.children : shadowRoot.children, true, options);
        if (options.flatten) {
          candidates.push.apply(candidates, _nestedCandidates);
        } else {
          candidates.push({
            scope: element,
            candidates: _nestedCandidates
          });
        }
      } else {
        elementsToCheck.unshift.apply(elementsToCheck, element.children);
      }
    }
  }
  return candidates;
};
var getTabindex = function getTabindex2(node, isScope) {
  if (node.tabIndex < 0) {
    if ((isScope || /^(AUDIO|VIDEO|DETAILS)$/.test(node.tagName) || node.isContentEditable) && isNaN(parseInt(node.getAttribute("tabindex"), 10))) {
      return 0;
    }
  }
  return node.tabIndex;
};
var sortOrderedTabbables = function sortOrderedTabbables2(a2, b) {
  return a2.tabIndex === b.tabIndex ? a2.documentOrder - b.documentOrder : a2.tabIndex - b.tabIndex;
};
var isInput = function isInput2(node) {
  return node.tagName === "INPUT";
};
var isHiddenInput = function isHiddenInput2(node) {
  return isInput(node) && node.type === "hidden";
};
var isDetailsWithSummary = function isDetailsWithSummary2(node) {
  var r2 = node.tagName === "DETAILS" && Array.prototype.slice.apply(node.children).some(function(child) {
    return child.tagName === "SUMMARY";
  });
  return r2;
};
var getCheckedRadio = function getCheckedRadio2(nodes, form) {
  for (var i2 = 0; i2 < nodes.length; i2++) {
    if (nodes[i2].checked && nodes[i2].form === form) {
      return nodes[i2];
    }
  }
};
var isTabbableRadio = function isTabbableRadio2(node) {
  if (!node.name) {
    return true;
  }
  var radioScope = node.form || getRootNode(node);
  var queryRadios = function queryRadios2(name) {
    return radioScope.querySelectorAll('input[type="radio"][name="' + name + '"]');
  };
  var radioSet;
  if (typeof window !== "undefined" && typeof window.CSS !== "undefined" && typeof window.CSS.escape === "function") {
    radioSet = queryRadios(window.CSS.escape(node.name));
  } else {
    try {
      radioSet = queryRadios(node.name);
    } catch (err) {
      console.error("Looks like you have a radio button with a name attribute containing invalid CSS selector characters and need the CSS.escape polyfill: %s", err.message);
      return false;
    }
  }
  var checked = getCheckedRadio(radioSet, node.form);
  return !checked || checked === node;
};
var isRadio = function isRadio2(node) {
  return isInput(node) && node.type === "radio";
};
var isNonTabbableRadio = function isNonTabbableRadio2(node) {
  return isRadio(node) && !isTabbableRadio(node);
};
var isZeroArea = function isZeroArea2(node) {
  var _node$getBoundingClie = node.getBoundingClientRect(), width = _node$getBoundingClie.width, height = _node$getBoundingClie.height;
  return width === 0 && height === 0;
};
var isHidden = function isHidden2(node, _ref) {
  var displayCheck = _ref.displayCheck, getShadowRoot = _ref.getShadowRoot;
  if (getComputedStyle(node).visibility === "hidden") {
    return true;
  }
  var isDirectSummary = matches.call(node, "details>summary:first-of-type");
  var nodeUnderDetails = isDirectSummary ? node.parentElement : node;
  if (matches.call(nodeUnderDetails, "details:not([open]) *")) {
    return true;
  }
  var nodeRootHost = getRootNode(node).host;
  var nodeIsAttached = (nodeRootHost === null || nodeRootHost === void 0 ? void 0 : nodeRootHost.ownerDocument.contains(nodeRootHost)) || node.ownerDocument.contains(node);
  if (!displayCheck || displayCheck === "full") {
    if (typeof getShadowRoot === "function") {
      var originalNode = node;
      while (node) {
        var parentElement = node.parentElement;
        var rootNode = getRootNode(node);
        if (parentElement && !parentElement.shadowRoot && getShadowRoot(parentElement) === true) {
          return isZeroArea(node);
        } else if (node.assignedSlot) {
          node = node.assignedSlot;
        } else if (!parentElement && rootNode !== node.ownerDocument) {
          node = rootNode.host;
        } else {
          node = parentElement;
        }
      }
      node = originalNode;
    }
    if (nodeIsAttached) {
      return !node.getClientRects().length;
    }
  } else if (displayCheck === "non-zero-area") {
    return isZeroArea(node);
  }
  return false;
};
var isDisabledFromFieldset = function isDisabledFromFieldset2(node) {
  if (/^(INPUT|BUTTON|SELECT|TEXTAREA)$/.test(node.tagName)) {
    var parentNode = node.parentElement;
    while (parentNode) {
      if (parentNode.tagName === "FIELDSET" && parentNode.disabled) {
        for (var i2 = 0; i2 < parentNode.children.length; i2++) {
          var child = parentNode.children.item(i2);
          if (child.tagName === "LEGEND") {
            return matches.call(parentNode, "fieldset[disabled] *") ? true : !child.contains(node);
          }
        }
        return true;
      }
      parentNode = parentNode.parentElement;
    }
  }
  return false;
};
var isNodeMatchingSelectorFocusable = function isNodeMatchingSelectorFocusable2(options, node) {
  if (node.disabled || isHiddenInput(node) || isHidden(node, options) || // For a details element with a summary, the summary element gets the focus
  isDetailsWithSummary(node) || isDisabledFromFieldset(node)) {
    return false;
  }
  return true;
};
var isNodeMatchingSelectorTabbable = function isNodeMatchingSelectorTabbable2(options, node) {
  if (isNonTabbableRadio(node) || getTabindex(node) < 0 || !isNodeMatchingSelectorFocusable(options, node)) {
    return false;
  }
  return true;
};
var isValidShadowRootTabbable = function isValidShadowRootTabbable2(shadowHostNode) {
  var tabIndex = parseInt(shadowHostNode.getAttribute("tabindex"), 10);
  if (isNaN(tabIndex) || tabIndex >= 0) {
    return true;
  }
  return false;
};
var sortByOrder = function sortByOrder2(candidates) {
  var regularTabbables = [];
  var orderedTabbables = [];
  candidates.forEach(function(item, i2) {
    var isScope = !!item.scope;
    var element = isScope ? item.scope : item;
    var candidateTabindex = getTabindex(element, isScope);
    var elements = isScope ? sortByOrder2(item.candidates) : element;
    if (candidateTabindex === 0) {
      isScope ? regularTabbables.push.apply(regularTabbables, elements) : regularTabbables.push(element);
    } else {
      orderedTabbables.push({
        documentOrder: i2,
        tabIndex: candidateTabindex,
        item,
        isScope,
        content: elements
      });
    }
  });
  return orderedTabbables.sort(sortOrderedTabbables).reduce(function(acc, sortable) {
    sortable.isScope ? acc.push.apply(acc, sortable.content) : acc.push(sortable.content);
    return acc;
  }, []).concat(regularTabbables);
};
var tabbable = function tabbable2(el, options) {
  options = options || {};
  var candidates;
  if (options.getShadowRoot) {
    candidates = getCandidatesIteratively([el], options.includeContainer, {
      filter: isNodeMatchingSelectorTabbable.bind(null, options),
      flatten: false,
      getShadowRoot: options.getShadowRoot,
      shadowRootFilter: isValidShadowRootTabbable
    });
  } else {
    candidates = getCandidates(el, options.includeContainer, isNodeMatchingSelectorTabbable.bind(null, options));
  }
  return sortByOrder(candidates);
};
var focusable = function focusable2(el, options) {
  options = options || {};
  var candidates;
  if (options.getShadowRoot) {
    candidates = getCandidatesIteratively([el], options.includeContainer, {
      filter: isNodeMatchingSelectorFocusable.bind(null, options),
      flatten: true,
      getShadowRoot: options.getShadowRoot
    });
  } else {
    candidates = getCandidates(el, options.includeContainer, isNodeMatchingSelectorFocusable.bind(null, options));
  }
  return candidates;
};
var isTabbable = function isTabbable2(node, options) {
  options = options || {};
  if (!node) {
    throw new Error("No node provided");
  }
  if (matches.call(node, candidateSelector) === false) {
    return false;
  }
  return isNodeMatchingSelectorTabbable(options, node);
};
var focusableCandidateSelector = candidateSelectors.concat("iframe").join(",");
var isFocusable = function isFocusable2(node, options) {
  options = options || {};
  if (!node) {
    throw new Error("No node provided");
  }
  if (matches.call(node, focusableCandidateSelector) === false) {
    return false;
  }
  return isNodeMatchingSelectorFocusable(options, node);
};

// node_modules/focus-trap/dist/focus-trap.esm.js
function ownKeys(object, enumerableOnly) {
  var keys = Object.keys(object);
  if (Object.getOwnPropertySymbols) {
    var symbols = Object.getOwnPropertySymbols(object);
    enumerableOnly && (symbols = symbols.filter(function(sym) {
      return Object.getOwnPropertyDescriptor(object, sym).enumerable;
    })), keys.push.apply(keys, symbols);
  }
  return keys;
}
function _objectSpread2(target) {
  for (var i2 = 1; i2 < arguments.length; i2++) {
    var source = null != arguments[i2] ? arguments[i2] : {};
    i2 % 2 ? ownKeys(Object(source), true).forEach(function(key) {
      _defineProperty(target, key, source[key]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)) : ownKeys(Object(source)).forEach(function(key) {
      Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key));
    });
  }
  return target;
}
function _defineProperty(obj, key, value) {
  if (key in obj) {
    Object.defineProperty(obj, key, {
      value,
      enumerable: true,
      configurable: true,
      writable: true
    });
  } else {
    obj[key] = value;
  }
  return obj;
}
var activeFocusTraps = /* @__PURE__ */ function() {
  var trapQueue = [];
  return {
    activateTrap: function activateTrap(trap) {
      if (trapQueue.length > 0) {
        var activeTrap = trapQueue[trapQueue.length - 1];
        if (activeTrap !== trap) {
          activeTrap.pause();
        }
      }
      var trapIndex = trapQueue.indexOf(trap);
      if (trapIndex === -1) {
        trapQueue.push(trap);
      } else {
        trapQueue.splice(trapIndex, 1);
        trapQueue.push(trap);
      }
    },
    deactivateTrap: function deactivateTrap(trap) {
      var trapIndex = trapQueue.indexOf(trap);
      if (trapIndex !== -1) {
        trapQueue.splice(trapIndex, 1);
      }
      if (trapQueue.length > 0) {
        trapQueue[trapQueue.length - 1].unpause();
      }
    }
  };
}();
var isSelectableInput = function isSelectableInput2(node) {
  return node.tagName && node.tagName.toLowerCase() === "input" && typeof node.select === "function";
};
var isEscapeEvent = function isEscapeEvent2(e) {
  return e.key === "Escape" || e.key === "Esc" || e.keyCode === 27;
};
var isTabEvent = function isTabEvent2(e) {
  return e.key === "Tab" || e.keyCode === 9;
};
var delay2 = function delay3(fn) {
  return setTimeout(fn, 0);
};
var findIndex = function findIndex2(arr, fn) {
  var idx = -1;
  arr.every(function(value, i2) {
    if (fn(value)) {
      idx = i2;
      return false;
    }
    return true;
  });
  return idx;
};
var valueOrHandler = function valueOrHandler2(value) {
  for (var _len = arguments.length, params = new Array(_len > 1 ? _len - 1 : 0), _key = 1; _key < _len; _key++) {
    params[_key - 1] = arguments[_key];
  }
  return typeof value === "function" ? value.apply(void 0, params) : value;
};
var getActualTarget = function getActualTarget2(event2) {
  return event2.target.shadowRoot && typeof event2.composedPath === "function" ? event2.composedPath()[0] : event2.target;
};
var createFocusTrap = function createFocusTrap2(elements, userOptions) {
  var doc = (userOptions === null || userOptions === void 0 ? void 0 : userOptions.document) || document;
  var config2 = _objectSpread2({
    returnFocusOnDeactivate: true,
    escapeDeactivates: true,
    delayInitialFocus: true
  }, userOptions);
  var state = {
    // containers given to createFocusTrap()
    // @type {Array<HTMLElement>}
    containers: [],
    // list of objects identifying tabbable nodes in `containers` in the trap
    // NOTE: it's possible that a group has no tabbable nodes if nodes get removed while the trap
    //  is active, but the trap should never get to a state where there isn't at least one group
    //  with at least one tabbable node in it (that would lead to an error condition that would
    //  result in an error being thrown)
    // @type {Array<{
    //   container: HTMLElement,
    //   tabbableNodes: Array<HTMLElement>, // empty if none
    //   focusableNodes: Array<HTMLElement>, // empty if none
    //   firstTabbableNode: HTMLElement|null,
    //   lastTabbableNode: HTMLElement|null,
    //   nextTabbableNode: (node: HTMLElement, forward: boolean) => HTMLElement|undefined
    // }>}
    containerGroups: [],
    // same order/length as `containers` list
    // references to objects in `containerGroups`, but only those that actually have
    //  tabbable nodes in them
    // NOTE: same order as `containers` and `containerGroups`, but __not necessarily__
    //  the same length
    tabbableGroups: [],
    nodeFocusedBeforeActivation: null,
    mostRecentlyFocusedNode: null,
    active: false,
    paused: false,
    // timer ID for when delayInitialFocus is true and initial focus in this trap
    //  has been delayed during activation
    delayInitialFocusTimer: void 0
  };
  var trap;
  var getOption = function getOption2(configOverrideOptions, optionName, configOptionName) {
    return configOverrideOptions && configOverrideOptions[optionName] !== void 0 ? configOverrideOptions[optionName] : config2[configOptionName || optionName];
  };
  var findContainerIndex = function findContainerIndex2(element) {
    return state.containerGroups.findIndex(function(_ref) {
      var container = _ref.container, tabbableNodes = _ref.tabbableNodes;
      return container.contains(element) || // fall back to explicit tabbable search which will take into consideration any
      //  web components if the `tabbableOptions.getShadowRoot` option was used for
      //  the trap, enabling shadow DOM support in tabbable (`Node.contains()` doesn't
      //  look inside web components even if open)
      tabbableNodes.find(function(node) {
        return node === element;
      });
    });
  };
  var getNodeForOption = function getNodeForOption2(optionName) {
    var optionValue = config2[optionName];
    if (typeof optionValue === "function") {
      for (var _len2 = arguments.length, params = new Array(_len2 > 1 ? _len2 - 1 : 0), _key2 = 1; _key2 < _len2; _key2++) {
        params[_key2 - 1] = arguments[_key2];
      }
      optionValue = optionValue.apply(void 0, params);
    }
    if (optionValue === true) {
      optionValue = void 0;
    }
    if (!optionValue) {
      if (optionValue === void 0 || optionValue === false) {
        return optionValue;
      }
      throw new Error("`".concat(optionName, "` was specified but was not a node, or did not return a node"));
    }
    var node = optionValue;
    if (typeof optionValue === "string") {
      node = doc.querySelector(optionValue);
      if (!node) {
        throw new Error("`".concat(optionName, "` as selector refers to no known node"));
      }
    }
    return node;
  };
  var getInitialFocusNode = function getInitialFocusNode2() {
    var node = getNodeForOption("initialFocus");
    if (node === false) {
      return false;
    }
    if (node === void 0) {
      if (findContainerIndex(doc.activeElement) >= 0) {
        node = doc.activeElement;
      } else {
        var firstTabbableGroup = state.tabbableGroups[0];
        var firstTabbableNode = firstTabbableGroup && firstTabbableGroup.firstTabbableNode;
        node = firstTabbableNode || getNodeForOption("fallbackFocus");
      }
    }
    if (!node) {
      throw new Error("Your focus-trap needs to have at least one focusable element");
    }
    return node;
  };
  var updateTabbableNodes = function updateTabbableNodes2() {
    state.containerGroups = state.containers.map(function(container) {
      var tabbableNodes = tabbable(container, config2.tabbableOptions);
      var focusableNodes = focusable(container, config2.tabbableOptions);
      return {
        container,
        tabbableNodes,
        focusableNodes,
        firstTabbableNode: tabbableNodes.length > 0 ? tabbableNodes[0] : null,
        lastTabbableNode: tabbableNodes.length > 0 ? tabbableNodes[tabbableNodes.length - 1] : null,
        /**
         * Finds the __tabbable__ node that follows the given node in the specified direction,
         *  in this container, if any.
         * @param {HTMLElement} node
         * @param {boolean} [forward] True if going in forward tab order; false if going
         *  in reverse.
         * @returns {HTMLElement|undefined} The next tabbable node, if any.
         */
        nextTabbableNode: function nextTabbableNode(node) {
          var forward = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : true;
          var nodeIdx = focusableNodes.findIndex(function(n2) {
            return n2 === node;
          });
          if (nodeIdx < 0) {
            return void 0;
          }
          if (forward) {
            return focusableNodes.slice(nodeIdx + 1).find(function(n2) {
              return isTabbable(n2, config2.tabbableOptions);
            });
          }
          return focusableNodes.slice(0, nodeIdx).reverse().find(function(n2) {
            return isTabbable(n2, config2.tabbableOptions);
          });
        }
      };
    });
    state.tabbableGroups = state.containerGroups.filter(function(group) {
      return group.tabbableNodes.length > 0;
    });
    if (state.tabbableGroups.length <= 0 && !getNodeForOption("fallbackFocus")) {
      throw new Error("Your focus-trap must have at least one container with at least one tabbable node in it at all times");
    }
  };
  var tryFocus = function tryFocus2(node) {
    if (node === false) {
      return;
    }
    if (node === doc.activeElement) {
      return;
    }
    if (!node || !node.focus) {
      tryFocus2(getInitialFocusNode());
      return;
    }
    node.focus({
      preventScroll: !!config2.preventScroll
    });
    state.mostRecentlyFocusedNode = node;
    if (isSelectableInput(node)) {
      node.select();
    }
  };
  var getReturnFocusNode = function getReturnFocusNode2(previousActiveElement) {
    var node = getNodeForOption("setReturnFocus", previousActiveElement);
    return node ? node : node === false ? false : previousActiveElement;
  };
  var checkPointerDown = function checkPointerDown2(e) {
    var target = getActualTarget(e);
    if (findContainerIndex(target) >= 0) {
      return;
    }
    if (valueOrHandler(config2.clickOutsideDeactivates, e)) {
      trap.deactivate({
        // if, on deactivation, we should return focus to the node originally-focused
        //  when the trap was activated (or the configured `setReturnFocus` node),
        //  then assume it's also OK to return focus to the outside node that was
        //  just clicked, causing deactivation, as long as that node is focusable;
        //  if it isn't focusable, then return focus to the original node focused
        //  on activation (or the configured `setReturnFocus` node)
        // NOTE: by setting `returnFocus: false`, deactivate() will do nothing,
        //  which will result in the outside click setting focus to the node
        //  that was clicked, whether it's focusable or not; by setting
        //  `returnFocus: true`, we'll attempt to re-focus the node originally-focused
        //  on activation (or the configured `setReturnFocus` node)
        returnFocus: config2.returnFocusOnDeactivate && !isFocusable(target, config2.tabbableOptions)
      });
      return;
    }
    if (valueOrHandler(config2.allowOutsideClick, e)) {
      return;
    }
    e.preventDefault();
  };
  var checkFocusIn = function checkFocusIn2(e) {
    var target = getActualTarget(e);
    var targetContained = findContainerIndex(target) >= 0;
    if (targetContained || target instanceof Document) {
      if (targetContained) {
        state.mostRecentlyFocusedNode = target;
      }
    } else {
      e.stopImmediatePropagation();
      tryFocus(state.mostRecentlyFocusedNode || getInitialFocusNode());
    }
  };
  var checkTab = function checkTab2(e) {
    var target = getActualTarget(e);
    updateTabbableNodes();
    var destinationNode = null;
    if (state.tabbableGroups.length > 0) {
      var containerIndex = findContainerIndex(target);
      var containerGroup = containerIndex >= 0 ? state.containerGroups[containerIndex] : void 0;
      if (containerIndex < 0) {
        if (e.shiftKey) {
          destinationNode = state.tabbableGroups[state.tabbableGroups.length - 1].lastTabbableNode;
        } else {
          destinationNode = state.tabbableGroups[0].firstTabbableNode;
        }
      } else if (e.shiftKey) {
        var startOfGroupIndex = findIndex(state.tabbableGroups, function(_ref2) {
          var firstTabbableNode = _ref2.firstTabbableNode;
          return target === firstTabbableNode;
        });
        if (startOfGroupIndex < 0 && (containerGroup.container === target || isFocusable(target, config2.tabbableOptions) && !isTabbable(target, config2.tabbableOptions) && !containerGroup.nextTabbableNode(target, false))) {
          startOfGroupIndex = containerIndex;
        }
        if (startOfGroupIndex >= 0) {
          var destinationGroupIndex = startOfGroupIndex === 0 ? state.tabbableGroups.length - 1 : startOfGroupIndex - 1;
          var destinationGroup = state.tabbableGroups[destinationGroupIndex];
          destinationNode = destinationGroup.lastTabbableNode;
        }
      } else {
        var lastOfGroupIndex = findIndex(state.tabbableGroups, function(_ref3) {
          var lastTabbableNode = _ref3.lastTabbableNode;
          return target === lastTabbableNode;
        });
        if (lastOfGroupIndex < 0 && (containerGroup.container === target || isFocusable(target, config2.tabbableOptions) && !isTabbable(target, config2.tabbableOptions) && !containerGroup.nextTabbableNode(target))) {
          lastOfGroupIndex = containerIndex;
        }
        if (lastOfGroupIndex >= 0) {
          var _destinationGroupIndex = lastOfGroupIndex === state.tabbableGroups.length - 1 ? 0 : lastOfGroupIndex + 1;
          var _destinationGroup = state.tabbableGroups[_destinationGroupIndex];
          destinationNode = _destinationGroup.firstTabbableNode;
        }
      }
    } else {
      destinationNode = getNodeForOption("fallbackFocus");
    }
    if (destinationNode) {
      e.preventDefault();
      tryFocus(destinationNode);
    }
  };
  var checkKey = function checkKey2(e) {
    if (isEscapeEvent(e) && valueOrHandler(config2.escapeDeactivates, e) !== false) {
      e.preventDefault();
      trap.deactivate();
      return;
    }
    if (isTabEvent(e)) {
      checkTab(e);
      return;
    }
  };
  var checkClick = function checkClick2(e) {
    var target = getActualTarget(e);
    if (findContainerIndex(target) >= 0) {
      return;
    }
    if (valueOrHandler(config2.clickOutsideDeactivates, e)) {
      return;
    }
    if (valueOrHandler(config2.allowOutsideClick, e)) {
      return;
    }
    e.preventDefault();
    e.stopImmediatePropagation();
  };
  var addListeners2 = function addListeners3() {
    if (!state.active) {
      return;
    }
    activeFocusTraps.activateTrap(trap);
    state.delayInitialFocusTimer = config2.delayInitialFocus ? delay2(function() {
      tryFocus(getInitialFocusNode());
    }) : tryFocus(getInitialFocusNode());
    doc.addEventListener("focusin", checkFocusIn, true);
    doc.addEventListener("mousedown", checkPointerDown, {
      capture: true,
      passive: false
    });
    doc.addEventListener("touchstart", checkPointerDown, {
      capture: true,
      passive: false
    });
    doc.addEventListener("click", checkClick, {
      capture: true,
      passive: false
    });
    doc.addEventListener("keydown", checkKey, {
      capture: true,
      passive: false
    });
    return trap;
  };
  var removeListeners2 = function removeListeners3() {
    if (!state.active) {
      return;
    }
    doc.removeEventListener("focusin", checkFocusIn, true);
    doc.removeEventListener("mousedown", checkPointerDown, true);
    doc.removeEventListener("touchstart", checkPointerDown, true);
    doc.removeEventListener("click", checkClick, true);
    doc.removeEventListener("keydown", checkKey, true);
    return trap;
  };
  trap = {
    get active() {
      return state.active;
    },
    get paused() {
      return state.paused;
    },
    activate: function activate(activateOptions) {
      if (state.active) {
        return this;
      }
      var onActivate = getOption(activateOptions, "onActivate");
      var onPostActivate = getOption(activateOptions, "onPostActivate");
      var checkCanFocusTrap = getOption(activateOptions, "checkCanFocusTrap");
      if (!checkCanFocusTrap) {
        updateTabbableNodes();
      }
      state.active = true;
      state.paused = false;
      state.nodeFocusedBeforeActivation = doc.activeElement;
      if (onActivate) {
        onActivate();
      }
      var finishActivation = function finishActivation2() {
        if (checkCanFocusTrap) {
          updateTabbableNodes();
        }
        addListeners2();
        if (onPostActivate) {
          onPostActivate();
        }
      };
      if (checkCanFocusTrap) {
        checkCanFocusTrap(state.containers.concat()).then(finishActivation, finishActivation);
        return this;
      }
      finishActivation();
      return this;
    },
    deactivate: function deactivate(deactivateOptions) {
      if (!state.active) {
        return this;
      }
      var options = _objectSpread2({
        onDeactivate: config2.onDeactivate,
        onPostDeactivate: config2.onPostDeactivate,
        checkCanReturnFocus: config2.checkCanReturnFocus
      }, deactivateOptions);
      clearTimeout(state.delayInitialFocusTimer);
      state.delayInitialFocusTimer = void 0;
      removeListeners2();
      state.active = false;
      state.paused = false;
      activeFocusTraps.deactivateTrap(trap);
      var onDeactivate = getOption(options, "onDeactivate");
      var onPostDeactivate = getOption(options, "onPostDeactivate");
      var checkCanReturnFocus = getOption(options, "checkCanReturnFocus");
      var returnFocus = getOption(options, "returnFocus", "returnFocusOnDeactivate");
      if (onDeactivate) {
        onDeactivate();
      }
      var finishDeactivation = function finishDeactivation2() {
        delay2(function() {
          if (returnFocus) {
            tryFocus(getReturnFocusNode(state.nodeFocusedBeforeActivation));
          }
          if (onPostDeactivate) {
            onPostDeactivate();
          }
        });
      };
      if (returnFocus && checkCanReturnFocus) {
        checkCanReturnFocus(getReturnFocusNode(state.nodeFocusedBeforeActivation)).then(finishDeactivation, finishDeactivation);
        return this;
      }
      finishDeactivation();
      return this;
    },
    pause: function pause() {
      if (state.paused || !state.active) {
        return this;
      }
      state.paused = true;
      removeListeners2();
      return this;
    },
    unpause: function unpause() {
      if (!state.paused || !state.active) {
        return this;
      }
      state.paused = false;
      updateTabbableNodes();
      addListeners2();
      return this;
    },
    updateContainerElements: function updateContainerElements(containerElements) {
      var elementsAsArray = [].concat(containerElements).filter(Boolean);
      state.containers = elementsAsArray.map(function(element) {
        return typeof element === "string" ? doc.querySelector(element) : element;
      });
      if (state.active) {
        updateTabbableNodes();
      }
      return this;
    }
  };
  trap.updateContainerElements(elements);
  return trap;
};

// node_modules/body-scroll-lock/lib/bodyScrollLock.esm.js
function _toConsumableArray(arr) {
  if (Array.isArray(arr)) {
    for (var i2 = 0, arr2 = Array(arr.length); i2 < arr.length; i2++) {
      arr2[i2] = arr[i2];
    }
    return arr2;
  } else {
    return Array.from(arr);
  }
}
var hasPassiveEvents = false;
if (typeof window !== "undefined") {
  passiveTestOptions = {
    get passive() {
      hasPassiveEvents = true;
      return void 0;
    }
  };
  window.addEventListener("testPassive", null, passiveTestOptions);
  window.removeEventListener("testPassive", null, passiveTestOptions);
}
var passiveTestOptions;
var isIosDevice = typeof window !== "undefined" && window.navigator && window.navigator.platform && (/iP(ad|hone|od)/.test(window.navigator.platform) || window.navigator.platform === "MacIntel" && window.navigator.maxTouchPoints > 1);
var locks = [];
var documentListenerAdded = false;
var initialClientY = -1;
var previousBodyOverflowSetting = void 0;
var previousBodyPaddingRight = void 0;
var allowTouchMove = function allowTouchMove2(el) {
  return locks.some(function(lock) {
    if (lock.options.allowTouchMove && lock.options.allowTouchMove(el)) {
      return true;
    }
    return false;
  });
};
var preventDefault = function preventDefault2(rawEvent) {
  var e = rawEvent || window.event;
  if (allowTouchMove(e.target)) {
    return true;
  }
  if (e.touches.length > 1) return true;
  if (e.preventDefault) e.preventDefault();
  return false;
};
var setOverflowHidden = function setOverflowHidden2(options) {
  if (previousBodyPaddingRight === void 0) {
    var _reserveScrollBarGap = !!options && options.reserveScrollBarGap === true;
    var scrollBarGap = window.innerWidth - document.documentElement.clientWidth;
    if (_reserveScrollBarGap && scrollBarGap > 0) {
      previousBodyPaddingRight = document.body.style.paddingRight;
      document.body.style.paddingRight = scrollBarGap + "px";
    }
  }
  if (previousBodyOverflowSetting === void 0) {
    previousBodyOverflowSetting = document.body.style.overflow;
    document.body.style.overflow = "hidden";
  }
};
var restoreOverflowSetting = function restoreOverflowSetting2() {
  if (previousBodyPaddingRight !== void 0) {
    document.body.style.paddingRight = previousBodyPaddingRight;
    previousBodyPaddingRight = void 0;
  }
  if (previousBodyOverflowSetting !== void 0) {
    document.body.style.overflow = previousBodyOverflowSetting;
    previousBodyOverflowSetting = void 0;
  }
};
var isTargetElementTotallyScrolled = function isTargetElementTotallyScrolled2(targetElement) {
  return targetElement ? targetElement.scrollHeight - targetElement.scrollTop <= targetElement.clientHeight : false;
};
var handleScroll = function handleScroll2(event2, targetElement) {
  var clientY = event2.targetTouches[0].clientY - initialClientY;
  if (allowTouchMove(event2.target)) {
    return false;
  }
  if (targetElement && targetElement.scrollTop === 0 && clientY > 0) {
    return preventDefault(event2);
  }
  if (isTargetElementTotallyScrolled(targetElement) && clientY < 0) {
    return preventDefault(event2);
  }
  event2.stopPropagation();
  return true;
};
var disableBodyScroll = function disableBodyScroll2(targetElement, options) {
  if (!targetElement) {
    console.error("disableBodyScroll unsuccessful - targetElement must be provided when calling disableBodyScroll on IOS devices.");
    return;
  }
  if (locks.some(function(lock2) {
    return lock2.targetElement === targetElement;
  })) {
    return;
  }
  var lock = {
    targetElement,
    options: options || {}
  };
  locks = [].concat(_toConsumableArray(locks), [lock]);
  if (isIosDevice) {
    targetElement.ontouchstart = function(event2) {
      if (event2.targetTouches.length === 1) {
        initialClientY = event2.targetTouches[0].clientY;
      }
    };
    targetElement.ontouchmove = function(event2) {
      if (event2.targetTouches.length === 1) {
        handleScroll(event2, targetElement);
      }
    };
    if (!documentListenerAdded) {
      document.addEventListener("touchmove", preventDefault, hasPassiveEvents ? { passive: false } : void 0);
      documentListenerAdded = true;
    }
  } else {
    setOverflowHidden(options);
  }
};
var enableBodyScroll = function enableBodyScroll2(targetElement) {
  if (!targetElement) {
    console.error("enableBodyScroll unsuccessful - targetElement must be provided when calling enableBodyScroll on IOS devices.");
    return;
  }
  locks = locks.filter(function(lock) {
    return lock.targetElement !== targetElement;
  });
  if (isIosDevice) {
    targetElement.ontouchstart = null;
    targetElement.ontouchmove = null;
    if (documentListenerAdded && locks.length === 0) {
      document.removeEventListener("touchmove", preventDefault, hasPassiveEvents ? { passive: false } : void 0);
      documentListenerAdded = false;
    }
  } else if (!locks.length) {
    restoreOverflowSetting();
  }
};

// node_modules/@juggle/resize-observer/lib/utils/resizeObservers.js
var resizeObservers = [];

// node_modules/@juggle/resize-observer/lib/algorithms/hasActiveObservations.js
var hasActiveObservations = function() {
  return resizeObservers.some(function(ro) {
    return ro.activeTargets.length > 0;
  });
};

// node_modules/@juggle/resize-observer/lib/algorithms/hasSkippedObservations.js
var hasSkippedObservations = function() {
  return resizeObservers.some(function(ro) {
    return ro.skippedTargets.length > 0;
  });
};

// node_modules/@juggle/resize-observer/lib/algorithms/deliverResizeLoopError.js
var msg = "ResizeObserver loop completed with undelivered notifications.";
var deliverResizeLoopError = function() {
  var event2;
  if (typeof ErrorEvent === "function") {
    event2 = new ErrorEvent("error", {
      message: msg
    });
  } else {
    event2 = document.createEvent("Event");
    event2.initEvent("error", false, false);
    event2.message = msg;
  }
  window.dispatchEvent(event2);
};

// node_modules/@juggle/resize-observer/lib/ResizeObserverBoxOptions.js
var ResizeObserverBoxOptions;
(function(ResizeObserverBoxOptions2) {
  ResizeObserverBoxOptions2["BORDER_BOX"] = "border-box";
  ResizeObserverBoxOptions2["CONTENT_BOX"] = "content-box";
  ResizeObserverBoxOptions2["DEVICE_PIXEL_CONTENT_BOX"] = "device-pixel-content-box";
})(ResizeObserverBoxOptions || (ResizeObserverBoxOptions = {}));

// node_modules/@juggle/resize-observer/lib/utils/freeze.js
var freeze = function(obj) {
  return Object.freeze(obj);
};

// node_modules/@juggle/resize-observer/lib/ResizeObserverSize.js
var ResizeObserverSize = /* @__PURE__ */ function() {
  function ResizeObserverSize2(inlineSize, blockSize) {
    this.inlineSize = inlineSize;
    this.blockSize = blockSize;
    freeze(this);
  }
  return ResizeObserverSize2;
}();

// node_modules/@juggle/resize-observer/lib/DOMRectReadOnly.js
var DOMRectReadOnly = function() {
  function DOMRectReadOnly2(x2, y, width, height) {
    this.x = x2;
    this.y = y;
    this.width = width;
    this.height = height;
    this.top = this.y;
    this.left = this.x;
    this.bottom = this.top + this.height;
    this.right = this.left + this.width;
    return freeze(this);
  }
  DOMRectReadOnly2.prototype.toJSON = function() {
    var _a2 = this, x2 = _a2.x, y = _a2.y, top = _a2.top, right = _a2.right, bottom = _a2.bottom, left = _a2.left, width = _a2.width, height = _a2.height;
    return { x: x2, y, top, right, bottom, left, width, height };
  };
  DOMRectReadOnly2.fromRect = function(rectangle) {
    return new DOMRectReadOnly2(rectangle.x, rectangle.y, rectangle.width, rectangle.height);
  };
  return DOMRectReadOnly2;
}();

// node_modules/@juggle/resize-observer/lib/utils/element.js
var isSVG = function(target) {
  return target instanceof SVGElement && "getBBox" in target;
};
var isHidden3 = function(target) {
  if (isSVG(target)) {
    var _a2 = target.getBBox(), width = _a2.width, height = _a2.height;
    return !width && !height;
  }
  var _b = target, offsetWidth = _b.offsetWidth, offsetHeight = _b.offsetHeight;
  return !(offsetWidth || offsetHeight || target.getClientRects().length);
};
var isElement = function(obj) {
  var _a2;
  if (obj instanceof Element) {
    return true;
  }
  var scope = (_a2 = obj === null || obj === void 0 ? void 0 : obj.ownerDocument) === null || _a2 === void 0 ? void 0 : _a2.defaultView;
  return !!(scope && obj instanceof scope.Element);
};
var isReplacedElement = function(target) {
  switch (target.tagName) {
    case "INPUT":
      if (target.type !== "image") {
        break;
      }
    case "VIDEO":
    case "AUDIO":
    case "EMBED":
    case "OBJECT":
    case "CANVAS":
    case "IFRAME":
    case "IMG":
      return true;
  }
  return false;
};

// node_modules/@juggle/resize-observer/lib/utils/global.js
var global2 = typeof window !== "undefined" ? window : {};

// node_modules/@juggle/resize-observer/lib/algorithms/calculateBoxSize.js
var cache = /* @__PURE__ */ new WeakMap();
var scrollRegexp = /auto|scroll/;
var verticalRegexp = /^tb|vertical/;
var IE = /msie|trident/i.test(global2.navigator && global2.navigator.userAgent);
var parseDimension = function(pixel) {
  return parseFloat(pixel || "0");
};
var size = function(inlineSize, blockSize, switchSizes) {
  if (inlineSize === void 0) {
    inlineSize = 0;
  }
  if (blockSize === void 0) {
    blockSize = 0;
  }
  if (switchSizes === void 0) {
    switchSizes = false;
  }
  return new ResizeObserverSize((switchSizes ? blockSize : inlineSize) || 0, (switchSizes ? inlineSize : blockSize) || 0);
};
var zeroBoxes = freeze({
  devicePixelContentBoxSize: size(),
  borderBoxSize: size(),
  contentBoxSize: size(),
  contentRect: new DOMRectReadOnly(0, 0, 0, 0)
});
var calculateBoxSizes = function(target, forceRecalculation) {
  if (forceRecalculation === void 0) {
    forceRecalculation = false;
  }
  if (cache.has(target) && !forceRecalculation) {
    return cache.get(target);
  }
  if (isHidden3(target)) {
    cache.set(target, zeroBoxes);
    return zeroBoxes;
  }
  var cs = getComputedStyle(target);
  var svg = isSVG(target) && target.ownerSVGElement && target.getBBox();
  var removePadding = !IE && cs.boxSizing === "border-box";
  var switchSizes = verticalRegexp.test(cs.writingMode || "");
  var canScrollVertically = !svg && scrollRegexp.test(cs.overflowY || "");
  var canScrollHorizontally = !svg && scrollRegexp.test(cs.overflowX || "");
  var paddingTop = svg ? 0 : parseDimension(cs.paddingTop);
  var paddingRight = svg ? 0 : parseDimension(cs.paddingRight);
  var paddingBottom = svg ? 0 : parseDimension(cs.paddingBottom);
  var paddingLeft = svg ? 0 : parseDimension(cs.paddingLeft);
  var borderTop = svg ? 0 : parseDimension(cs.borderTopWidth);
  var borderRight = svg ? 0 : parseDimension(cs.borderRightWidth);
  var borderBottom = svg ? 0 : parseDimension(cs.borderBottomWidth);
  var borderLeft = svg ? 0 : parseDimension(cs.borderLeftWidth);
  var horizontalPadding = paddingLeft + paddingRight;
  var verticalPadding = paddingTop + paddingBottom;
  var horizontalBorderArea = borderLeft + borderRight;
  var verticalBorderArea = borderTop + borderBottom;
  var horizontalScrollbarThickness = !canScrollHorizontally ? 0 : target.offsetHeight - verticalBorderArea - target.clientHeight;
  var verticalScrollbarThickness = !canScrollVertically ? 0 : target.offsetWidth - horizontalBorderArea - target.clientWidth;
  var widthReduction = removePadding ? horizontalPadding + horizontalBorderArea : 0;
  var heightReduction = removePadding ? verticalPadding + verticalBorderArea : 0;
  var contentWidth = svg ? svg.width : parseDimension(cs.width) - widthReduction - verticalScrollbarThickness;
  var contentHeight = svg ? svg.height : parseDimension(cs.height) - heightReduction - horizontalScrollbarThickness;
  var borderBoxWidth = contentWidth + horizontalPadding + verticalScrollbarThickness + horizontalBorderArea;
  var borderBoxHeight = contentHeight + verticalPadding + horizontalScrollbarThickness + verticalBorderArea;
  var boxes = freeze({
    devicePixelContentBoxSize: size(Math.round(contentWidth * devicePixelRatio), Math.round(contentHeight * devicePixelRatio), switchSizes),
    borderBoxSize: size(borderBoxWidth, borderBoxHeight, switchSizes),
    contentBoxSize: size(contentWidth, contentHeight, switchSizes),
    contentRect: new DOMRectReadOnly(paddingLeft, paddingTop, contentWidth, contentHeight)
  });
  cache.set(target, boxes);
  return boxes;
};
var calculateBoxSize = function(target, observedBox, forceRecalculation) {
  var _a2 = calculateBoxSizes(target, forceRecalculation), borderBoxSize = _a2.borderBoxSize, contentBoxSize = _a2.contentBoxSize, devicePixelContentBoxSize = _a2.devicePixelContentBoxSize;
  switch (observedBox) {
    case ResizeObserverBoxOptions.DEVICE_PIXEL_CONTENT_BOX:
      return devicePixelContentBoxSize;
    case ResizeObserverBoxOptions.BORDER_BOX:
      return borderBoxSize;
    default:
      return contentBoxSize;
  }
};

// node_modules/@juggle/resize-observer/lib/ResizeObserverEntry.js
var ResizeObserverEntry = /* @__PURE__ */ function() {
  function ResizeObserverEntry2(target) {
    var boxes = calculateBoxSizes(target);
    this.target = target;
    this.contentRect = boxes.contentRect;
    this.borderBoxSize = freeze([boxes.borderBoxSize]);
    this.contentBoxSize = freeze([boxes.contentBoxSize]);
    this.devicePixelContentBoxSize = freeze([boxes.devicePixelContentBoxSize]);
  }
  return ResizeObserverEntry2;
}();

// node_modules/@juggle/resize-observer/lib/algorithms/calculateDepthForNode.js
var calculateDepthForNode = function(node) {
  if (isHidden3(node)) {
    return Infinity;
  }
  var depth = 0;
  var parent = node.parentNode;
  while (parent) {
    depth += 1;
    parent = parent.parentNode;
  }
  return depth;
};

// node_modules/@juggle/resize-observer/lib/algorithms/broadcastActiveObservations.js
var broadcastActiveObservations = function() {
  var shallowestDepth = Infinity;
  var callbacks2 = [];
  resizeObservers.forEach(function processObserver(ro) {
    if (ro.activeTargets.length === 0) {
      return;
    }
    var entries = [];
    ro.activeTargets.forEach(function processTarget(ot) {
      var entry = new ResizeObserverEntry(ot.target);
      var targetDepth = calculateDepthForNode(ot.target);
      entries.push(entry);
      ot.lastReportedSize = calculateBoxSize(ot.target, ot.observedBox);
      if (targetDepth < shallowestDepth) {
        shallowestDepth = targetDepth;
      }
    });
    callbacks2.push(function resizeObserverCallback() {
      ro.callback.call(ro.observer, entries, ro.observer);
    });
    ro.activeTargets.splice(0, ro.activeTargets.length);
  });
  for (var _i = 0, callbacks_1 = callbacks2; _i < callbacks_1.length; _i++) {
    var callback = callbacks_1[_i];
    callback();
  }
  return shallowestDepth;
};

// node_modules/@juggle/resize-observer/lib/algorithms/gatherActiveObservationsAtDepth.js
var gatherActiveObservationsAtDepth = function(depth) {
  resizeObservers.forEach(function processObserver(ro) {
    ro.activeTargets.splice(0, ro.activeTargets.length);
    ro.skippedTargets.splice(0, ro.skippedTargets.length);
    ro.observationTargets.forEach(function processTarget(ot) {
      if (ot.isActive()) {
        if (calculateDepthForNode(ot.target) > depth) {
          ro.activeTargets.push(ot);
        } else {
          ro.skippedTargets.push(ot);
        }
      }
    });
  });
};

// node_modules/@juggle/resize-observer/lib/utils/process.js
var process2 = function() {
  var depth = 0;
  gatherActiveObservationsAtDepth(depth);
  while (hasActiveObservations()) {
    depth = broadcastActiveObservations();
    gatherActiveObservationsAtDepth(depth);
  }
  if (hasSkippedObservations()) {
    deliverResizeLoopError();
  }
  return depth > 0;
};

// node_modules/@juggle/resize-observer/lib/utils/queueMicroTask.js
var trigger;
var callbacks = [];
var notify = function() {
  return callbacks.splice(0).forEach(function(cb) {
    return cb();
  });
};
var queueMicroTask = function(callback) {
  if (!trigger) {
    var toggle_1 = 0;
    var el_1 = document.createTextNode("");
    var config2 = { characterData: true };
    new MutationObserver(function() {
      return notify();
    }).observe(el_1, config2);
    trigger = function() {
      el_1.textContent = "".concat(toggle_1 ? toggle_1-- : toggle_1++);
    };
  }
  callbacks.push(callback);
  trigger();
};

// node_modules/@juggle/resize-observer/lib/utils/queueResizeObserver.js
var queueResizeObserver = function(cb) {
  queueMicroTask(function ResizeObserver2() {
    requestAnimationFrame(cb);
  });
};

// node_modules/@juggle/resize-observer/lib/utils/scheduler.js
var watching = 0;
var isWatching = function() {
  return !!watching;
};
var CATCH_PERIOD = 250;
var observerConfig = { attributes: true, characterData: true, childList: true, subtree: true };
var events = [
  "resize",
  "load",
  "transitionend",
  "animationend",
  "animationstart",
  "animationiteration",
  "keyup",
  "keydown",
  "mouseup",
  "mousedown",
  "mouseover",
  "mouseout",
  "blur",
  "focus"
];
var time = function(timeout) {
  if (timeout === void 0) {
    timeout = 0;
  }
  return Date.now() + timeout;
};
var scheduled = false;
var Scheduler2 = function() {
  function Scheduler3() {
    var _this = this;
    this.stopped = true;
    this.listener = function() {
      return _this.schedule();
    };
  }
  Scheduler3.prototype.run = function(timeout) {
    var _this = this;
    if (timeout === void 0) {
      timeout = CATCH_PERIOD;
    }
    if (scheduled) {
      return;
    }
    scheduled = true;
    var until = time(timeout);
    queueResizeObserver(function() {
      var elementsHaveResized = false;
      try {
        elementsHaveResized = process2();
      } finally {
        scheduled = false;
        timeout = until - time();
        if (!isWatching()) {
          return;
        }
        if (elementsHaveResized) {
          _this.run(1e3);
        } else if (timeout > 0) {
          _this.run(timeout);
        } else {
          _this.start();
        }
      }
    });
  };
  Scheduler3.prototype.schedule = function() {
    this.stop();
    this.run();
  };
  Scheduler3.prototype.observe = function() {
    var _this = this;
    var cb = function() {
      return _this.observer && _this.observer.observe(document.body, observerConfig);
    };
    document.body ? cb() : global2.addEventListener("DOMContentLoaded", cb);
  };
  Scheduler3.prototype.start = function() {
    var _this = this;
    if (this.stopped) {
      this.stopped = false;
      this.observer = new MutationObserver(this.listener);
      this.observe();
      events.forEach(function(name) {
        return global2.addEventListener(name, _this.listener, true);
      });
    }
  };
  Scheduler3.prototype.stop = function() {
    var _this = this;
    if (!this.stopped) {
      this.observer && this.observer.disconnect();
      events.forEach(function(name) {
        return global2.removeEventListener(name, _this.listener, true);
      });
      this.stopped = true;
    }
  };
  return Scheduler3;
}();
var scheduler = new Scheduler2();
var updateCount = function(n2) {
  !watching && n2 > 0 && scheduler.start();
  watching += n2;
  !watching && scheduler.stop();
};

// node_modules/@juggle/resize-observer/lib/ResizeObservation.js
var skipNotifyOnElement = function(target) {
  return !isSVG(target) && !isReplacedElement(target) && getComputedStyle(target).display === "inline";
};
var ResizeObservation = function() {
  function ResizeObservation2(target, observedBox) {
    this.target = target;
    this.observedBox = observedBox || ResizeObserverBoxOptions.CONTENT_BOX;
    this.lastReportedSize = {
      inlineSize: 0,
      blockSize: 0
    };
  }
  ResizeObservation2.prototype.isActive = function() {
    var size2 = calculateBoxSize(this.target, this.observedBox, true);
    if (skipNotifyOnElement(this.target)) {
      this.lastReportedSize = size2;
    }
    if (this.lastReportedSize.inlineSize !== size2.inlineSize || this.lastReportedSize.blockSize !== size2.blockSize) {
      return true;
    }
    return false;
  };
  return ResizeObservation2;
}();

// node_modules/@juggle/resize-observer/lib/ResizeObserverDetail.js
var ResizeObserverDetail = /* @__PURE__ */ function() {
  function ResizeObserverDetail2(resizeObserver, callback) {
    this.activeTargets = [];
    this.skippedTargets = [];
    this.observationTargets = [];
    this.observer = resizeObserver;
    this.callback = callback;
  }
  return ResizeObserverDetail2;
}();

// node_modules/@juggle/resize-observer/lib/ResizeObserverController.js
var observerMap = /* @__PURE__ */ new WeakMap();
var getObservationIndex = function(observationTargets, target) {
  for (var i2 = 0; i2 < observationTargets.length; i2 += 1) {
    if (observationTargets[i2].target === target) {
      return i2;
    }
  }
  return -1;
};
var ResizeObserverController = function() {
  function ResizeObserverController2() {
  }
  ResizeObserverController2.connect = function(resizeObserver, callback) {
    var detail = new ResizeObserverDetail(resizeObserver, callback);
    observerMap.set(resizeObserver, detail);
  };
  ResizeObserverController2.observe = function(resizeObserver, target, options) {
    var detail = observerMap.get(resizeObserver);
    var firstObservation = detail.observationTargets.length === 0;
    if (getObservationIndex(detail.observationTargets, target) < 0) {
      firstObservation && resizeObservers.push(detail);
      detail.observationTargets.push(new ResizeObservation(target, options && options.box));
      updateCount(1);
      scheduler.schedule();
    }
  };
  ResizeObserverController2.unobserve = function(resizeObserver, target) {
    var detail = observerMap.get(resizeObserver);
    var index2 = getObservationIndex(detail.observationTargets, target);
    var lastObservation = detail.observationTargets.length === 1;
    if (index2 >= 0) {
      lastObservation && resizeObservers.splice(resizeObservers.indexOf(detail), 1);
      detail.observationTargets.splice(index2, 1);
      updateCount(-1);
    }
  };
  ResizeObserverController2.disconnect = function(resizeObserver) {
    var _this = this;
    var detail = observerMap.get(resizeObserver);
    detail.observationTargets.slice().forEach(function(ot) {
      return _this.unobserve(resizeObserver, ot.target);
    });
    detail.activeTargets.splice(0, detail.activeTargets.length);
  };
  return ResizeObserverController2;
}();

// node_modules/@juggle/resize-observer/lib/ResizeObserver.js
var ResizeObserver = function() {
  function ResizeObserver2(callback) {
    if (arguments.length === 0) {
      throw new TypeError("Failed to construct 'ResizeObserver': 1 argument required, but only 0 present.");
    }
    if (typeof callback !== "function") {
      throw new TypeError("Failed to construct 'ResizeObserver': The callback provided as parameter 1 is not a function.");
    }
    ResizeObserverController.connect(this, callback);
  }
  ResizeObserver2.prototype.observe = function(target, options) {
    if (arguments.length === 0) {
      throw new TypeError("Failed to execute 'observe' on 'ResizeObserver': 1 argument required, but only 0 present.");
    }
    if (!isElement(target)) {
      throw new TypeError("Failed to execute 'observe' on 'ResizeObserver': parameter 1 is not of type 'Element");
    }
    ResizeObserverController.observe(this, target, options);
  };
  ResizeObserver2.prototype.unobserve = function(target) {
    if (arguments.length === 0) {
      throw new TypeError("Failed to execute 'unobserve' on 'ResizeObserver': 1 argument required, but only 0 present.");
    }
    if (!isElement(target)) {
      throw new TypeError("Failed to execute 'unobserve' on 'ResizeObserver': parameter 1 is not of type 'Element");
    }
    ResizeObserverController.unobserve(this, target);
  };
  ResizeObserver2.prototype.disconnect = function() {
    ResizeObserverController.disconnect(this);
  };
  ResizeObserver2.toString = function() {
    return "function ResizeObserver () { [polyfill code] }";
  };
  return ResizeObserver2;
}();

// node_modules/react-spring-bottom-sheet/dist/index.es.js
function x() {
  return x = Object.assign || function(e) {
    for (var n2 = 1; n2 < arguments.length; n2++) {
      var r2 = arguments[n2];
      for (var t3 in r2) Object.prototype.hasOwnProperty.call(r2, t3) && (e[t3] = r2[t3]);
    }
    return e;
  }, x.apply(this, arguments);
}
function C(e, n2) {
  if (null == e) return {};
  var r2, t3, o2 = {}, i2 = Object.keys(e);
  for (t3 = 0; t3 < i2.length; t3++) n2.indexOf(r2 = i2[t3]) >= 0 || (o2[r2] = e[r2]);
  return o2;
}
var O = "undefined" != typeof window ? import_react11.useLayoutEffect : import_react11.useEffect;
function N(e, n2, r2) {
  return n2 = (n2 = +n2) == n2 ? n2 : 0, r2 = (r2 = +r2) == r2 ? r2 : 0, (e = +e) == e && (e = (e = e <= r2 ? e : r2) >= n2 ? e : n2), e;
}
function w(e) {
  var n2 = Math.round(e);
  if (Number.isNaN(e)) throw new TypeError("Found a NaN! Check your snapPoints / defaultSnap / snapTo ");
  return n2;
}
var H = { box: "border-box" };
function D(e, n2) {
  var r2 = n2.label, o2 = n2.enabled, i2 = n2.resizeSourceRef, u2 = (0, import_react11.useState)(0), s2 = u2[0], l2 = u2[1];
  (0, import_react11.useDebugValue)(r2 + ": " + s2);
  var d = (0, import_react11.useCallback)(function(e2) {
    l2(e2[0].borderBoxSize[0].blockSize), i2.current = "element";
  }, [i2]);
  return O(function() {
    if (e.current && o2) {
      var n3 = new ResizeObserver(d);
      return n3.observe(e.current, H), function() {
        n3.disconnect();
      };
    }
  }, [e, d, o2]), o2 ? s2 : 0;
}
function k(e) {
  return void 0 === e && (e = 1e3), new Promise(function(n2) {
    return setTimeout(n2, e);
  });
}
var z = { DRAG: { target: "#overlay.dragging", actions: "onOpenEnd" } };
var j = { RESIZE: { target: "#overlay.resizing", actions: "onOpenEnd" } };
var A = Machine({ id: "overlay", initial: "closed", context: { initialState: "CLOSED" }, states: { closed: { on: { OPEN: "opening", CLOSE: void 0 } }, opening: { initial: "start", states: { start: { invoke: { src: "onOpenStart", onDone: "transition" } }, transition: { always: [{ target: "immediately", cond: "initiallyOpen" }, { target: "smoothly", cond: "initiallyClosed" }] }, immediately: { initial: "open", states: { open: { invoke: { src: "openImmediately", onDone: "activating" } }, activating: { invoke: { src: "activate", onDone: "#overlay.opening.end" }, on: x({}, z, j) } } }, smoothly: { initial: "visuallyHidden", states: { visuallyHidden: { invoke: { src: "renderVisuallyHidden", onDone: "activating" } }, activating: { invoke: { src: "activate", onDone: "open" } }, open: { invoke: { src: "openSmoothly", onDone: "#overlay.opening.end" }, on: x({}, z, j) } } }, end: { invoke: { src: "onOpenEnd", onDone: "done" }, on: { CLOSE: "#overlay.closing", DRAG: "#overlay.dragging" } }, done: { type: "final" } }, on: x({}, { CLOSE: { target: "#overlay.closing", actions: "onOpenCancel" } }), onDone: "open" }, open: { on: { DRAG: "#overlay.dragging", SNAP: "snapping", RESIZE: "resizing" } }, dragging: { on: { SNAP: "snapping" } }, snapping: { initial: "start", states: { start: { invoke: { src: "onSnapStart", onDone: "snappingSmoothly" }, entry: [assign3({ y: function(e, n2) {
  return n2.payload.y;
}, velocity: function(e, n2) {
  return n2.payload.velocity;
}, snapSource: function(e, n2) {
  var r2 = n2.payload.source;
  return void 0 === r2 ? "custom" : r2;
} })] }, snappingSmoothly: { invoke: { src: "snapSmoothly", onDone: "end" } }, end: { invoke: { src: "onSnapEnd", onDone: "done" }, on: { RESIZE: "#overlay.resizing", SNAP: "#overlay.snapping", CLOSE: "#overlay.closing", DRAG: "#overlay.dragging" } }, done: { type: "final" } }, on: { SNAP: { target: "snapping", actions: "onSnapEnd" }, RESIZE: { target: "#overlay.resizing", actions: "onSnapCancel" }, DRAG: { target: "#overlay.dragging", actions: "onSnapCancel" }, CLOSE: { target: "#overlay.closing", actions: "onSnapCancel" } }, onDone: "open" }, resizing: { initial: "start", states: { start: { invoke: { src: "onResizeStart", onDone: "resizingSmoothly" } }, resizingSmoothly: { invoke: { src: "resizeSmoothly", onDone: "end" } }, end: { invoke: { src: "onResizeEnd", onDone: "done" }, on: { SNAP: "#overlay.snapping", CLOSE: "#overlay.closing", DRAG: "#overlay.dragging" } }, done: { type: "final" } }, on: { RESIZE: { target: "resizing", actions: "onResizeEnd" }, SNAP: { target: "snapping", actions: "onResizeCancel" }, DRAG: { target: "#overlay.dragging", actions: "onResizeCancel" }, CLOSE: { target: "#overlay.closing", actions: "onResizeCancel" } }, onDone: "open" }, closing: { initial: "start", states: { start: { invoke: { src: "onCloseStart", onDone: "deactivating" }, on: { OPEN: { target: "#overlay.open", actions: "onCloseCancel" } } }, deactivating: { invoke: { src: "deactivate", onDone: "closingSmoothly" } }, closingSmoothly: { invoke: { src: "closeSmoothly", onDone: "end" } }, end: { invoke: { src: "onCloseEnd", onDone: "done" }, on: { OPEN: { target: "#overlay.opening", actions: "onCloseCancel" } } }, done: { type: "final" } }, on: { CLOSE: void 0, OPEN: { target: "#overlay.opening", actions: "onCloseCancel" } }, onDone: "closed" } }, on: { CLOSE: "closing" } }, { actions: { onOpenCancel: function(e, n2) {
}, onSnapCancel: function(e, n2) {
}, onResizeCancel: function(e, n2) {
}, onCloseCancel: function(e, n2) {
}, onOpenEnd: function(e, n2) {
}, onSnapEnd: function(e, n2) {
}, onRezizeEnd: function(e, n2) {
} }, services: { onSnapStart: function() {
  try {
    return Promise.resolve(k()).then(function() {
    });
  } catch (e) {
    return Promise.reject(e);
  }
}, onOpenStart: function() {
  try {
    return Promise.resolve(k()).then(function() {
    });
  } catch (e) {
    return Promise.reject(e);
  }
}, onCloseStart: function() {
  try {
    return Promise.resolve(k()).then(function() {
    });
  } catch (e) {
    return Promise.reject(e);
  }
}, onResizeStart: function() {
  try {
    return Promise.resolve(k()).then(function() {
    });
  } catch (e) {
    return Promise.reject(e);
  }
}, onSnapEnd: function() {
  try {
    return Promise.resolve(k()).then(function() {
    });
  } catch (e) {
    return Promise.reject(e);
  }
}, onOpenEnd: function() {
  try {
    return Promise.resolve(k()).then(function() {
    });
  } catch (e) {
    return Promise.reject(e);
  }
}, onCloseEnd: function() {
  try {
    return Promise.resolve(k()).then(function() {
    });
  } catch (e) {
    return Promise.reject(e);
  }
}, onResizeEnd: function() {
  try {
    return Promise.resolve(k()).then(function() {
    });
  } catch (e) {
    return Promise.reject(e);
  }
}, renderVisuallyHidden: function(e, n2) {
  try {
    return Promise.resolve(k()).then(function() {
    });
  } catch (e2) {
    return Promise.reject(e2);
  }
}, activate: function(e, n2) {
  try {
    return Promise.resolve(k()).then(function() {
    });
  } catch (e2) {
    return Promise.reject(e2);
  }
}, deactivate: function(e, n2) {
  try {
    return Promise.resolve(k()).then(function() {
    });
  } catch (e2) {
    return Promise.reject(e2);
  }
}, openSmoothly: function(e, n2) {
  try {
    return Promise.resolve(k()).then(function() {
    });
  } catch (e2) {
    return Promise.reject(e2);
  }
}, openImmediately: function(e, n2) {
  try {
    return Promise.resolve(k()).then(function() {
    });
  } catch (e2) {
    return Promise.reject(e2);
  }
}, snapSmoothly: function(e, n2) {
  try {
    return Promise.resolve(k()).then(function() {
    });
  } catch (e2) {
    return Promise.reject(e2);
  }
}, resizeSmoothly: function(e, n2) {
  try {
    return Promise.resolve(k()).then(function() {
    });
  } catch (e2) {
    return Promise.reject(e2);
  }
}, closeSmoothly: function(e, n2) {
  try {
    return Promise.resolve(k()).then(function() {
    });
  } catch (e2) {
    return Promise.reject(e2);
  }
} }, guards: { initiallyClosed: function(e) {
  return "CLOSED" === e.initialState;
}, initiallyOpen: function(e) {
  return "OPEN" === e.initialState;
} } });
var L = ["children", "sibling", "className", "footer", "header", "open", "initialState", "lastSnapRef", "initialFocusRef", "onDismiss", "maxHeight", "defaultSnap", "snapPoints", "blocking", "scrollLocking", "style", "onSpringStart", "onSpringCancel", "onSpringEnd", "reserveScrollBarGap", "expandOnContentDrag"];
var T = ["velocity"];
var M = ["onRest", "config"];
var I = config.default;
var F = I.tension;
var G2 = I.friction;
var Z = import_react11.default.forwardRef(function(e, i2) {
  var l2 = e.children, p = e.sibling, P = e.className, b = e.footer, R = e.header, H2 = e.open, k2 = e.initialState, z2 = e.lastSnapRef, j2 = e.initialFocusRef, I2 = e.onDismiss, Z2 = e.maxHeight, K2 = e.defaultSnap, J2 = void 0 === K2 ? q : K2, Q = e.snapPoints, U = void 0 === Q ? V : Q, W = e.blocking, X = void 0 === W || W, Y = e.scrollLocking, $ = void 0 === Y || Y, _ = e.style, ee = e.onSpringStart, ne = e.onSpringCancel, re = e.onSpringEnd, te = e.reserveScrollBarGap, oe = void 0 === te ? X : te, ie = e.expandOnContentDrag, ae = void 0 !== ie && ie, ce = C(e, L), ue = function() {
    var e2 = (0, import_react11.useState)(false), n2 = e2[0], r2 = e2[1], t3 = (0, import_react11.useState)({}), i3 = t3[0], u2 = t3[1], s2 = (0, import_react11.useCallback)(function(e3) {
      return u2(function(n3) {
        var r3;
        return x({}, n3, ((r3 = {})[e3] = false, r3));
      }), function() {
        u2(function(n3) {
          var r3;
          return x({}, n3, ((r3 = {})[e3] = true, r3));
        });
      };
    }, []);
    return (0, import_react11.useEffect)(function() {
      var e3 = Object.values(i3);
      0 !== e3.length && e3.every(Boolean) && r2(true);
    }, [i3]), { ready: n2, registerReady: s2 };
  }(), se = ue.ready, le = ue.registerReady, de = (0, import_react11.useRef)(false), fe = (0, import_react11.useRef)(ee), ve = (0, import_react11.useRef)(ne), me = (0, import_react11.useRef)(re);
  (0, import_react11.useEffect)(function() {
    fe.current = ee, ve.current = ne, me.current = re;
  }, [ne, ee, re]);
  var pe, ye, he = useSpring(function() {
    return { y: 0, ready: 0, maxHeight: 0, minSnap: 0, maxSnap: 0 };
  }), ge = he[0], Se = he[1], Ee = (0, import_react11.useRef)(null), Pe = (0, import_react11.useRef)(null), be = (0, import_react11.useRef)(null), Re = (0, import_react11.useRef)(null), xe = (0, import_react11.useRef)(null), Ce = (0, import_react11.useRef)(null), Oe = (0, import_react11.useRef)(0), Ne = (0, import_react11.useRef)(), we = (0, import_react11.useRef)(false), He = (pe = (0, import_react11.useMemo)(function() {
    return "undefined" != typeof window ? window.matchMedia("(prefers-reduced-motion: reduce)") : null;
  }, []), ye = (0, import_react11.useRef)(null == pe ? void 0 : pe.matches), (0, import_react11.useDebugValue)(ye.current ? "reduce" : "no-preference"), (0, import_react11.useEffect)(function() {
    var e2 = function(e3) {
      ye.current = e3.matches;
    };
    return null == pe || pe.addListener(e2), function() {
      return null == pe ? void 0 : pe.removeListener(e2);
    };
  }, [pe]), ye), De = function(e2) {
    var n2 = e2.targetRef, i3 = e2.enabled, a2 = e2.reserveScrollBarGap, c2 = (0, import_react11.useRef)({ activate: function() {
      throw new TypeError("Tried to activate scroll lock too early");
    }, deactivate: function() {
    } });
    return (0, import_react11.useDebugValue)(i3 ? "Enabled" : "Disabled"), (0, import_react11.useEffect)(function() {
      if (!i3) return c2.current.deactivate(), void (c2.current = { activate: function() {
      }, deactivate: function() {
      } });
      var e3 = n2.current, r2 = false;
      c2.current = { activate: function() {
        r2 || (r2 = true, disableBodyScroll(e3, { allowTouchMove: function(e4) {
          return e4.closest("[data-body-scroll-lock-ignore]");
        }, reserveScrollBarGap: a2 }));
      }, deactivate: function() {
        r2 && (r2 = false, enableBodyScroll(e3));
      } };
    }, [i3, n2, a2]), c2;
  }({ targetRef: Pe, enabled: se && $, reserveScrollBarGap: oe }), ke = function(e2) {
    var n2 = e2.targetRef, i3 = e2.enabled, a2 = (0, import_react11.useRef)({ activate: function() {
      throw new TypeError("Tried to activate aria hider too early");
    }, deactivate: function() {
    } });
    return (0, import_react11.useDebugValue)(i3 ? "Enabled" : "Disabled"), (0, import_react11.useEffect)(function() {
      if (!i3) return a2.current.deactivate(), void (a2.current = { activate: function() {
      }, deactivate: function() {
      } });
      var e3 = n2.current, r2 = false, t3 = [], o2 = [];
      a2.current = { activate: function() {
        if (!r2) {
          r2 = true;
          var n3 = e3.parentNode;
          document.querySelectorAll("body > *").forEach(function(e4) {
            if (e4 !== n3) {
              var r3 = e4.getAttribute("aria-hidden");
              null !== r3 && "false" !== r3 || (t3.push(r3), o2.push(e4), e4.setAttribute("aria-hidden", "true"));
            }
          });
        }
      }, deactivate: function() {
        r2 && (r2 = false, o2.forEach(function(e4, n3) {
          var r3 = t3[n3];
          null === r3 ? e4.removeAttribute("aria-hidden") : e4.setAttribute("aria-hidden", r3);
        }), t3 = [], o2 = []);
      } };
    }, [n2, i3]), a2;
  }({ targetRef: Ee, enabled: se && X }), ze = function(e2) {
    var n2 = e2.targetRef, i3 = e2.fallbackRef, a2 = e2.initialFocusRef, c2 = e2.enabled, u2 = (0, import_react11.useRef)({ activate: function() {
      throw new TypeError("Tried to activate focus trap too early");
    }, deactivate: function() {
    } });
    return (0, import_react11.useDebugValue)(c2 ? "Enabled" : "Disabled"), (0, import_react11.useEffect)(function() {
      if (!c2) return u2.current.deactivate(), void (u2.current = { activate: function() {
      }, deactivate: function() {
      } });
      var e3 = i3.current, r2 = createFocusTrap(n2.current, { onActivate: void 0, initialFocus: a2 ? function() {
        return (null == a2 ? void 0 : a2.current) || e3;
      } : void 0, fallbackFocus: e3, escapeDeactivates: false, clickOutsideDeactivates: false }), t3 = false;
      u2.current = { activate: function() {
        try {
          return t3 ? Promise.resolve() : (t3 = true, Promise.resolve(r2.activate()).then(function() {
            return Promise.resolve(new Promise(function(e4) {
              return setTimeout(function() {
                return e4(void 0);
              }, 0);
            })).then(function() {
            });
          }));
        } catch (e4) {
          return Promise.reject(e4);
        }
      }, deactivate: function() {
        t3 && (t3 = false, r2.deactivate());
      } };
    }, [c2, i3, a2, n2]), u2;
  }({ targetRef: Ee, fallbackRef: Ce, initialFocusRef: j2 || void 0, enabled: se && X && false !== j2 }), je = function(e2) {
    var n2 = e2.getSnapPoints, i3 = e2.heightRef, c2 = e2.lastSnapRef, s2 = e2.ready, l3 = function(e3) {
      var n3 = e3.contentRef, i4 = e3.controlledMaxHeight, c3 = e3.footerEnabled, s3 = e3.footerRef, l4 = e3.headerEnabled, d2 = e3.headerRef, f2 = e3.registerReady, v2 = e3.resizeSourceRef, m2 = (0, import_react11.useMemo)(function() {
        return f2("contentHeight");
      }, [f2]), p3 = function(e4, n4, i5) {
        var c4 = (0, import_react11.useMemo)(function() {
          return n4("maxHeight");
        }, [n4]), s4 = (0, import_react11.useState)(function() {
          return w(e4) || "undefined" != typeof window ? window.innerHeight : 0;
        }), l5 = s4[0], d3 = s4[1], f3 = l5 > 0, v3 = (0, import_react11.useRef)(0);
        return (0, import_react11.useDebugValue)(e4 ? "controlled" : "auto"), (0, import_react11.useEffect)(function() {
          f3 && c4();
        }, [f3, c4]), O(function() {
          if (e4) return d3(w(e4)), void (i5.current = "maxheightprop");
          var n5 = function() {
            v3.current || (v3.current = requestAnimationFrame(function() {
              d3(window.innerHeight), i5.current = "window", v3.current = 0;
            }));
          };
          return window.addEventListener("resize", n5), d3(window.innerHeight), i5.current = "window", c4(), function() {
            window.removeEventListener("resize", n5), cancelAnimationFrame(v3.current);
          };
        }, [e4, c4, i5]), l5;
      }(i4, f2, v2), y2 = D(d2, { label: "headerHeight", enabled: l4, resizeSourceRef: v2 }), h2 = D(n3, { label: "contentHeight", enabled: true, resizeSourceRef: v2 }), g2 = D(s3, { label: "footerHeight", enabled: c3, resizeSourceRef: v2 }), S = Math.min(p3 - y2 - g2, h2) + y2 + g2;
      (0, import_react11.useDebugValue)("minHeight: " + S);
      var E = h2 > 0;
      return (0, import_react11.useEffect)(function() {
        E && m2();
      }, [E, m2]), { maxHeight: p3, minHeight: S, headerHeight: y2, footerHeight: g2 };
    }({ contentRef: e2.contentRef, controlledMaxHeight: e2.controlledMaxHeight, footerEnabled: e2.footerEnabled, footerRef: e2.footerRef, headerEnabled: e2.headerEnabled, headerRef: e2.headerRef, registerReady: e2.registerReady, resizeSourceRef: e2.resizeSourceRef }), d = l3.maxHeight, f = l3.minHeight, v = l3.headerHeight, m = l3.footerHeight, p2 = function(e3, n3) {
      var r2 = [].concat(e3).map(w).reduce(function(e4, r3) {
        return e4.add(N(r3, 0, n3)), e4;
      }, /* @__PURE__ */ new Set()), t3 = Array.from(r2), o2 = Math.min.apply(Math, t3);
      if (Number.isNaN(o2)) throw new TypeError("minSnap is NaN");
      var i4 = Math.max.apply(Math, t3);
      if (Number.isNaN(i4)) throw new TypeError("maxSnap is NaN");
      return { snapPoints: t3, minSnap: o2, maxSnap: i4 };
    }(s2 ? n2({ height: i3.current, footerHeight: m, headerHeight: v, minHeight: f, maxHeight: d }) : [0], d), y = p2.snapPoints, h = p2.minSnap, g = p2.maxSnap;
    return (0, import_react11.useDebugValue)("minSnap: " + h + ", maxSnap:" + g), { minSnap: h, maxSnap: g, findSnap: function(e3) {
      var n3 = w("function" == typeof e3 ? e3({ footerHeight: m, headerHeight: v, height: i3.current, minHeight: f, maxHeight: d, snapPoints: y, lastSnap: c2.current }) : e3);
      return y.reduce(function(e4, r2) {
        return Math.abs(r2 - n3) < Math.abs(e4 - n3) ? r2 : e4;
      }, h);
    }, maxHeight: d };
  }({ contentRef: be, controlledMaxHeight: Z2, footerEnabled: !!b, footerRef: xe, getSnapPoints: U, headerEnabled: false !== R, headerRef: Re, heightRef: Oe, lastSnapRef: z2, ready: se, registerReady: le, resizeSourceRef: Ne }), Ae = je.minSnap, Le = je.maxSnap, Te = je.maxHeight, Me = je.findSnap, Ie = (0, import_react11.useRef)(Te), Fe = (0, import_react11.useRef)(Ae), Ge = (0, import_react11.useRef)(Le), Ze = (0, import_react11.useRef)(Me), Be = (0, import_react11.useRef)(0);
  O(function() {
    Ie.current = Te, Ge.current = Le, Fe.current = Ae, Ze.current = Me, Be.current = Me(J2);
  }, [Me, J2, Te, Le, Ae]);
  var qe = (0, import_react11.useCallback)(function(e2) {
    var n2 = e2.onRest, r2 = e2.config, t3 = (r2 = void 0 === r2 ? {} : r2).velocity, o2 = void 0 === t3 ? 1 : t3, i3 = C(r2, T), a2 = C(e2, M);
    return new Promise(function(e3) {
      return Se(x({}, a2, { config: x({ velocity: o2 }, i3, { mass: 1, tension: F, friction: Math.max(G2, G2 + (G2 - G2 * o2)) }), onRest: function() {
        var r3 = [].slice.call(arguments);
        e3.apply(void 0, r3), null == n2 || n2.apply(void 0, r3);
      } }));
    });
  }, [Se]), Ve = useMachine(A, { devTools: false, actions: { onOpenCancel: (0, import_react11.useCallback)(function() {
    return null == ve.current ? void 0 : ve.current({ type: "OPEN" });
  }, []), onSnapCancel: (0, import_react11.useCallback)(function(e2) {
    return null == ve.current ? void 0 : ve.current({ type: "SNAP", source: e2.snapSource });
  }, []), onCloseCancel: (0, import_react11.useCallback)(function() {
    return null == ve.current ? void 0 : ve.current({ type: "CLOSE" });
  }, []), onResizeCancel: (0, import_react11.useCallback)(function() {
    return null == ve.current ? void 0 : ve.current({ type: "RESIZE", source: Ne.current });
  }, []), onOpenEnd: (0, import_react11.useCallback)(function() {
    return null == me.current ? void 0 : me.current({ type: "OPEN" });
  }, []), onSnapEnd: (0, import_react11.useCallback)(function(e2, n2) {
    return null == me.current ? void 0 : me.current({ type: "SNAP", source: e2.snapSource });
  }, []), onResizeEnd: (0, import_react11.useCallback)(function() {
    return null == me.current ? void 0 : me.current({ type: "RESIZE", source: Ne.current });
  }, []) }, context: { initialState: k2 }, services: { onSnapStart: (0, import_react11.useCallback)(function(e2, n2) {
    try {
      return Promise.resolve(null == fe.current ? void 0 : fe.current({ type: "SNAP", source: n2.payload.source || "custom" }));
    } catch (e3) {
      return Promise.reject(e3);
    }
  }, []), onOpenStart: (0, import_react11.useCallback)(function() {
    try {
      return Promise.resolve(null == fe.current ? void 0 : fe.current({ type: "OPEN" }));
    } catch (e2) {
      return Promise.reject(e2);
    }
  }, []), onCloseStart: (0, import_react11.useCallback)(function() {
    try {
      return Promise.resolve(null == fe.current ? void 0 : fe.current({ type: "CLOSE" }));
    } catch (e2) {
      return Promise.reject(e2);
    }
  }, []), onResizeStart: (0, import_react11.useCallback)(function() {
    try {
      return Promise.resolve(null == fe.current ? void 0 : fe.current({ type: "RESIZE", source: Ne.current }));
    } catch (e2) {
      return Promise.reject(e2);
    }
  }, []), onSnapEnd: (0, import_react11.useCallback)(function(e2, n2) {
    try {
      return Promise.resolve(null == me.current ? void 0 : me.current({ type: "SNAP", source: e2.snapSource }));
    } catch (e3) {
      return Promise.reject(e3);
    }
  }, []), onOpenEnd: (0, import_react11.useCallback)(function() {
    try {
      return Promise.resolve(null == me.current ? void 0 : me.current({ type: "OPEN" }));
    } catch (e2) {
      return Promise.reject(e2);
    }
  }, []), onCloseEnd: (0, import_react11.useCallback)(function() {
    try {
      return Promise.resolve(null == me.current ? void 0 : me.current({ type: "CLOSE" }));
    } catch (e2) {
      return Promise.reject(e2);
    }
  }, []), onResizeEnd: (0, import_react11.useCallback)(function() {
    try {
      return Promise.resolve(null == me.current ? void 0 : me.current({ type: "RESIZE", source: Ne.current }));
    } catch (e2) {
      return Promise.reject(e2);
    }
  }, []), renderVisuallyHidden: (0, import_react11.useCallback)(function(e2, n2) {
    try {
      return Promise.resolve(qe({ y: Be.current, ready: 0, maxHeight: Ie.current, maxSnap: Ge.current, minSnap: Be.current, immediate: true })).then(function() {
      });
    } catch (e3) {
      return Promise.reject(e3);
    }
  }, [qe]), activate: (0, import_react11.useCallback)(function(e2, n2) {
    try {
      return de.current = true, Promise.resolve(Promise.all([De.current.activate(), ze.current.activate(), ke.current.activate()])).then(function() {
      });
    } catch (e3) {
      return Promise.reject(e3);
    }
  }, [ke, ze, De]), deactivate: (0, import_react11.useCallback)(function() {
    try {
      return De.current.deactivate(), ze.current.deactivate(), ke.current.deactivate(), de.current = false, Promise.resolve();
    } catch (e2) {
      return Promise.reject(e2);
    }
  }, [ke, ze, De]), openImmediately: (0, import_react11.useCallback)(function() {
    try {
      return Oe.current = Be.current, Promise.resolve(qe({ y: Be.current, ready: 1, maxHeight: Ie.current, maxSnap: Ge.current, minSnap: Be.current, immediate: true })).then(function() {
      });
    } catch (e2) {
      return Promise.reject(e2);
    }
  }, [qe]), openSmoothly: (0, import_react11.useCallback)(function() {
    try {
      return Promise.resolve(qe({ y: 0, ready: 1, maxHeight: Ie.current, maxSnap: Ge.current, minSnap: Be.current, immediate: true })).then(function() {
        return Oe.current = Be.current, Promise.resolve(qe({ y: Be.current, ready: 1, maxHeight: Ie.current, maxSnap: Ge.current, minSnap: Be.current, immediate: He.current })).then(function() {
        });
      });
    } catch (e2) {
      return Promise.reject(e2);
    }
  }, [qe, He]), snapSmoothly: (0, import_react11.useCallback)(function(e2, n2) {
    try {
      var r2 = Ze.current(e2.y);
      return Oe.current = r2, z2.current = r2, Promise.resolve(qe({ y: r2, ready: 1, maxHeight: Ie.current, maxSnap: Ge.current, minSnap: Fe.current, immediate: He.current, config: { velocity: e2.velocity } })).then(function() {
      });
    } catch (e3) {
      return Promise.reject(e3);
    }
  }, [qe, z2, He]), resizeSmoothly: (0, import_react11.useCallback)(function() {
    try {
      var e2 = Ze.current(Oe.current);
      return Oe.current = e2, z2.current = e2, Promise.resolve(qe({ y: e2, ready: 1, maxHeight: Ie.current, maxSnap: Ge.current, minSnap: Fe.current, immediate: "element" !== Ne.current || He.current })).then(function() {
      });
    } catch (e3) {
      return Promise.reject(e3);
    }
  }, [qe, z2, He]), closeSmoothly: (0, import_react11.useCallback)(function(e2, n2) {
    try {
      return qe({ minSnap: Oe.current, immediate: true }), Oe.current = 0, Promise.resolve(qe({ y: 0, maxHeight: Ie.current, maxSnap: Ge.current, immediate: He.current })).then(function() {
        return Promise.resolve(qe({ ready: 0, immediate: true })).then(function() {
        });
      });
    } catch (e3) {
      return Promise.reject(e3);
    }
  }, [qe, He]) } }), Ke = Ve[0], Je = Ve[1];
  (0, import_react11.useEffect)(function() {
    se && Je(H2 ? "OPEN" : "CLOSE");
  }, [H2, Je, se]), O(function() {
    (Te || Le || Ae) && Je("RESIZE");
  }, [Te, Le, Ae, Je]), (0, import_react11.useEffect)(function() {
    return function() {
      De.current.deactivate(), ze.current.deactivate(), ke.current.deactivate();
    };
  }, [ke, ze, De]), (0, import_react11.useImperativeHandle)(i2, function() {
    return { snapTo: function(e2, n2) {
      var r2 = void 0 === n2 ? {} : n2, t3 = r2.velocity, o2 = void 0 === t3 ? 1 : t3, i3 = r2.source, a2 = void 0 === i3 ? "custom" : i3;
      Je("SNAP", { payload: { y: Ze.current(e2), velocity: o2, source: a2 } });
    }, get height() {
      return Oe.current;
    } };
  }, [Je]), (0, import_react11.useEffect)(function() {
    var e2 = Pe.current, n2 = function(e3) {
      we.current && e3.preventDefault();
    }, r2 = function(n3) {
      e2.scrollTop < 0 && (requestAnimationFrame(function() {
        e2.style.overflow = "hidden", e2.scrollTop = 0, e2.style.removeProperty("overflow");
      }), n3.preventDefault());
    };
    return ae && (e2.addEventListener("scroll", n2), e2.addEventListener("touchmove", n2), e2.addEventListener("touchstart", r2)), function() {
      e2.removeEventListener("scroll", n2), e2.removeEventListener("touchmove", n2), e2.removeEventListener("touchstart", r2);
    };
  }, [ae, Pe]);
  var Qe = useDrag(function(e2) {
    var n2 = e2.args, r2 = (n2 = void 0 === n2 ? [] : n2)[0], t3 = (r2 = void 0 === r2 ? {} : r2).closeOnTap, o2 = void 0 !== t3 && t3, i3 = r2.isContentDragging, a2 = void 0 !== i3 && i3, c2 = e2.cancel, u2 = e2.direction[1], s2 = e2.down, l3 = e2.first, d = e2.last, f = e2.memo, v = void 0 === f ? ge.y.getValue() : f, m = e2.tap, p2 = e2.velocity, y = -1 * e2.movement[1];
    if (!de.current) return c2(), v;
    if (I2 && o2 && m) return c2(), setTimeout(function() {
      return I2();
    }, 0), v;
    if (m) return v;
    var g = v + y, S = y * p2, E = Math.max(Fe.current, Math.min(Ge.current, g + 2 * S));
    if (!s2 && I2 && u2 > 0 && g + S < Fe.current / 2) return c2(), I2(), v;
    var P2 = s2 ? I2 || Fe.current !== Ge.current ? rubberbandIfOutOfBounds(g, I2 ? 0 : Fe.current, Ge.current, 0.55) : g < Fe.current ? rubberbandIfOutOfBounds(g, Fe.current, 2 * Ge.current, 0.55) : rubberbandIfOutOfBounds(g, Fe.current / 2, Ge.current, 0.55) : E;
    return ae && a2 ? (P2 >= Ge.current && (P2 = Ge.current), v === Ge.current && Pe.current.scrollTop > 0 && (P2 = Ge.current), we.current = P2 < Ge.current) : we.current = false, l3 && Je("DRAG"), d ? (Je("SNAP", { payload: { y: P2, velocity: p2 > 0.05 ? p2 : 1, source: "dragging" } }), v) : (Se({ y: P2, ready: 1, maxHeight: Ie.current, maxSnap: Ge.current, minSnap: Fe.current, immediate: true, config: { velocity: p2 } }), v);
  }, { filterTaps: true });
  if (Number.isNaN(Ge.current)) throw new TypeError("maxSnapRef is NaN!!");
  if (Number.isNaN(Fe.current)) throw new TypeError("minSnapRef is NaN!!");
  var Ue = function(e2) {
    var n2, r2 = e2.spring, t3 = interpolate$1([r2.y, r2.maxHeight], function(e3, n3) {
      return Math.round(N(n3 - e3, 0, 16)) + "px";
    }), o2 = interpolate$1([r2.y, r2.minSnap, r2.maxSnap], function(e3, n3, r3) {
      return N(e3, n3, r3) + "px";
    }), i3 = interpolate$1([r2.y, r2.minSnap, r2.maxSnap], function(e3, n3, r3) {
      return e3 < n3 ? n3 - e3 + "px" : e3 > r3 ? r3 - e3 + "px" : "0px";
    }), a2 = interpolate$1([r2.y, r2.maxSnap], function(e3, n3) {
      return e3 >= n3 ? Math.ceil(e3 - n3) : 0;
    }), c2 = interpolate$1([r2.y, r2.minSnap], function(e3, n3) {
      if (!n3) return 0;
      var r3 = Math.max(n3 / 2 - 45, 0);
      return N((e3 - r3) * (1 / (Math.min(n3 / 2 + 45, n3) - r3) + 0), 0, 1);
    }), u2 = interpolate$1([r2.y, r2.minSnap], function(e3, n3) {
      return n3 ? N(e3 / n3, 0, 1) : 0;
    });
    return (n2 = {})["--rsbs-content-opacity"] = c2, n2["--rsbs-backdrop-opacity"] = u2, n2["--rsbs-antigap-scale-y"] = a2, n2["--rsbs-overlay-translate-y"] = i3, n2["--rsbs-overlay-rounded"] = t3, n2["--rsbs-overlay-h"] = o2, n2;
  }({ spring: ge });
  return import_react11.default.createElement(extendedAnimated.div, x({}, ce, { "data-rsbs-root": true, "data-rsbs-state": B.find(Ke.matches), "data-rsbs-is-blocking": X, "data-rsbs-is-dismissable": !!I2, "data-rsbs-has-header": !!R, "data-rsbs-has-footer": !!b, className: P, ref: Ee, style: x({}, Ue, _, { opacity: ge.ready }) }), p, X && import_react11.default.createElement("div", x({ key: "backdrop", "data-rsbs-backdrop": true }, Qe({ closeOnTap: true }))), import_react11.default.createElement("div", { key: "overlay", "aria-modal": "true", role: "dialog", "data-rsbs-overlay": true, tabIndex: -1, ref: Ce, onKeyDown: function(e2) {
    "Escape" === e2.key && (e2.stopPropagation(), I2 && I2());
  } }, false !== R && import_react11.default.createElement("div", x({ key: "header", "data-rsbs-header": true, ref: Re }, Qe()), R), import_react11.default.createElement("div", x({ key: "scroll", "data-rsbs-scroll": true, ref: Pe }, ae ? Qe({ isContentDragging: true }) : {}), import_react11.default.createElement("div", { "data-rsbs-content": true, ref: be }, l2)), b && import_react11.default.createElement("div", x({ key: "footer", ref: xe, "data-rsbs-footer": true }, Qe()), b)));
});
var B = ["closed", "opening", "open", "closing", "dragging", "snapping", "resizing"];
function q(e) {
  var n2 = e.lastSnap;
  return null != n2 ? n2 : Math.min.apply(Math, e.snapPoints);
}
function V(e) {
  return e.minHeight;
}
var K = ["onSpringStart", "onSpringEnd", "skipInitialTransition"];
var J = (0, import_react11.forwardRef)(function(t3, o2) {
  var i2 = t3.onSpringStart, u2 = t3.onSpringEnd, s2 = t3.skipInitialTransition, l2 = C(t3, K), d = (0, import_react11.useState)(false), f = d[0], v = d[1], m = (0, import_react11.useRef)(), p = (0, import_react11.useRef)(null), y = (0, import_react11.useRef)(s2 && l2.open ? "OPEN" : "CLOSED");
  O(function() {
    if (l2.open) return cancelAnimationFrame(m.current), v(true), function() {
      y.current = "CLOSED";
    };
  }, [l2.open]);
  var h = (0, import_react11.useCallback)(function(e) {
    return Promise.resolve(null == i2 ? void 0 : i2(e)).then(function() {
      "OPEN" === e.type && cancelAnimationFrame(m.current);
    });
  }, [i2]), g = (0, import_react11.useCallback)(function(e) {
    return Promise.resolve(null == u2 ? void 0 : u2(e)).then(function() {
      "CLOSE" === e.type && (m.current = requestAnimationFrame(function() {
        return v(false);
      }));
    });
  }, [u2]);
  return f ? import_react11.default.createElement(reach_portal_esm_default, { "data-rsbs-portal": true }, import_react11.default.createElement(Z, x({}, l2, { lastSnapRef: p, ref: o2, initialState: y.current, onSpringStart: h, onSpringEnd: g }))) : null;
});
export {
  J as BottomSheet
};
/*! Bundled license information:

use-sync-external-store/cjs/use-sync-external-store-shim.development.js:
  (**
   * @license React
   * use-sync-external-store-shim.development.js
   *
   * Copyright (c) Meta Platforms, Inc. and affiliates.
   *
   * This source code is licensed under the MIT license found in the
   * LICENSE file in the root directory of this source tree.
   *)

use-subscription/cjs/use-subscription.development.js:
  (**
   * @license React
   * use-subscription.development.js
   *
   * Copyright (c) Meta Platforms, Inc. and affiliates.
   *
   * This source code is licensed under the MIT license found in the
   * LICENSE file in the root directory of this source tree.
   *)

xstate/lib/_virtual/_tslib.js:
  (*! *****************************************************************************
  Copyright (c) Microsoft Corporation.
  
  Permission to use, copy, modify, and/or distribute this software for any
  purpose with or without fee is hereby granted.
  
  THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES WITH
  REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY
  AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY SPECIAL, DIRECT,
  INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM
  LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR
  OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
  PERFORMANCE OF THIS SOFTWARE.
  ***************************************************************************** *)

xstate/es/_virtual/_tslib.js:
  (*! *****************************************************************************
  Copyright (c) Microsoft Corporation.
  
  Permission to use, copy, modify, and/or distribute this software for any
  purpose with or without fee is hereby granted.
  
  THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES WITH
  REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY
  AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY SPECIAL, DIRECT,
  INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM
  LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR
  OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
  PERFORMANCE OF THIS SOFTWARE.
  ***************************************************************************** *)

tabbable/dist/index.esm.js:
  (*!
  * tabbable 5.3.3
  * @license MIT, https://github.com/focus-trap/tabbable/blob/master/LICENSE
  *)

focus-trap/dist/focus-trap.esm.js:
  (*!
  * focus-trap 6.9.4
  * @license MIT, https://github.com/focus-trap/focus-trap/blob/master/LICENSE
  *)
*/
//# sourceMappingURL=react-spring-bottom-sheet.js.map
